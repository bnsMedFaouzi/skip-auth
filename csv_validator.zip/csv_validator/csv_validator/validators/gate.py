"""File-gate validation — shared types and constants.

A *gate* check inspects the file as a whole (its columns / header) before any
value validation: if the structure is wrong, validating values makes no sense.
This module holds the abstractions (the check contract and its result); the
concrete checks live in `structure.py`, and `FileRunner` runs them.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field

from ..models import EngineConfig


@dataclass
class StructureResult:
    """Outcome of the file-structure validation (header comparison + gate checks)."""

    missing: list[str] = field(default_factory=list)      # schema cols absent from the CSV
    unexpected: list[str] = field(default_factory=list)   # CSV cols absent from the schema
    order_ok: bool = True
    issues: list[str] = field(default_factory=list)       # messages from extra gate checks
    valid: bool = True


class FileCheck(ABC):
    """A pluggable gate check on the file's columns.

    Returns a message describing the violation, or ``None`` when the file passes.
    Subclass it and hand instances to the engine (``structure_checks=[...]``) or
    to `FileRunner` — no built-in code changes (open/closed).
    """

    name: str = "file"

    @abstractmethod
    def violation(self, expected: list[str], actual: list[str], config: EngineConfig) -> str | None:
        """Message if the header violates the check, else ``None``."""
