"""Structure validation: the check abstraction, its result, and the concrete checks."""

from .base import StructureCheck, StructureResult
from .checks import HeaderCheck, MaxColumns

__all__ = ["StructureCheck", "StructureResult", "HeaderCheck", "MaxColumns"]
