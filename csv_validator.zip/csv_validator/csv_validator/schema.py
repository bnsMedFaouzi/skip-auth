"""Schema parsing (Strategy pattern).

`SchemaParser` is the abstract interface; `JsonSchemaParser` handles the
JSON-Schema draft-07 style used here. Adding an XSD parser later means adding a
subclass that produces the same `ColumnDef` list; the engine is untouched.

The JSON schema shape:

    {
      "definitions": { "<NamedType>": { "type": ..., "enum": ..., ... }, ... },
      "properties":  { "<Column>":    { "type": ..., "Size": ..., "Mandatory": ..., ... }, ... }
    }
"""

from __future__ import annotations

import json
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any

from .column import ColumnDef

_TYPE_ALIASES = {
    "str": "string",
    "text": "string",
    "int": "integer",
    "integer": "integer",
    "number": "number",
    "decimal": "number",
    "float": "number",
    "double": "number",
    "timestamp": "timestamp",
    "datetime": "timestamp",
    "date": "date",
    "boolean": "boolean",
    "bool": "boolean",
}


class SchemaParser(ABC):
    """Abstract schema parser: produces normalized columns."""

    @abstractmethod
    def parse(self) -> list[ColumnDef]:
        """Return the ordered list of normalized columns."""


class JsonSchemaParser(SchemaParser):
    """Parser for the JSON-Schema draft-07 style schema."""

    def __init__(self, source: str | Path | dict[str, Any]) -> None:
        self._source = source

    # -- public -------------------------------------------------------------

    def parse(self) -> list[ColumnDef]:
        data = self._load()
        definitions = data.get("definitions") or {}
        properties = data.get("properties") or {}

        columns = [
            self._to_column(name, node, definitions)
            for name, node in properties.items()
        ]
        # Sort by ColumnIndex when present; columns without an index keep their
        # order of appearance, placed after.
        columns.sort(key=lambda c: (c.order is None, c.order if c.order is not None else 0))
        return columns

    # -- helpers ------------------------------------------------------------

    def _load(self) -> dict[str, Any]:
        if isinstance(self._source, dict):
            return self._source
        p = Path(self._source)
        if p.exists():
            return json.loads(p.read_text(encoding="utf-8"))
        return json.loads(str(self._source))

    @staticmethod
    def _normalize_type(raw_type: str | None) -> str:
        if not raw_type:
            return "string"
        return _TYPE_ALIASES.get(str(raw_type).strip().lower(), str(raw_type).strip().lower())

    @staticmethod
    def _resolve_ref(node: dict[str, Any], definitions: dict[str, Any]) -> dict[str, Any]:
        """Merge an optional `$ref` with the node's own keys (local keys win)."""
        ref = node.get("$ref")
        if not ref:
            return node
        key = ref.split("/")[-1]           # "#/definitions/Currency" -> "Currency"
        base = dict(definitions.get(key, {}))
        return {**base, **{k: v for k, v in node.items() if k != "$ref"}}

    def _to_column(self, name: str, node: dict[str, Any], definitions: dict[str, Any]) -> ColumnDef:
        node = self._resolve_ref(node, definitions)

        allowed = node.get("AuthorizeValue") or node.get("enum")
        if allowed is not None:
            allowed = [str(v) for v in allowed]

        size = node.get("Size")
        minimum = node.get("minimum")
        mandatory = str(node.get("Mandatory", "no")).strip().lower() in ("yes", "true", "y", "1")

        return ColumnDef(
            name=name,
            base_type=self._normalize_type(node.get("type")),
            mandatory=mandatory,
            order=node.get("ColumnIndex"),
            max_length=int(size) if size is not None else None,
            allowed_values=allowed,
            pattern=node.get("pattern"),
            minimum=float(minimum) if minimum is not None else None,
            label=node.get("InformationItem"),
        )
