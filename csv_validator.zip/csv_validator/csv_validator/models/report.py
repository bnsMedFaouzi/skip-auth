"""Report models (Pydantic) and builder.

Being Pydantic models, reports serialize to JSON for free via
`report.model_dump_json()`.
"""

from __future__ import annotations

from pydantic import BaseModel, Field


class CheckResult(BaseModel):
    column: str
    check: str
    error_count: int
    sample: list[tuple[int, str]] = Field(default_factory=list)  # (line, value)


class ValidationReport(BaseModel):
    status: str                       # "VALID" / "INVALID"
    rows_checked: int
    columns_checked: int
    missing_columns: list[str] = Field(default_factory=list)
    results: list[CheckResult] = Field(default_factory=list)

    @property
    def total_errors(self) -> int:
        return sum(r.error_count for r in self.results)

    def to_text(self, sample_limit: int = 5) -> str:
        lines: list[str] = [
            f"status          : {self.status}",
            f"rows_checked    : {self.rows_checked}",
            f"columns_checked : {self.columns_checked}",
        ]
        if self.missing_columns:
            lines.append(f"missing_columns : {', '.join(self.missing_columns)}")
        lines.append(f"total_errors    : {self.total_errors}")
        lines.append("")
        if not self.results:
            lines.append("No errors.")
            return "\n".join(lines)

        lines.append("results")
        for r in self.results:
            lines.append(f"  {r.column:<16} {r.check:<14} error_count {r.error_count}")
            for line_no, value in r.sample[:sample_limit]:
                shown = value if value not in (None, "") else "(empty)"
                lines.append(f"      line {line_no:<6} « {shown} »")
        return "\n".join(lines)


class ReportBuilder:
    """Accumulates per-check results, then builds the final report."""

    def __init__(self) -> None:
        self._results: list[CheckResult] = []
        self._missing: list[str] = []

    def set_missing_columns(self, missing: list[str]) -> "ReportBuilder":
        self._missing = list(missing)
        return self

    def add_result(self, result: CheckResult) -> "ReportBuilder":
        self._results.append(result)
        return self

    def build(self, rows_checked: int, columns_checked: int) -> ValidationReport:
        status = "VALID" if (not self._results and not self._missing) else "INVALID"
        return ValidationReport(
            status=status,
            rows_checked=rows_checked,
            columns_checked=columns_checked,
            missing_columns=self._missing,
            results=self._results,
        )
