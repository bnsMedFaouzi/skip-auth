"""Tests for models/config.py: row weight and the linear batch-sizing model."""

from csv_validator import EngineConfig, JsonSchemaParser


def _cols(props):
    return JsonSchemaParser({"properties": props}).parse()


def test_forced_batch_size_wins():
    assert EngineConfig(row_batch_size=1234).batch_for(1000.0) == 1234


def test_row_weight_sums_columns_and_checks():
    cfg = EngineConfig()
    cols = _cols({"A": {"type": "string", "Size": 40, "ColumnIndex": 1},   # 40
                  "B": {"type": "number", "ColumnIndex": 2}})              # default_other (20)
    assert cfg.row_weight(cols, num_checks=3) == 40 + 20 + 3


def test_heavier_schema_gives_smaller_batch():
    cfg = EngineConfig()
    light, heavy = cfg.batch_for(100.0), cfg.batch_for(3000.0)
    assert heavy < light
    assert cfg.min_batch <= heavy <= cfg.max_batch
    assert cfg.min_batch <= light <= cfg.max_batch


def test_auto_batch_stays_under_margined_target():
    cfg = EngineConfig()
    W = 1000.0
    b = cfg.batch_for(W)
    if cfg.min_batch < b < cfg.max_batch:
        assert cfg.estimated_peak_mb(b, W) <= cfg.target_memory_mb * (1 - cfg.safety_margin) + 1


def test_operational_fields_configurable():
    cfg = EngineConfig(target_memory_mb=1000, safety_margin=0.3, default_string_bytes=128)
    assert (cfg.target_memory_mb, cfg.default_string_bytes) == (1000, 128)
