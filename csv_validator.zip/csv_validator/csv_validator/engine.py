"""Validation engine (Facade) with an asyncio event loop for performance.

Ties together a `SchemaParser`, a `DataSource`, and a `ValidatorRegistry`, and
runs the checks via the `Runner`. Independent Polars collects are dispatched
concurrently on the event loop (Polars releases the GIL during `collect()`).
"""

from __future__ import annotations

import asyncio
from pathlib import Path

from .datasource import CsvDataSource, DataSource
from .report import CheckResult, ReportBuilder, ValidationReport
from .runner import Runner
from .schema import JsonSchemaParser, SchemaParser
from .validators import BoundCheck, ValidatorRegistry, default_registry


class ValidationEngine:
    """Orchestrates parsing (Planner) and running (Runner) of the validation."""

    def __init__(
        self,
        schema_parser: SchemaParser,
        data_source: DataSource,
        registry: ValidatorRegistry | None = None,
        runner: Runner | None = None,
    ) -> None:
        self._schema_parser = schema_parser
        self._data_source = data_source
        self._registry = registry or default_registry()
        self._runner = runner or Runner()

    def validate(self, sample_size: int = 20) -> ValidationReport:
        try:
            asyncio.get_running_loop()
        except RuntimeError:
            return asyncio.run(self.validate_async(sample_size))
        raise RuntimeError(
            "An event loop is already running; use `await engine.validate_async()`."
        )

    async def validate_async(self, sample_size: int = 20) -> ValidationReport:
        columns = self._schema_parser.parse()
        csv_columns = set(self._data_source.columns())
        lf = self._data_source.frame()

        present = [c for c in columns if c.name in csv_columns]
        missing = [c.name for c in columns if c.name not in csv_columns]
        builder = ReportBuilder().set_missing_columns(missing)

        checks = self._plan(present)
        if not checks:
            rows = await asyncio.to_thread(self._runner.count_rows, lf)
            return builder.build(rows, len(present))

        # Row-count and invalid-count passes run concurrently.
        rows, counts = await asyncio.gather(
            asyncio.to_thread(self._runner.count_rows, lf),
            asyncio.to_thread(self._runner.count_invalids, lf, checks),
        )

        # Sample collects for all failing checks run concurrently.
        failing = [(i, chk) for i, chk in enumerate(checks) if int(counts[i] or 0) > 0]
        samples = await asyncio.gather(
            *(asyncio.to_thread(self._runner.collect_sample, lf, chk, sample_size)
              for _, chk in failing)
        )
        for (i, chk), sample in zip(failing, samples):
            builder.add_result(CheckResult(chk.column, chk.check, int(counts[i]), sample))

        return builder.build(rows, len(present))

    def _plan(self, present) -> list[BoundCheck]:
        return [chk for col in present for chk in self._registry.checks_for(col)]


# --- convenience facades ---------------------------------------------------

def _engine(schema_source, csv_path, registry) -> ValidationEngine:
    return ValidationEngine(
        schema_parser=JsonSchemaParser(schema_source),
        data_source=CsvDataSource(csv_path),
        registry=registry,
    )


def validate(schema_source, csv_path: str | Path, sample_size: int = 20,
             registry: ValidatorRegistry | None = None) -> ValidationReport:
    """Sync facade: validate a CSV against a JSON schema with defaults."""
    return _engine(schema_source, csv_path, registry).validate(sample_size)


async def validate_async(schema_source, csv_path: str | Path, sample_size: int = 20,
                         registry: ValidatorRegistry | None = None) -> ValidationReport:
    """Async facade: awaitable validation, driven by the event loop."""
    return await _engine(schema_source, csv_path, registry).validate_async(sample_size)
