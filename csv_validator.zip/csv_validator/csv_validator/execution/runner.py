"""Generic block runner: streams row blocks once, feeding block processors.

Iterating the blocks already yields the total row count (the runner sums block
heights to offset sample line numbers), so the count is returned directly — no
dedicated processor re-counts it. A `BlockProcessor` handles anything that needs
per-block state; adding a metric = adding a processor.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import Iterable
from typing import Any

import polars as pl


class BlockProcessor(ABC):
    """Consumes row blocks one by one, then yields a result."""

    @abstractmethod
    def update(self, block: pl.DataFrame, offset: int) -> None:
        """Fold one block into the running state (`offset` = rows seen before it)."""

    @abstractmethod
    def result(self) -> Any:
        """Return the accumulated result once all blocks are consumed."""


class Runner:
    """Streams blocks once, feeding each to every processor."""

    def run(
        self, blocks: Iterable[pl.DataFrame], processors: list[BlockProcessor]
    ) -> tuple[int, list[Any]]:
        """Consume the blocks a single time.

        Returns the total row count (intrinsic to the pass) and each processor's
        result, in order.
        """
        rows = 0
        for block in blocks:
            for processor in processors:
                processor.update(block, rows)
            rows += block.height
        return rows, [processor.result() for processor in processors]
