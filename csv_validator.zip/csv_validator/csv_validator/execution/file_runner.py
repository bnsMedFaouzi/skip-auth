"""File-level validation and metrics (the "file" runner).

Checks the file's structure — the header: which schema columns are present,
their order, and any missing/extra columns — which gates value validation, and
produces the `FileMetrics`. This is the natural home for future whole-file
checks (encoding, delimiter, declared file type). Column-value checks live in
`ColumnRunner`; the row count comes from the generic `Runner`.
"""

from __future__ import annotations

from ..models import ColumnDef, EngineConfig, FileMetrics
from ..validators.structure import HeaderResult, HeaderValidator, StructureCheck


class FileRunner:
    """Validates file structure and assembles the file-level metrics."""

    def __init__(self, config: EngineConfig, structure_checks: list[StructureCheck] | None = None) -> None:
        self._config = config
        self._header = HeaderValidator(structure_checks)

    def check_structure(self, expected: list[ColumnDef], actual: list[str]) -> HeaderResult:
        """Validate the header against the schema (presence, order, extras)."""
        return self._header.check(expected, actual, self._config)

    def metrics(
        self,
        *,
        rows: int,
        expected: int,
        present: int,
        structure: HeaderResult,
        total_errors: int,
        stopped_at: str | None = None,
    ) -> FileMetrics:
        """Produce the file-level metrics from structure + the pass results."""
        return FileMetrics(
            rows=rows,
            columns_expected=expected,
            columns_present=present,
            missing_columns=structure.missing,
            unexpected_columns=structure.unexpected,
            order_ok=structure.order_ok,
            structure_valid=structure.valid,
            structure_issues=structure.issues,
            stopped_at=stopped_at,
            total_errors=total_errors,
        )
