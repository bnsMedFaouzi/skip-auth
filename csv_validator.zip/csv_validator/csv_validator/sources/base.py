"""Data source abstraction (Strategy)."""

from __future__ import annotations

from abc import ABC, abstractmethod

import polars as pl


class DataSource(ABC):
    """Abstract source of tabular data."""

    @abstractmethod
    def columns(self) -> list[str]:
        """Return the column names, in order."""

    @abstractmethod
    def frame(self) -> pl.LazyFrame:
        """Return a lazy Polars frame with all columns as text (Utf8)."""
