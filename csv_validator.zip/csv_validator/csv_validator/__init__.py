"""CSV validation engine driven by a JSON schema.

Provided validations: value type + mandatory. Object-oriented, pattern-based
(Strategy, Template Method, Registry, Facade, Builder), and extensible.
"""

from .column import ColumnDef
from .datasource import DataSource, CsvDataSource
from .schema import SchemaParser, JsonSchemaParser
from .validators import (
    Validator,
    GatedValidator,
    TypeValidator,
    ConstraintValidator,
    MandatoryValidator,
    ValidatorRegistry,
    default_registry,
    BoundCheck,
)
from .report import CheckResult, ValidationReport, ReportBuilder
from .runner import Runner
from .engine import ValidationEngine, validate, validate_async

__all__ = [
    "ColumnDef",
    "DataSource", "CsvDataSource",
    "SchemaParser", "JsonSchemaParser",
    "Validator", "GatedValidator", "TypeValidator", "ConstraintValidator",
    "MandatoryValidator", "ValidatorRegistry", "default_registry", "BoundCheck",
    "CheckResult", "ValidationReport", "ReportBuilder",
    "Runner", "ValidationEngine", "validate", "validate_async",
]
