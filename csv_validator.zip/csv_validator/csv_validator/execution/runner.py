"""Generic block runner: streams row blocks once, feeding block processors.

A `BlockProcessor` consumes blocks incrementally and produces a result, so file-
level and column-level work share a single file pass. The runner itself is
backend-agnostic (it only iterates and dispatches); the Polars specifics live in
the processors. Adding a metric = adding a processor.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import Iterable
from typing import Any

import polars as pl


class BlockProcessor(ABC):
    """Consumes row blocks one by one, then yields a result."""

    @abstractmethod
    def update(self, block: pl.DataFrame, offset: int) -> None:
        """Fold one block into the running state (`offset` = rows seen before it)."""

    @abstractmethod
    def result(self) -> Any:
        """Return the accumulated result once all blocks are consumed."""


class Runner:
    """Streams blocks once, feeding each to every processor."""

    def run(self, blocks: Iterable[pl.DataFrame], processors: list[BlockProcessor]) -> list[Any]:
        """Consume the blocks a single time; return each processor's result, in order."""
        offset = 0
        for block in blocks:
            for processor in processors:
                processor.update(block, offset)
            offset += block.height
        return [processor.result() for processor in processors]
