"""BoundCheck: a validator bound to a column (holds a Polars expression).

Kept as a dataclass (not Pydantic) because it carries a `pl.Expr`, which is not a
validated/serializable value.
"""

from __future__ import annotations

from dataclasses import dataclass

import polars as pl


@dataclass
class BoundCheck:
    """A check bound to a column: its display name and its invalid-mask expression."""

    column: str
    check: str
    invalid: pl.Expr
