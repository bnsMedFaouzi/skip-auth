"""Validator base classes (Strategy + Template Method) and the bound check."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass

import polars as pl

from ..column import ColumnDef


def non_empty(name: str) -> pl.Expr:
    """Mask of cells that are actually filled (not null, not blank)."""
    e = pl.col(name)
    return e.is_not_null() & (e.cast(pl.Utf8).str.strip_chars() != "")


@dataclass
class BoundCheck:
    """A validator bound to a column: the final invalid mask to evaluate."""

    column: str
    check: str
    invalid: pl.Expr


class Validator(ABC):
    """A validation strategy applicable to a column."""

    @abstractmethod
    def applies(self, col: ColumnDef) -> bool:
        """Whether this validator concerns the given column."""

    @abstractmethod
    def build(self, col: ColumnDef) -> pl.Expr:
        """Boolean mask, True where the cell is invalid."""

    def check_name(self, col: ColumnDef) -> str:
        return getattr(self, "name", self.__class__.__name__)


class GatedValidator(Validator):
    """Template Method: only non-empty cells are checked.

    Subclasses implement `invalid_expr`; the gate excluding empty cells is
    applied here once.
    """

    @abstractmethod
    def invalid_expr(self, col: ColumnDef) -> pl.Expr:
        """Invalid mask, assuming the cell is non-empty."""

    def build(self, col: ColumnDef) -> pl.Expr:
        return non_empty(col.name) & self.invalid_expr(col)
