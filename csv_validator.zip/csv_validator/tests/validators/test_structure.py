"""Tests for file-structure validation: gate types + structure checks + FileRunner."""

from csv_validator import (
    CsvDataSource, EngineConfig, FileCheck, HeaderStructure,
    JsonSchemaParser, MaxColumns, ValidationEngine,
)
from csv_validator.execution.file_runner import FileRunner


def _cols(props):
    return JsonSchemaParser({"properties": props}).parse()


# -- end-to-end via validate() ---------------------------------------------- #

def test_missing_column_gates(run_csv):
    schema = {"properties": {
        "A": {"type": "string", "ColumnIndex": 1, "Mandatory": "Yes"},
        "B": {"type": "string", "ColumnIndex": 2, "Mandatory": "No"},
    }}
    report = run_csv(schema, "A\nx\n")                      # B missing
    assert report.status == "INVALID_STRUCTURE"
    assert report.file.stopped_at == "header"
    assert "B" in report.file.missing_columns


def test_extra_column_flagged(run_csv):
    schema = {"properties": {"A": {"type": "string", "ColumnIndex": 1, "Mandatory": "No"}}}
    report = run_csv(schema, "A;Z\nx;1\n")                  # Z is extra
    assert "Z" in report.file.unexpected_columns
    assert report.file.structure_valid is False


def test_order_mismatch(run_csv):
    schema = {"properties": {
        "A": {"type": "string", "ColumnIndex": 1, "Mandatory": "No"},
        "B": {"type": "string", "ColumnIndex": 2, "Mandatory": "No"},
    }}
    report = run_csv(schema, "B;A\n1;2\n")                  # wrong order
    assert report.file.order_ok is False
    assert report.status == "INVALID_STRUCTURE"


def test_extra_column_tolerated_when_configured(run_csv):
    schema = {"properties": {"A": {"type": "string", "ColumnIndex": 1, "Mandatory": "No"}}}
    report = run_csv(schema, "A;Z\nx;1\n", allow_extra_columns=True)
    assert report.file.structure_valid is True
    assert "Z" in report.file.unexpected_columns


# -- units: header comparison + gate checks + orchestration ------------------ #

def test_header_structure_compare_detects_order():
    cols = _cols({"A": {"type": "string", "ColumnIndex": 1, "Mandatory": "No"},
                  "B": {"type": "string", "ColumnIndex": 2, "Mandatory": "No"}})
    missing, unexpected, order_ok = HeaderStructure().compare(cols, ["B", "A"], EngineConfig())
    assert (missing, unexpected, order_ok) == ([], [], False)


def test_max_columns_gate_via_file_runner():
    cols = _cols({"a": {"type": "string", "ColumnIndex": 1}})
    result = FileRunner(EngineConfig(), structure_checks=[MaxColumns(2)]).check_structure(cols, ["a", "b", "c"])
    assert result.valid is False
    assert any("too many columns" in m for m in result.issues)


def test_custom_gate_check_gates_engine(tmp_file):
    class RejectAll(FileCheck):
        name = "reject_all"
        def violation(self, expected, actual, config):
            return "rejected by policy"

    schema = {"properties": {"a": {"type": "number", "ColumnIndex": 1}}}
    csv = tmp_file("a\n1\n")
    report = ValidationEngine(JsonSchemaParser(schema), CsvDataSource(csv),
                              structure_checks=[RejectAll()]).validate()
    assert report.status == "INVALID_STRUCTURE"
    assert "rejected by policy" in report.file.structure_issues
