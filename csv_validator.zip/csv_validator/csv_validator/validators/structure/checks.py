"""Concrete structure checks — the header, and other file-level rules."""

from __future__ import annotations

from ...models import ColumnDef, EngineConfig
from .base import StructureCheck


class HeaderCheck(StructureCheck):
    """The CSV columns must match the schema: presence, no extras, and order."""

    name = "header"

    def check(self, columns: list[ColumnDef], actual: list[str], config: EngineConfig) -> list[str]:
        expected = [c.name for c in columns]           # already sorted by order
        expected_set, actual_set = set(expected), set(actual)
        issues: list[str] = []

        missing = [c for c in expected if c not in actual_set]
        if missing:
            issues.append(f"missing columns: {', '.join(missing)}")

        unexpected = [c for c in actual if c not in expected_set]
        if unexpected and not config.allow_extra_columns:
            issues.append(f"unexpected columns: {', '.join(unexpected)}")

        # Order is only meaningful once the sets line up.
        if config.strict_column_order and not missing and (config.allow_extra_columns or not unexpected):
            if [c for c in actual if c in expected_set] != expected:
                issues.append("columns out of order")

        return issues


class MaxColumns(StructureCheck):
    """The CSV must not have more than `limit` columns. (Not enabled by default.)"""

    name = "max_columns"

    def __init__(self, limit: int) -> None:
        self._limit = limit

    def check(self, columns: list[ColumnDef], actual: list[str], config: EngineConfig) -> list[str]:
        return [f"too many columns: {len(actual)} > {self._limit}"] if len(actual) > self._limit else []
