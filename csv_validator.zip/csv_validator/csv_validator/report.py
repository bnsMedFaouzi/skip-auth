"""Report structures and builder (Builder pattern)."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class CheckResult:
    column: str
    check: str
    error_count: int
    sample: list[tuple[int, str]] = field(default_factory=list)  # (line no., value)


@dataclass
class ValidationReport:
    status: str                       # "VALID" / "INVALID"
    rows_checked: int
    columns_checked: int
    missing_columns: list[str] = field(default_factory=list)
    results: list[CheckResult] = field(default_factory=list)

    @property
    def total_errors(self) -> int:
        return sum(r.error_count for r in self.results)

    def to_text(self, sample_limit: int = 5) -> str:
        lines: list[str] = []
        lines.append(f"status          : {self.status}")
        lines.append(f"rows_checked    : {self.rows_checked}")
        lines.append(f"columns_checked : {self.columns_checked}")
        if self.missing_columns:
            lines.append(f"missing_columns : {', '.join(self.missing_columns)}")
        lines.append(f"total_errors    : {self.total_errors}")
        lines.append("")
        if not self.results:
            lines.append("No errors.")
            return "\n".join(lines)

        lines.append("results")
        for r in self.results:
            lines.append(f"  {r.column:<16} {r.check:<14} error_count {r.error_count}")
            for line_no, value in r.sample[:sample_limit]:
                shown = value if value not in (None, "") else "(empty)"
                lines.append(f"      line {line_no:<6} \u00ab {shown} \u00bb")
        return "\n".join(lines)


class ReportBuilder:
    """Accumulates per-check results, then builds the final report."""

    def __init__(self) -> None:
        self._results: list[CheckResult] = []
        self._missing: list[str] = []

    def set_missing_columns(self, missing: list[str]) -> "ReportBuilder":
        self._missing = list(missing)
        return self

    def add_result(self, result: CheckResult) -> "ReportBuilder":
        self._results.append(result)
        return self

    def build(self, rows_checked: int, columns_checked: int) -> ValidationReport:
        status = "VALID" if (not self._results and not self._missing) else "INVALID"
        return ValidationReport(
            status=status,
            rows_checked=rows_checked,
            columns_checked=columns_checked,
            missing_columns=self._missing,
            results=self._results,
        )
