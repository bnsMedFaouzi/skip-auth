"""Validator registry — the extension point."""

from __future__ import annotations

from ..models import ColumnDef, EngineConfig
from ..models.check import BoundCheck
from .base import Validator
from .constraints import CONSTRAINT_VALIDATORS, MandatoryValidator
from .types import (
    BooleanType, DateType, IntegerType, NumberType, StringType, TimestampType,
)


class ValidatorRegistry:
    """Holds validators and yields the checks applicable to a column."""

    def __init__(self) -> None:
        self._validators: list[Validator] = []

    def register(self, validator: Validator) -> "ValidatorRegistry":
        self._validators.append(validator)
        return self

    def checks_for(self, col: ColumnDef) -> list[BoundCheck]:
        return [
            BoundCheck(col.name, v.check_name(col), v.build(col))
            for v in self._validators
            if v.applies(col)
        ]


def default_registry(config: EngineConfig | None = None) -> ValidatorRegistry:
    """Registry with the built-in validators (mandatory + type + constraints).

    Date/Timestamp validators receive their default format from `config`.
    """
    cfg = config or EngineConfig()
    registry = ValidatorRegistry()
    registry.register(MandatoryValidator())
    registry.register(StringType())
    registry.register(NumberType())
    registry.register(IntegerType())
    registry.register(TimestampType(cfg.default_timestamp_format))
    registry.register(DateType(cfg.default_date_format))
    registry.register(BooleanType())
    for cv in CONSTRAINT_VALIDATORS:
        registry.register(cv())
    return registry
