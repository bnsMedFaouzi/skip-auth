"""Benchmark the CSV validator on YOUR files (a JSON schema + a CSV).

Usage
-----
    python benchmarks/run_bench.py schema.json data.csv
    python benchmarks/run_bench.py schema.json data.csv --date-fmt "%Y%m%d"
    python benchmarks/run_bench.py schema.json data.csv --quick   # headline only

Method
------
Peak memory is read from `resource.getrusage(...).ru_maxrss` (a per-process
maximum), so every case runs in its OWN subprocess — otherwise the first case's
peak would contaminate the next. This orchestrating process stays tiny so its
memory is never inherited by the measurement subprocesses.

What it reports
---------------
1. Headline   -> time, throughput, peak memory, rows, errors
2. Batch size -> row_batch_size is a memory knob, not a speed knob
3. Engine     -> streaming vs in-memory

Notes
-----
- Runs the file several times (once per case); use --quick on very large files.
- Pass --date-fmt to match your Date columns (e.g. "%Y%m%d" for YYYYMMDD).
- Throughput is per available core; check the printed core count.
"""

from __future__ import annotations

import argparse
import json
import os
import resource
import subprocess
import sys
import time
import warnings
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent                       # dir containing the `csv_validator` package
BATCHES = (20_000, 50_000, 100_000, 200_000)
DEFAULT_BATCH = 100_000


# --------------------------------------------------------------------------- #
# One measurement (runs as a subprocess for a clean peak-RSS reading)
# --------------------------------------------------------------------------- #

def measure(schema: str, csv: str, streaming: bool, batch: int, date_fmt: str) -> None:
    warnings.filterwarnings("ignore")
    sys.path.insert(0, str(ROOT))
    import csv_validator as cv

    row_batch_size = None if batch <= 0 else batch   # <=0 -> auto-size from column count
    cfg = cv.EngineConfig(default_date_format=date_fmt, streaming=streaming, row_batch_size=row_batch_size)
    start = time.perf_counter()
    report = cv.validate(schema, csv, config=cfg)
    elapsed = time.perf_counter() - start
    peak = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024  # MB
    print(json.dumps({
        "time": elapsed, "peak_mb": peak,
        "rows": report.file.rows, "errors": report.file.total_errors,
        "status": report.status,
    }))


def run_case(schema: Path, csv: Path, *, streaming: bool, batch: int, date_fmt: str) -> dict:
    """Run one measurement in a fresh process and return its parsed result."""
    proc = subprocess.run(
        [sys.executable, str(HERE / "run_bench.py"), str(schema), str(csv), "--measure",
         "--streaming", str(streaming), "--batch", str(batch), "--date-fmt", date_fmt],
        capture_output=True, text=True,
    )
    if proc.returncode != 0:
        raise RuntimeError(f"measurement failed:\n{proc.stderr}")
    return json.loads(proc.stdout.strip().splitlines()[-1])


# --------------------------------------------------------------------------- #
# Orchestration
# --------------------------------------------------------------------------- #

def suite(schema: Path, csv: Path, date_fmt: str, quick: bool) -> None:
    if not schema.exists():
        sys.exit(f"schema not found: {schema}")
    if not csv.exists():
        sys.exit(f"csv not found: {csv}")

    size_mb = csv.stat().st_size / 1e6
    ncpu = os.cpu_count() or 1
    print(f"file: {csv.name}  ({size_mb:.0f} MB)   schema: {schema.name}   cores: {ncpu}")
    print(f"date format: {date_fmt}\n")

    # 1) headline (streaming, auto batch = the real default)
    print("== 1. headline (streaming, auto batch) ==")
    r = run_case(schema, csv, streaming=True, batch=0, date_fmt=date_fmt)
    print(f"  status   : {r['status']}")
    print(f"  rows     : {r['rows']:,}")
    print(f"  errors   : {r['errors']:,}")
    print(f"  time     : {r['time']:.1f} s   ({size_mb / r['time']:.1f} MB/s on {ncpu} core(s))")
    print(f"  peak mem : {r['peak_mb']:.0f} MB")

    if quick:
        return

    # 2) batch-size sweep -> memory knob, not speed knob
    print("\n== 2. batch size (memory vs speed) ==")
    print(f"{'batch':>8} | {'time s':>7} | {'peak MB':>8}")
    for batch in BATCHES:
        r = run_case(schema, csv, streaming=True, batch=batch, date_fmt=date_fmt)
        print(f"{batch:>8} | {r['time']:7.1f} | {r['peak_mb']:8.0f}")

    # 3) streaming vs in-memory
    print("\n== 3. engine ==")
    print(f"{'engine':>10} | {'time s':>7} | {'peak MB':>8}")
    for streaming in (True, False):
        r = run_case(schema, csv, streaming=streaming, batch=0, date_fmt=date_fmt)
        print(f"{'streaming' if streaming else 'in-memory':>10} | {r['time']:7.1f} | {r['peak_mb']:8.0f}")


def main() -> None:
    parser = argparse.ArgumentParser(description="Benchmark the CSV validator on a schema + CSV.")
    parser.add_argument("schema", help="path to the JSON schema")
    parser.add_argument("csv", help="path to the CSV file to validate")
    parser.add_argument("--date-fmt", default="%Y%m%d", help="date format for Date columns")
    parser.add_argument("--quick", action="store_true", help="headline measurement only")
    # internal (subprocess measurement mode)
    parser.add_argument("--measure", action="store_true", help=argparse.SUPPRESS)
    parser.add_argument("--streaming", default="True", help=argparse.SUPPRESS)
    parser.add_argument("--batch", type=int, default=DEFAULT_BATCH, help=argparse.SUPPRESS)
    args = parser.parse_args()

    if args.measure:
        measure(args.schema, args.csv, args.streaming == "True", args.batch, args.date_fmt)
    else:
        suite(Path(args.schema), Path(args.csv), args.date_fmt, args.quick)


if __name__ == "__main__":
    main()
