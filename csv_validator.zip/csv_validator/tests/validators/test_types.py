"""Tests for validators/types.py: type checks and date formats."""


def test_default_date_format_configurable(run_csv, checks):
    schema = {"properties": {"D": {"type": "Date", "Size": 8, "ColumnIndex": 1, "Mandatory": "No"}}}
    # with YYYYMMDD default, 20240115 is valid; only 'bad' fails
    r = run_csv(schema, "D\n20240115\nbad\n", default_date_format="%Y%m%d")
    assert checks(r).get(("D", "type:date")) == 1


def test_per_column_date_format_overrides_default(run_csv, checks):
    schema = {"properties": {"D": {"type": "Date", "Format": "%d/%m/%Y", "ColumnIndex": 1, "Mandatory": "No"}}}
    r = run_csv(schema, "D\n15/01/2024\n2024-01-15\n")
    assert checks(r).get(("D", "type:date")) == 1          # ISO value fails the dd/mm/yyyy format
