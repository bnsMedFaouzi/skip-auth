"""Type validators: one consolidated check per column, composing constraints.

A type validator holds a list of `Constraint` objects (its base-type format check
plus the value constraints relevant to that type) and emits a single
"type:<type>" check: the OR of the constraints that apply to the column. The
composition lives in the base class; a subclass only declares its constraints.
`constraints` is an instance list, so a rule can be folded in at runtime.
"""

from __future__ import annotations

import polars as pl

from ...models.column import ColumnDef
from .base import GatedValidator
from .constraint import (
    BooleanFormat, Constraint, DateFormat, Enum, IntegerFormat, MaxLength,
    Minimum, NumberFormat, Pattern, Precision, TimestampFormat,
)


class TypeValidator(GatedValidator):
    """A per-type check: the OR of the constraints that apply to the column."""

    handles: tuple[str, ...] = ()

    def __init__(self, constraints: list[Constraint]) -> None:
        self.constraints = list(constraints)

    def applies(self, col: ColumnDef) -> bool:
        """True if the column is one of `handles` and at least one constraint applies."""
        return col.type in self.handles and any(c.applies(col) for c in self.constraints)

    def check_name(self, col: ColumnDef) -> str:
        """The check is reported as ``type:<type>``."""
        return f"type:{col.type}"

    def invalid_expr(self, col: ColumnDef) -> pl.Expr:
        """Invalid where any applicable constraint's mask is True."""
        active = [c.mask(col) for c in self.constraints if c.applies(col)]
        return pl.any_horizontal(active) if active else pl.lit(False)


class StringType(TypeValidator):
    """String: max length, allowed values, and pattern."""

    handles = ("string", "text")

    def __init__(self) -> None:
        super().__init__([MaxLength(), Enum(), Pattern()])


class NumberType(TypeValidator):
    """Number: numeric format, minimum, and decimal precision."""

    handles = ("number", "decimal", "float", "double")

    def __init__(self) -> None:
        super().__init__([NumberFormat(), Minimum(), Precision()])


class IntegerType(TypeValidator):
    """Integer: integer format and minimum."""

    handles = ("integer",)

    def __init__(self) -> None:
        super().__init__([IntegerFormat(), Minimum()])


class TimestampType(TypeValidator):
    """Timestamp: parses in the column's format (or the engine default)."""

    handles = ("timestamp", "datetime")

    def __init__(self, default_format: str = "%Y-%m-%dT%H:%M:%S") -> None:
        super().__init__([TimestampFormat(default_format)])


class DateType(TypeValidator):
    """Date: parses in the column's format (or the engine default)."""

    handles = ("date",)

    def __init__(self, default_format: str = "%Y-%m-%d") -> None:
        super().__init__([DateFormat(default_format)])


class BooleanType(TypeValidator):
    """Boolean: recognized true/false tokens."""

    handles = ("boolean",)

    def __init__(self) -> None:
        super().__init__([BooleanFormat()])


TYPE_VALIDATORS = (StringType, NumberType, IntegerType, TimestampType, DateType, BooleanType)
