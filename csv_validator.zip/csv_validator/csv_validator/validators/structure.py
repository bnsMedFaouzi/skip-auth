"""File-structure validations: the header comparison and other gate checks.

`HeaderStructure` is the built-in structural check — which schema columns are
present, their order, and any missing/extra ones — producing the detailed lists
the report shows. Extra rules (e.g. a column-count cap) plug in as `FileCheck`
objects. `FileRunner` runs the header comparison together with these checks.
"""

from __future__ import annotations

from ..models import ColumnDef, EngineConfig
from .gate import FileCheck


class HeaderStructure:
    """Compares the CSV header to the schema: missing, unexpected, and order."""

    def compare(
        self, columns: list[ColumnDef], actual: list[str], config: EngineConfig
    ) -> tuple[list[str], list[str], bool]:
        """Return (missing, unexpected, order_ok) for the header vs the schema."""
        expected = [c.name for c in columns]           # already sorted by order
        expected_set, actual_set = set(expected), set(actual)

        missing = [c for c in expected if c not in actual_set]
        unexpected = [c for c in actual if c not in expected_set]

        # Order is only meaningful once the sets line up.
        order_ok = True
        if config.strict_column_order and not missing and (config.allow_extra_columns or not unexpected):
            order_ok = [c for c in actual if c in expected_set] == expected

        return missing, unexpected, order_ok


class MaxColumns(FileCheck):
    """The CSV must not have more than `limit` columns. (Not enabled by default.)

    A source-agnostic gate check: it counts columns, so it works even when the
    reader renames duplicate headers. Use it as `MaxColumns(300)`.
    """

    name = "max_columns"

    def __init__(self, limit: int) -> None:
        self._limit = limit

    def violation(self, expected: list[str], actual: list[str], config: EngineConfig) -> str | None:
        return f"too many columns: {len(actual)} > {self._limit}" if len(actual) > self._limit else None
