"""Normalized column definition, shared across the engine."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class ColumnDef:
    """Normalized column definition, independent of the source schema format."""

    name: str
    base_type: str                           # "string", "number", "timestamp"...
    mandatory: bool = False
    order: int | None = None                 # ColumnIndex
    max_length: int | None = None            # Size
    allowed_values: list[str] | None = None  # AuthorizeValue / enum
    pattern: str | None = None
    minimum: float | None = None
    label: str | None = None                 # InformationItem (human-readable)
