"""JSON schema parser (JSON-Schema draft-07 style), validated with Pydantic.

Each `properties` entry is validated into a `PropertySchema` (coercion, aliases,
clear errors), then mapped to a normalized `ColumnDef`.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from pydantic import ValidationError

from ..models import ColumnDef, PropertySchema, RawSchema
from .base import SchemaParser

_TYPE_ALIASES = {
    "str": "string", "text": "string",
    "int": "integer", "integer": "integer",
    "number": "number", "decimal": "number", "float": "number", "double": "number",
    "timestamp": "timestamp", "datetime": "timestamp",
    "date": "date", "boolean": "boolean", "bool": "boolean",
}
_TRUE = {"yes", "true", "y", "1"}


class JsonSchemaParser(SchemaParser):
    def __init__(self, source: str | Path | dict[str, Any]) -> None:
        self._source = source

    def parse(self) -> list[ColumnDef]:
        raw = RawSchema.model_validate(self._load())
        columns = [
            self._to_column(name, self._resolve(node, raw.definitions))
            for name, node in raw.properties.items()
        ]
        columns.sort(key=lambda c: (c.order is None, c.order if c.order is not None else 0))
        return columns

    # -- helpers ------------------------------------------------------------

    def _load(self) -> dict[str, Any]:
        if isinstance(self._source, dict):
            return self._source
        p = Path(self._source)
        return json.loads(p.read_text(encoding="utf-8") if p.exists() else str(self._source))

    @staticmethod
    def _resolve(node: dict[str, Any], definitions: dict[str, dict]) -> dict[str, Any]:
        """Merge an optional `$ref` with the node's own keys (local keys win)."""
        ref = node.get("$ref")
        if not ref:
            return node
        base = dict(definitions.get(ref.split("/")[-1], {}))
        return {**base, **{k: v for k, v in node.items() if k != "$ref"}}

    def _to_column(self, name: str, node: dict[str, Any]) -> ColumnDef:
        try:
            prop = PropertySchema.model_validate(node)
        except ValidationError as exc:
            raise ValueError(f"Invalid schema for column '{name}': {exc}") from exc

        base_type = _TYPE_ALIASES.get((prop.type or "string").lower(), (prop.type or "string").lower())
        return ColumnDef(
            name=name,
            base_type=base_type,
            mandatory=prop.mandatory.strip().lower() in _TRUE,
            order=prop.column_index,
            max_length=prop.size,
            allowed_values=prop.authorize_value or prop.enum,
            pattern=prop.pattern,
            minimum=prop.minimum,
            label=prop.information_item,
            attributes=node,
        )
