"""Report models (Pydantic): file-level and column-level metrics.

- FileMetrics   : structure of the file/header (missing/extra/ordered columns,
                  row count, overall structure validity).
- ColumnMetrics : per-column quality (failure rate, per-check breakdown).

Being Pydantic models, reports serialize to JSON via `report.model_dump_json()`.
"""

from __future__ import annotations

from pydantic import BaseModel, Field


class CheckMetric(BaseModel):
    check: str
    error_count: int
    failure_rate: float                                # error_count / rows
    sample: list[tuple[int, str]] = Field(default_factory=list)  # (line, value)


class ColumnMetrics(BaseModel):
    column: str
    failing_rows: int                                  # distinct rows failing >=1 check
    failure_rate: float                                # failing_rows / rows
    error_count: int                                   # sum of per-check counts
    checks: list[CheckMetric] = Field(default_factory=list)


class FileMetrics(BaseModel):
    rows: int
    columns_expected: int
    columns_present: int
    missing_columns: list[str] = Field(default_factory=list)
    unexpected_columns: list[str] = Field(default_factory=list)
    order_ok: bool = True
    structure_valid: bool = True
    stopped_at: str | None = None
    total_errors: int = 0


class ValidationReport(BaseModel):
    status: str                                        # "VALID" / "INVALID"
    file: FileMetrics
    columns: list[ColumnMetrics] = Field(default_factory=list)

    @property
    def total_errors(self) -> int:
        return self.file.total_errors

    def to_text(self, sample_limit: int = 5, show_clean: bool = False) -> str:
        f = self.file
        out = [f"status : {self.status}", "", "file metrics"]
        out.append(f"  rows            : {f.rows}")
        out.append(f"  columns         : {f.columns_present}/{f.columns_expected} present")
        if f.missing_columns:
            out.append(f"  missing_columns : {', '.join(f.missing_columns)}")
        if f.unexpected_columns:
            out.append(f"  extra_columns   : {', '.join(f.unexpected_columns)}")
        out.append(f"  order_ok        : {f.order_ok}")
        out.append(f"  structure_valid : {f.structure_valid}")
        if f.stopped_at:
            out.append(f"  stopped_at      : {f.stopped_at}")
        out.append(f"  total_errors    : {f.total_errors}")

        failing_cols = [c for c in self.columns if c.error_count > 0]
        shown_cols = self.columns if show_clean else failing_cols
        clean = len(self.columns) - len(failing_cols)
        if shown_cols:
            out.append("")
            out.append("column metrics" if show_clean else "column metrics (failing columns)")
            for c in shown_cols:
                out.append(
                    f"  {c.column:<16} failing {c.failing_rows}/{f.rows} "
                    f"(rate {c.failure_rate:.2%}) · errors {c.error_count}"
                )
                for ck in c.checks:
                    out.append(f"      {ck.check:<14} {ck.error_count} (rate {ck.failure_rate:.2%})")
                    for line_no, value in ck.sample[:sample_limit]:
                        shown = value if value not in (None, "") else "(empty)"
                        out.append(f"         line {line_no:<6} « {shown} »")
        if clean and not show_clean:
            out.append("")
            out.append(f"{clean} column(s) checked with no errors.")
        return "\n".join(out)


class ReportBuilder:
    """Assembles the final ValidationReport from file + column metrics."""

    def build(self, file: FileMetrics, columns: list[ColumnMetrics]) -> ValidationReport:
        is_valid = file.structure_valid and file.stopped_at is None and file.total_errors == 0
        return ValidationReport(
            status="VALID" if is_valid else "INVALID",
            file=file,
            columns=columns,
        )
