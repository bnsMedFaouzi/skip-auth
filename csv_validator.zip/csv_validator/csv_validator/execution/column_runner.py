"""Per-column checks, evaluated block by block with Polars (bounded memory).

Role
----
`ColumnRunner` is the `BlockProcessor` that runs the value-level validation. The
generic `Runner` streams the file as lazy blocks and hands them here one at a
time; this class evaluates every column's checks on each block and accumulates
the results, then reports them once the file is exhausted.

Design: flatten, then regroup
-----------------------------
A schema yields `checks_by_column`, e.g. ``{"Amount": [type:number],
"Ccy": [type:string]}``. Internally the checks are *flattened* into a single list
``_flat = [(column, check), ...]``. Each check then has a stable index ``i`` used
everywhere: per-check state lives in plain lists indexed by ``i`` (``_counts``,
``_samples``, ``_needs_sample``), which keeps the hot path simple and allocation-
free. Results are regrouped per column only at the end, in `_assemble`.

One collect per block, three uses per mask
------------------------------------------
For each block a single streaming `collect` computes everything at once. Each
check's boolean mask (True where a cell is invalid) is materialized once and
reused three ways: summed for the check's error count, OR-ed across a column's
checks for that column's failing-row count, and filtered for a bounded sample of
offending ``(line, value)`` pairs. Only a one-row result leaves Polars per block,
so peak memory depends on the block size, not the file size.

Samples are capped at ``sample_size`` per check; once a check's sample is full it
is dropped from later blocks' work. Sample line numbers are shifted by ``offset``
(the number of rows seen before the block) to be file-absolute.
"""

from __future__ import annotations

import polars as pl

from ..models import BoundCheck
from .runner import BlockProcessor

ROW_IDX = "__row__"  # transient row-index column added per block to number samples

# Shapes returned by `result()`, consumed by the engine to build the report.
CheckData = tuple[str, int, list[tuple[int, str]]]     # (check, error_count, sample)
ColumnData = tuple[str, int, list[CheckData]]          # (column, failing_rows, checks)


class ColumnRunner(BlockProcessor):
    """Accumulates per-column check results across blocks.

    State (all sized/keyed once in ``__init__`` then only mutated in place):

    - ``_sample_size`` / ``_engine`` -- config: sample cap per check; Polars
      collect engine (``"streaming"`` or ``"auto"``).
    - ``_flat`` -- the flattened ``[(column, check), ...]``; a check's position
      here is its identity in every parallel list below.
    - ``_masks`` / ``_rows_expr`` / ``_count_exprs`` / ``_sample_exprs`` /
      ``_colfail_exprs`` -- the Polars expressions, all data-independent, so built
      once and reused for every block; per block only the sample *subset* varies.
    - ``_col_indices`` -- ``{column: [flat indices]}`` in schema order; the single
      source of truth for which checks belong to a column (and for column order).
    - ``_counts`` -- per-check cumulative error count (parallel to ``_flat``).
    - ``_samples`` -- per-check accumulated ``[(line, value)]`` (parallel to ``_flat``).
    - ``_needs_sample`` -- per-check "still collecting?" flag; flips to False when a
      sample is full so later blocks skip it (parallel to ``_flat``).
    - ``_colfail`` -- ``{column: cumulative failing-row count}``; distinct rows that
      fail at least one of the column's checks (not the sum of check errors).
    """

    def __init__(
        self,
        checks_by_column: dict[str, list[BoundCheck]],
        sample_size: int,
        engine: str = "streaming",
    ) -> None:
        """Set up the flat check list and the per-check / per-column accumulators.

        ``checks_by_column`` is consumed here to build ``_flat`` and is not kept.
        """
        self._sample_size = sample_size
        self._engine = engine
        self._flat = [(col, chk) for col, chks in checks_by_column.items() for chk in chks]
        self._col_indices = self._group_by_column()
        # All expressions below are data-independent, so build them once and reuse
        # them for every block (only the sample subset selected varies per block).
        self._masks = self._mask_columns()
        self._rows_expr = pl.len().alias("rows")
        self._count_exprs = [pl.col(f"m{i}").sum().alias(f"count:{i}") for i in range(len(self._flat))]
        self._sample_exprs = [self._sample_expr(i) for i in range(len(self._flat))]
        self._colfail_exprs = [self._colfail_expr(col, idxs) for col, idxs in self._col_indices.items()]
        self._counts = [0] * len(self._flat)
        self._samples: list[list[tuple[int, str]]] = [[] for _ in self._flat]
        self._needs_sample = [sample_size > 0 for _ in self._flat]
        self._colfail = {col: 0 for col in self._col_indices}

    def _group_by_column(self) -> dict[str, list[int]]:
        """Map each column to the indices of its checks in the flat list.

        Built by scanning ``_flat`` with ``setdefault``, so columns appear in
        first-seen (i.e. schema) order — the order used for the final report.
        """
        indices: dict[str, list[int]] = {}
        for i, (col, _) in enumerate(self._flat):
            indices.setdefault(col, []).append(i)
        return indices

    # -- BlockProcessor interface -------------------------------------------

    def update(self, block: pl.LazyFrame, offset: int) -> int:
        """Evaluate one block and fold it into the accumulators.

        ``offset`` is the number of rows seen before this block (used to make
        sample line numbers file-absolute). Returns the block's row count so the
        runner can advance the total and the next offset.
        """
        row = self._evaluate(block)
        self._accumulate(row, offset)
        return int(row["rows"])

    def result(self) -> list[ColumnData]:
        """Return the accumulated per-column results (one ``ColumnData`` per column)."""
        return self._assemble()

    # -- one Polars pass over one block -------------------------------------

    def _evaluate(self, block: pl.LazyFrame) -> dict:
        """Add the masks and aggregates to the lazy block, then collect once.

        The single streaming collect lets Polars fuse scan + masks + aggregation
        and process the block in sub-chunks, so only the one-row result is kept.
        Returns that row as a ``{name: value}`` dict.
        """
        return (
            block.with_row_index(ROW_IDX)
            .with_columns(self._masks)
            .select(self._aggregates())
            .collect(engine=self._engine)
            .row(0, named=True)
        )

    def _mask_columns(self) -> list[pl.Expr]:
        """One boolean column ``m{i}`` per check. Data-independent, so built once
        in ``__init__`` and reused for every block.

        ``fill_null(False)`` means a null/missing cell is not counted as invalid
        here (completeness is the mandatory check's concern, not the type checks').
        """
        return [chk.invalid.fill_null(False).alias(f"m{i}") for i, (_, chk) in enumerate(self._flat)]

    def _aggregates(self) -> list[pl.Expr]:
        """Assemble this block's aggregates from the precomputed expressions.

        Everything is built once in ``__init__``; per block only the *selection* of
        sample expressions changes — a check's sample is included only while it
        still needs rows (``_needs_sample``). Produces: the block row count
        (``rows``); per check its error count (``count:{i}``) and, while needed, its
        sample (``sample:{i}``); and per column its failing-row count (``colfail:{col}``).
        """
        samples = [self._sample_exprs[i] for i in range(len(self._flat)) if self._needs_sample[i]]
        return [self._rows_expr, *self._count_exprs, *samples, *self._colfail_exprs]

    def _sample_expr(self, i: int) -> pl.Expr:
        """A bounded ``(line, value)`` sample for check ``i``, pulled in one filter.

        Lines are 1-based within the block (``ROW_IDX + 1``); ``_collect_sample``
        later shifts them by the block offset. ``head(sample_size)`` caps the count
        and ``implode`` packs the pairs into a single result cell.
        """
        column = self._flat[i][0]
        pair = pl.struct(
            (pl.col(ROW_IDX) + 1).alias("line"),
            pl.col(column).cast(pl.Utf8).alias("value"),
        )
        return pair.filter(pl.col(f"m{i}")).head(self._sample_size).implode().alias(f"sample:{i}")

    @staticmethod
    def _colfail_expr(column: str, indices: list[int]) -> pl.Expr:
        """Count of rows failing at least one of the column's checks.

        ``any_horizontal`` OR-s the column's masks per row, so a row failing two
        checks still counts once — this is what distinguishes failing *rows* from
        the total error count.
        """
        return pl.any_horizontal([pl.col(f"m{k}") for k in indices]).sum().alias(f"colfail:{column}")

    # -- accumulation across blocks -----------------------------------------

    def _accumulate(self, row: dict, offset: int) -> None:
        """Fold one block's aggregate row into the running counts and samples."""
        for i in range(len(self._flat)):
            self._counts[i] += int(row[f"count:{i}"] or 0)
            if self._needs_sample[i]:
                self._collect_sample(i, row, offset)
        for column in self._colfail:
            self._colfail[column] += int(row[f"colfail:{column}"] or 0)

    def _collect_sample(self, i: int, row: dict, offset: int) -> None:
        """Append this block's sample rows for check ``i``, up to ``sample_size``.

        Stops early once the sample is full and clears ``_needs_sample[i]`` so the
        check's sample is no longer computed on later blocks. Block-local line
        numbers are made file-absolute by adding ``offset``.
        """
        for pair in row[f"sample:{i}"] or []:
            if len(self._samples[i]) >= self._sample_size:
                self._needs_sample[i] = False
                return
            value = pair["value"]
            self._samples[i].append((offset + int(pair["line"]), value if value is not None else ""))

    def _assemble(self) -> list[ColumnData]:
        """Group per-check results back under their column, preserving schema order.

        Walks ``_col_indices`` (schema-ordered) and, for each column, gathers its
        checks' names, counts and samples into ``CheckData`` alongside the column's
        failing-row count.
        """
        return [
            (col, self._colfail[col],
             [(self._flat[i][1].check, self._counts[i], self._samples[i]) for i in idxs])
            for col, idxs in self._col_indices.items()
        ]
