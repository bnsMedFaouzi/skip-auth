"""End-to-end and per-check validation tests."""

from pathlib import Path

import polars as pl
import pytest

from csv_validator import (
    validate, EngineConfig, default_registry, ConstraintValidator,
    JsonSchemaParser, CsvDataSource, ValidationEngine,
)

EXAMPLE = Path(__file__).parent.parent / "example"


def test_end_to_end_example():
    report = validate(EXAMPLE / "passive_sr_schema.json", EXAMPLE / "sample_data.csv")
    assert report.status == "INVALID"
    assert report.rows_checked == 6
    checks = {(r.column, r.check) for r in report.results}
    assert ("PassSROrigin", "mandatory") in checks
    assert ("ExtractionTS", "type:timestamp") in checks
    assert ("Ccy", "pattern") in checks


def test_report_is_json_serializable():
    report = validate(EXAMPLE / "passive_sr_schema.json", EXAMPLE / "sample_data.csv")
    assert '"status"' in report.model_dump_json()


def _run(schema, rows):
    import tempfile, os
    f = tempfile.NamedTemporaryFile("w", suffix=".csv", delete=False)
    f.write(rows); f.close()
    try:
        return validate(schema, f.name)
    finally:
        os.unlink(f.name)


def test_mandatory_and_type():
    schema = {"properties": {"A": {"type": "number", "ColumnIndex": 1, "Mandatory": "Yes"}}}
    r = _run(schema, "A\n1\n\nx\n")
    checks = {r_.check: r_.error_count for r_ in r.results}
    assert checks["mandatory"] == 1      # empty row
    assert checks["type:number"] == 1    # "x"


def test_extensibility_custom_rule():
    class MaxValue(ConstraintValidator):
        name = "max_value"
        def applies(self, col):
            return col.attr("MaxValue") is not None
        def invalid_expr(self, col):
            return pl.col(col.name).cast(pl.Utf8).cast(pl.Float64, strict=False) > float(col.attr("MaxValue"))

    import tempfile, os
    schema = {"properties": {"S": {"type": "number", "MaxValue": 100, "ColumnIndex": 1}}}
    f = tempfile.NamedTemporaryFile("w", suffix=".csv", delete=False)
    f.write("S\n50\n150\n"); f.close()
    try:
        reg = default_registry().register(MaxValue())
        eng = ValidationEngine(JsonSchemaParser(schema), CsvDataSource(f.name), registry=reg)
        report = eng.validate()
    finally:
        os.unlink(f.name)
    assert any(r.check == "max_value" and r.error_count == 1 for r in report.results)
