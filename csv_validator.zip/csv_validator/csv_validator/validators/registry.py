"""Validator registry — the extension point."""

from __future__ import annotations

from ..models.column import ColumnDef
from ..models.check import BoundCheck
from .base import Validator
from .constraints import CONSTRAINT_VALIDATORS, MandatoryValidator
from .types import TYPE_VALIDATORS


class ValidatorRegistry:
    """Holds validators and yields the checks applicable to a column."""

    def __init__(self) -> None:
        self._validators: list[Validator] = []

    def register(self, validator: Validator) -> "ValidatorRegistry":
        self._validators.append(validator)
        return self

    def checks_for(self, col: ColumnDef) -> list[BoundCheck]:
        return [
            BoundCheck(col.name, v.check_name(col), v.build(col))
            for v in self._validators
            if v.applies(col)
        ]


def default_registry() -> ValidatorRegistry:
    """Registry with the built-in validators (mandatory + type + constraints)."""
    registry = ValidatorRegistry()
    registry.register(MandatoryValidator())
    for cls in (*TYPE_VALIDATORS, *CONSTRAINT_VALIDATORS):
        registry.register(cls())
    return registry
