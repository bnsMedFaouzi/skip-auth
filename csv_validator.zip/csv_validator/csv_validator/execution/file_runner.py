"""File-level validation runner: structure (header) + gate checks + metrics.

Responsible for the file's *structure* — not column values (those live in
`ColumnRunner`). It runs the built-in header comparison together with any extra
`FileCheck` gate rules, decides overall structural validity, and assembles the
`FileMetrics`. Future whole-file checks (encoding, delimiter, declared type) are
added simply as more `FileCheck`s.
"""

from __future__ import annotations

from ..models import ColumnDef, EngineConfig, FileMetrics
from ..validators.gate import FileCheck, StructureResult
from ..validators.structure import HeaderStructure


class FileRunner:
    """Runs the file structure checks (header + extra gate checks) and builds metrics."""

    def __init__(self, config: EngineConfig, structure_checks: list[FileCheck] | None = None) -> None:
        self._config = config
        self._header = HeaderStructure()
        self._checks: list[FileCheck] = list(structure_checks or [])

    def check_structure(self, columns: list[ColumnDef], actual: list[str]) -> StructureResult:
        """Validate the file structure: header comparison, then the extra gate checks.

        The header comparison yields the detailed missing/unexpected/order data;
        the gate checks add free-form issue messages. The file is structurally
        valid only when the header lines up AND no gate check reports an issue.
        """
        missing, unexpected, order_ok = self._header.compare(columns, actual, self._config)

        expected = [c.name for c in columns]
        issues = [msg for check in self._checks
                  if (msg := check.violation(expected, actual, self._config)) is not None]

        valid = (
            not missing
            and (self._config.allow_extra_columns or not unexpected)
            and order_ok
            and not issues
        )
        return StructureResult(missing=missing, unexpected=unexpected, order_ok=order_ok,
                               issues=issues, valid=valid)

    def metrics(
        self,
        *,
        rows: int,
        expected: int,
        present: int,
        structure: StructureResult,
        total_errors: int,
        stopped_at: str | None = None,
    ) -> FileMetrics:
        """Produce the file-level metrics from the structure result + the pass results."""
        return FileMetrics(
            rows=rows,
            columns_expected=expected,
            columns_present=present,
            missing_columns=structure.missing,
            unexpected_columns=structure.unexpected,
            order_ok=structure.order_ok,
            structure_valid=structure.valid,
            structure_issues=structure.issues,
            stopped_at=stopped_at,
            total_errors=total_errors,
        )
