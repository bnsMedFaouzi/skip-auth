"""CSV data source (bounded-memory, block-by-block)."""

from __future__ import annotations

import io
import itertools
import logging
from collections.abc import Iterator
from pathlib import Path

import polars as pl

from .base import DataSource

logger = logging.getLogger(__name__)


class CsvDataSource(DataSource):
    """CSV file read in row blocks, every column as text.

    Each block is a small lazy scan collected by the caller, so peak memory
    depends on the block size, not the file size. Reading as text avoids implicit
    conversions and enables faithful lexical validation.

    The CSV dialect (`separator`) is set once and shared by every
    read, so the header scan and the block scans can never disagree on the schema.

    Note: blocks are split on physical newlines; this assumes fields do not
    contain embedded newlines (true for the target inventory files).
    """

    def __init__(self, path: str | Path, *, separator: str = ",") -> None:
        self._path = Path(path)
        self._separator = separator
        self._header: list[str] | None = None
        self._columns: list[str] | None = None
        self._trailing_empty: bool | None = None

    def _scan(self, source) -> pl.LazyFrame:
        """A lazy scan with the shared dialect: every column as text, no inference.

        `infer_schema_length=0` reads names/values without a type-inference row
        scan (never use None here — that scans the whole file into memory).
        `null_values=[]` coerces nothing to null, so empty cells stay "" (the
        completeness check owns emptiness; values are never silently dropped).
        """
        return pl.scan_csv(
            source,
            separator=self._separator,
            infer_schema_length=0,
            null_values=[],
            low_memory=True,
        )

    def _raw_columns(self) -> list[str]:
        """The CSV header exactly as written (may include a trailing empty column)."""
        if self._header is None:
            self._header = self._scan(self._path).collect_schema().names()
        return self._header

    def columns(self) -> list[str]:
        """The logical columns to validate.

        A trailing separator produces an empty-named last column; it is detected
        and dropped here so it is not validated as a real column. If none is
        present, a warning is logged.
        """
        if self._columns is None:
            raw = list(self._raw_columns())
            self._trailing_empty = bool(raw) and raw[-1].strip() == ""
            self._columns = raw[:-1] if self._trailing_empty else raw
            if not self._trailing_empty:
                logger.warning("No trailing empty column found (expected a trailing separator).")
        return self._columns

    def iter_frames(self, batch_size: int) -> Iterator[pl.LazyFrame]:
        """Yield the data as lazy scans of `batch_size` rows, trailing empty column excluded."""
        keep = self.columns()  # logical columns (a trailing empty column is excluded)
        with open(self._path, "rb") as fh:
            header = fh.readline()
            while True:
                lines = list(itertools.islice(fh, batch_size))
                if not lines:
                    break
                # Lazy scan of this N-line block; the caller adds its expressions
                # and collects once. `select(keep)` drops the trailing empty column.
                # Boundedness comes from slicing to N lines here, not the reader.
                yield self._scan(io.BytesIO(header + b"".join(lines))).select(keep)
