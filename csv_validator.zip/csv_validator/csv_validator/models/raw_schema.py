"""Pydantic models of the *raw* JSON schema (edge validation).

Validating the incoming schema here gives coercion, field aliases, defaults, and
clear error messages pointing at the offending column.

Note on the real schema conventions:
- properties reference named types through the `type` field (e.g. "type":
  "Currency"), not only through `$ref` (handled in the parser).
- decimal precision uses `TotalDigits`/`FractionDigits` (in definitions) and
  `TotalDigit`/`FractionDigit` (in properties) — both spellings accepted below.
"""

from __future__ import annotations

from pydantic import AliasChoices, BaseModel, ConfigDict, Field


class PropertySchema(BaseModel):
    """Shape of one entry (property or definition), after type/$ref resolution."""

    model_config = ConfigDict(populate_by_name=True, extra="allow")

    type: str = "string"
    size: int | None = Field(None, alias="Size")
    mandatory: str = Field("No", alias="Mandatory")
    authorize_value: list[str] | None = Field(None, alias="AuthorizeValue")
    enum: list[str] | None = None
    column_index: int | None = Field(None, alias="ColumnIndex")
    pattern: str | None = None
    minimum: float | None = None
    # accept plural (definitions) and singular (properties), tolerate float typos
    total_digits: float | None = Field(
        None, validation_alias=AliasChoices("TotalDigits", "TotalDigit", "total_digits")
    )
    fraction_digits: float | None = Field(
        None, validation_alias=AliasChoices("FractionDigits", "FractionDigit", "fraction_digits")
    )
    date_format: str | None = Field(
        None, validation_alias=AliasChoices("Format", "DateFormat", "date_format")
    )
    information_item: str | None = Field(None, alias="InformationItem")


class RawSchema(BaseModel):
    """Top level of the JSON schema."""

    model_config = ConfigDict(populate_by_name=True, extra="ignore")

    definitions: dict[str, dict] = Field(default_factory=dict)
    properties: dict[str, dict] = Field(default_factory=dict)
