"""Pydantic models of the *raw* JSON schema (edge validation).

Validating the incoming schema here gives coercion ("15" -> 15), field aliases
(`Size` -> `size`), defaults, and clear error messages pointing at the offending
column — instead of silent `dict.get()` failures deeper in the pipeline.
"""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field


class PropertySchema(BaseModel):
    """Shape of one entry under `properties` (after `$ref` resolution)."""

    model_config = ConfigDict(populate_by_name=True, extra="allow")

    type: str = "string"
    size: int | None = Field(None, alias="Size")
    mandatory: str = Field("No", alias="Mandatory")
    authorize_value: list[str] | None = Field(None, alias="AuthorizeValue")
    enum: list[str] | None = None
    column_index: int | None = Field(None, alias="ColumnIndex")
    pattern: str | None = None
    minimum: float | None = None
    information_item: str | None = Field(None, alias="InformationItem")


class RawSchema(BaseModel):
    """Top level of the JSON schema."""

    model_config = ConfigDict(populate_by_name=True, extra="ignore")

    definitions: dict[str, dict] = Field(default_factory=dict)
    properties: dict[str, dict] = Field(default_factory=dict)
