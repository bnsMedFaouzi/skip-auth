"""Tests for validators/registry.py: extensibility hooks."""

import polars as pl

from csv_validator import (
    Constraint, CsvDataSource, GatedValidator, JsonSchemaParser, ValidationEngine, default_registry,
)


def _run(schema, rows, reg, tmp_file, checks):
    report = ValidationEngine(JsonSchemaParser(schema), CsvDataSource(tmp_file(rows)),
                              registry=reg).validate()
    return checks(report)


def test_fold_custom_constraint_into_type_check(tmp_file, checks):
    class MaxValue(Constraint):
        def applies(self, col):
            return col.attr("MaxValue") is not None
        def mask(self, col):
            return pl.col(col.name).cast(pl.Utf8).cast(pl.Float64, strict=False) > float(col.attr("MaxValue"))

    schema = {"properties": {"S": {"type": "number", "MaxValue": 100, "ColumnIndex": 1}}}
    reg = default_registry().add_constraint("number", MaxValue())
    c = _run(schema, "S\n50\n150\n", reg, tmp_file, checks)
    assert c[("S", "type:number")] == 1                    # 150 > 100, folded into the type check


def test_register_separate_validator(tmp_file, checks):
    class NotFortyTwo(GatedValidator):
        name = "not_42"
        def applies(self, col):
            return col.type == "integer"
        def invalid_expr(self, col):
            return pl.col(col.name).cast(pl.Utf8) == "42"

    schema = {"properties": {"N": {"type": "integer", "ColumnIndex": 1}}}
    reg = default_registry().register(NotFortyTwo())
    c = _run(schema, "N\n1\n42\n", reg, tmp_file, checks)
    assert c[("N", "not_42")] == 1
