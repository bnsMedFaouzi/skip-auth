# csv_validator

Validate a CSV against a JSON schema. Built-in checks: **value type** and
**mandatory**. Designed to stay **extensible** — new rules (declared in the JSON
schema) are added without touching the engine.

- **Pydantic** validates the incoming schema (clear errors) and models the report.
- **Polars** runs all data checks in a single **streaming** pass.
- Object-oriented, pattern-based, layered.

## Install

```bash
pip install polars pydantic     # + pytest to run the tests
```

## Usage

```python
from csv_validator import validate, EngineConfig

report = validate("schema.json", "data.csv", config=EngineConfig(sample_size=20))
print(report.to_text())
print(report.model_dump_json(indent=2))   # report is a Pydantic model
```

CLI:

```bash
python -m csv_validator schema.json data.csv          # text report
python -m csv_validator schema.json data.csv --json   # JSON report
# exit code 0 if VALID, 1 if INVALID
```

Several files concurrently (event loop — Polars releases the GIL, passes run in parallel):

```python
from csv_validator import validate_many
reports = validate_many([("schema.json", "a.csv"), ("schema.json", "b.csv")])
```

## Layers

```
csv_validator/
  models/       # data structures (Pydantic where it adds value)
    column.py       ColumnDef (+ attributes: hook for future rules)
    config.py       EngineConfig
    raw_schema.py   PropertySchema, RawSchema — validate incoming JSON
    check.py        BoundCheck (holds a Polars expr)
    report.py       CheckResult, ValidationReport, ReportBuilder
  sources/      # data input (DataSource strategy) — CsvDataSource
  schema/       # schema parsing (SchemaParser strategy) — JsonSchemaParser
  validators/   # the checks (Strategy + Registry)
  execution/    # runner.py (single streaming pass) + engine.py (Facade)
  __main__.py   # CLI
tests/          # pytest
```

## Design patterns

| Pattern | Where | Purpose |
|---------|-------|---------|
| Strategy | `Validator` subclasses, `SchemaParser`, `DataSource` | interchangeable implementations |
| Template Method | `GatedValidator` | shared "non-empty cells only" logic |
| Registry | `ValidatorRegistry` | the extension point |
| Facade | `ValidationEngine`, `validate()` | one entry point |
| Builder | `ReportBuilder` | assembles the report |
| Pydantic models | `models/` | validate the schema, serialize the report |

## Performance

All checks run in **one streaming pass**: the row count, per-check error counts,
and bounded per-check samples are computed together in a single Polars `collect`
(each per-check expression reduces to a length-1 cell). No re-scan per check.
The `validate_many` API uses the asyncio event loop to run multiple files' passes
concurrently.

## Extend

Two ways, both without touching the engine.

**A future rule declared in the JSON.** New schema fields flow into
`col.attributes`; a validator reads them:

```python
import polars as pl
from csv_validator import ConstraintValidator, default_registry, validate

class MaxValueConstraint(ConstraintValidator):
    name = "max_value"
    def applies(self, col):
        return col.attr("MaxValue") is not None
    def invalid_expr(self, col):
        return pl.col(col.name).cast(pl.Utf8).cast(pl.Float64, strict=False) > float(col.attr("MaxValue"))

registry = default_registry().register(MaxValueConstraint())
report = validate("schema.json", "data.csv", registry=registry)
```

Add `"MaxValue": 100` to a column in the JSON and it is enforced. No parser,
model, or engine change.

**A new type.** Subclass `TypeValidator`, set `handles`, register it.

## Checks active by default

| Check | Triggered by |
|-------|--------------|
| `mandatory` | `Mandatory: "Yes"` |
| `type:*` (string/number/integer/timestamp/date/boolean) | `type` |
| `enum` | `AuthorizeValue` / `enum` |
| `length` | `Size` |
| `minimum` | `minimum` |
| `pattern` | `pattern` |

Type and mandatory are the requested core; the others illustrate the extension
mechanism and are removed by building a custom registry instead of `default_registry()`.

## Tests

```bash
pytest -q
```
