"""Data source abstraction (Strategy pattern).

The engine does not know where the data comes from. A concrete `DataSource`
exposes the columns and a lazy Polars frame. Adding a new backend (Parquet, an
object-store stream, etc.) means adding a subclass; the engine is untouched.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from pathlib import Path

import polars as pl


class DataSource(ABC):
    """Abstract source of tabular data."""

    @abstractmethod
    def columns(self) -> list[str]:
        """Return the column names, in order."""

    @abstractmethod
    def frame(self) -> pl.LazyFrame:
        """Return a lazy Polars frame with all columns as text (Utf8)."""


class CsvDataSource(DataSource):
    """CSV file read lazily, every column as text.

    Reading as text avoids implicit conversions and enables faithful lexical
    validation (dates, long decimals) while staying streaming-friendly.
    """

    def __init__(self, path: str | Path) -> None:
        self._path = Path(path)
        self._columns: list[str] | None = None

    def columns(self) -> list[str]:
        if self._columns is None:
            self._columns = pl.read_csv(self._path, n_rows=0).columns
        return self._columns

    def frame(self) -> pl.LazyFrame:
        overrides = {c: pl.Utf8 for c in self.columns()}
        return pl.scan_csv(self._path, schema_overrides=overrides, infer_schema_length=0)
