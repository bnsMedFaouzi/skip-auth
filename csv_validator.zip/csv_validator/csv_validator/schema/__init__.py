"""Schema parsing: the SchemaParser strategy and its implementations."""

from .base import SchemaParser
from .json_parser import JsonSchemaParser

__all__ = ["SchemaParser", "JsonSchemaParser"]
