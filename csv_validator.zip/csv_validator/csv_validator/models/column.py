"""Normalized column definition — a schema property plus a name."""

from __future__ import annotations

from typing import Any

from pydantic import field_validator

from .raw_schema import PropertySchema

# Primitive type tokens; any other `type` value names a definition to resolve.
_TYPE_ALIASES = {
    "str": "string", "text": "string",
    "int": "integer", "integer": "integer",
    "number": "number", "decimal": "number", "float": "number", "double": "number",
    "timestamp": "timestamp", "datetime": "timestamp",
    "date": "date", "boolean": "boolean", "bool": "boolean",
}
PRIMITIVES = set(_TYPE_ALIASES) | {"string"}


class ColumnDef(PropertySchema):
    """A validated column: every `PropertySchema` field, plus a `name`.

    Its `type` is normalized to a canonical primitive. Unknown schema fields are
    kept (extra='allow') and read via `attr(...)`, so a future rule needs no
    change here.
    """

    name: str

    @field_validator("type", mode="after")
    @classmethod
    def _normalize_type(cls, value: str) -> str:
        """Map a primitive type token to its canonical form (Timestamp->timestamp)."""
        token = (value or "string").lower()
        return _TYPE_ALIASES.get(token, token)

    def attr(self, key: str, default: Any = None) -> Any:
        """Read a raw schema attribute kept from the source (for future rules)."""
        return (self.model_extra or {}).get(key, default)
