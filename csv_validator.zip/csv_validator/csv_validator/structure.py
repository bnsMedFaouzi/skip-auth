"""File-structure validation (the header), separate from column validators.

The header is checked on the list of column *names* (before touching the data),
because it is a structural, gate-level concern: if the columns are wrong or
misordered, validating values makes no sense.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from .models import ColumnDef, EngineConfig


@dataclass
class HeaderResult:
    """Outcome of the header check: missing/extra columns, order, and validity."""

    missing: list[str] = field(default_factory=list)      # schema cols absent from CSV
    unexpected: list[str] = field(default_factory=list)   # CSV cols absent from schema
    order_ok: bool = True
    valid: bool = True


class HeaderValidator:
    """Compares the CSV header to the schema columns."""

    def check(
        self,
        columns: list[ColumnDef],
        actual: list[str],
        config: EngineConfig,
    ) -> HeaderResult:
        """Compare the CSV header to the schema columns (presence, order, extras)."""
        expected = [c.name for c in columns]           # already sorted by order
        expected_set, actual_set = set(expected), set(actual)

        missing = [c for c in expected if c not in actual_set]
        unexpected = [c for c in actual if c not in expected_set]

        # Order is only meaningful once the sets line up.
        order_ok = True
        if config.strict_column_order and not missing and (config.allow_extra_columns or not unexpected):
            common_actual = [c for c in actual if c in expected_set]
            order_ok = common_actual == expected

        valid = (
            not missing
            and (config.allow_extra_columns or not unexpected)
            and order_ok
        )
        return HeaderResult(missing=missing, unexpected=unexpected, order_ok=order_ok, valid=valid)
