"""Tests for models/config.py: operational fields."""

from csv_validator import EngineConfig


def test_engine_mode_follows_streaming():
    assert EngineConfig(streaming=True).engine_mode == "streaming"
    assert EngineConfig(streaming=False).engine_mode == "auto"


def test_operational_fields_configurable():
    cfg = EngineConfig(target_memory_mb=1000, safety_margin=0.3, default_string_bytes=128)
    assert (cfg.target_memory_mb, cfg.safety_margin, cfg.default_string_bytes) == (1000, 0.3, 128)
