"""Example run.

    python run_example.py
"""

from pathlib import Path

from csv_validator import validate, EngineConfig

HERE = Path(__file__).parent
SCHEMA = HERE / "example" / "passive_sr_schema.json"
CSV = HERE / "example" / "sample_data.csv"


def main() -> None:
    report = validate(SCHEMA, CSV, config=EngineConfig(sample_size=20))
    print(report.to_text())


if __name__ == "__main__":
    main()
