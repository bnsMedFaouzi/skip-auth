"""Data source abstraction (Strategy)."""

from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import Iterator

import polars as pl

from ..models.config import _BASELINE_MB, _MB_PER_UNIT


class DataSource(ABC):
    """Abstract source of tabular data."""

    @abstractmethod
    def columns(self) -> list[str]:
        """Return the column names, in order."""

    @abstractmethod
    def iter_frames(self, batch_size: int) -> Iterator[pl.LazyFrame]:
        """Yield the data as lazy frames of `batch_size` rows (all columns as text).

        Each block is a small, independent lazy scan: the caller adds its
        expressions and collects once, so only the aggregated result is
        materialized and peak memory stays bounded regardless of file size.
        """

    def batch_for(self, columns, config) -> int:
        """Rows per batch so the predicted peak stays under the (margined) target.

        Sums each column's weight (its max cell width + its check masks) into the
        per-row weight W, then inverts the linear memory model. `row_batch_size`
        overrides. Clamped to [min_batch, max_batch].
        """
        if config.row_batch_size is not None:
            return config.row_batch_size
        weight = sum(col.weight(config) for col in columns) or 1.0
        target = config.target_memory_mb * (1.0 - config.safety_margin)
        budget = max(target - _BASELINE_MB, 1.0)
        rows = int(budget / (_MB_PER_UNIT * weight))
        return max(config.min_batch, min(rows, config.max_batch))

    @staticmethod
    def estimated_peak_mb(batch_rows: int, row_weight: float) -> float:
        """Predicted peak memory (MB) for a given batch and per-row weight."""
        return _BASELINE_MB + _MB_PER_UNIT * batch_rows * row_weight
