"""CSV validation engine driven by a JSON schema.

Layered, object-oriented, pattern-based (Strategy, Template Method, Registry,
Facade, Builder). Pydantic validates the incoming schema and models the report;
Polars runs the column-wise checks in a streaming, event-loop-parallel engine.

Layers:
  models/      data structures (Pydantic where it adds value)
  sources/     data input (DataSource strategy)
  schema/      schema parsing (SchemaParser strategy)
  validators/  the checks (Strategy + Registry)
  execution/   orchestration (Runner + ValidationEngine facade)
"""

from .models import (
    ColumnDef, EngineConfig, PropertySchema, RawSchema, BoundCheck,
    CheckResult, ValidationReport, ReportBuilder,
)
from .sources import DataSource, CsvDataSource
from .schema import SchemaParser, JsonSchemaParser
from .validators import (
    Validator, GatedValidator, TypeValidator, ConstraintValidator,
    MandatoryValidator, ValidatorRegistry, default_registry,
)
from .execution import (
    Runner, ValidationEngine,
    validate, validate_async, validate_many, validate_many_async,
)

__all__ = [
    # models
    "ColumnDef", "EngineConfig", "PropertySchema", "RawSchema", "BoundCheck",
    "CheckResult", "ValidationReport", "ReportBuilder",
    # sources / schema
    "DataSource", "CsvDataSource", "SchemaParser", "JsonSchemaParser",
    # validators
    "Validator", "GatedValidator", "TypeValidator", "ConstraintValidator",
    "MandatoryValidator", "ValidatorRegistry", "default_registry",
    # execution
    "Runner", "ValidationEngine",
    "validate", "validate_async", "validate_many", "validate_many_async",
]
