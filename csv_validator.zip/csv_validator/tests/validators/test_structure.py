"""Tests for validators/structure.py: header comparison + pluggable checks."""

from csv_validator import (
    CsvDataSource, EngineConfig, HeaderValidator, JsonSchemaParser,
    MaxColumns, StructureCheck, ValidationEngine,
)


def test_missing_column_gates(run_csv):
    schema = {"properties": {
        "A": {"type": "string", "ColumnIndex": 1, "Mandatory": "Yes"},
        "B": {"type": "string", "ColumnIndex": 2, "Mandatory": "No"},
    }}
    report = run_csv(schema, "A\nx\n")                      # B missing
    assert report.status == "INVALID_STRUCTURE"
    assert report.file.stopped_at == "header"
    assert "B" in report.file.missing_columns


def test_extra_column_flagged(run_csv):
    schema = {"properties": {"A": {"type": "string", "ColumnIndex": 1, "Mandatory": "No"}}}
    report = run_csv(schema, "A;Z\nx;1\n")                  # Z is extra
    assert "Z" in report.file.unexpected_columns
    assert report.file.structure_valid is False


def test_order_mismatch(run_csv):
    schema = {"properties": {
        "A": {"type": "string", "ColumnIndex": 1, "Mandatory": "No"},
        "B": {"type": "string", "ColumnIndex": 2, "Mandatory": "No"},
    }}
    report = run_csv(schema, "B;A\n1;2\n")                  # wrong order
    assert report.file.order_ok is False
    assert report.status == "INVALID_STRUCTURE"


def test_extra_column_tolerated_when_configured(run_csv):
    schema = {"properties": {"A": {"type": "string", "ColumnIndex": 1, "Mandatory": "No"}}}
    report = run_csv(schema, "A;Z\nx;1\n", allow_extra_columns=True)
    assert report.file.structure_valid is True
    assert "Z" in report.file.unexpected_columns


# --- extensibility ---------------------------------------------------------- #

def test_max_columns_check_direct():
    cols = JsonSchemaParser({"properties": {"a": {"type": "string", "ColumnIndex": 1}}}).parse()
    result = HeaderValidator([MaxColumns(2)]).check(cols, ["a", "b", "c"], EngineConfig())
    assert result.valid is False
    assert any("too many columns" in msg for msg in result.issues)


def test_custom_structure_check_gates_engine(tmp_file):
    class RejectAll(StructureCheck):
        name = "reject_all"
        def violation(self, expected, actual, config):
            return "rejected by policy"

    schema = {"properties": {"a": {"type": "number", "ColumnIndex": 1}}}
    csv = tmp_file("a\n1\n")
    report = ValidationEngine(JsonSchemaParser(schema), CsvDataSource(csv),
                              structure_checks=[RejectAll()]).validate()
    assert report.status == "INVALID_STRUCTURE"
    assert "rejected by policy" in report.file.structure_issues


def test_add_chaining_and_no_issue_when_clean():
    cols = JsonSchemaParser({"properties": {"a": {"type": "string", "ColumnIndex": 1}}}).parse()
    validator = HeaderValidator().add(MaxColumns(10))              # chained registration
    result = validator.check(cols, ["a"], EngineConfig())          # under the limit
    assert result.valid is True
    assert result.issues == []
