"""Engine configuration (Pydantic)."""

from __future__ import annotations

from pydantic import BaseModel


class EngineConfig(BaseModel):
    """Centralized engine parameters."""

    sample_size: int = 20            # bounded error sample per check
    streaming: bool = True           # use the Polars streaming engine

    # header / file structure
    strict_column_order: bool = True     # columns must match the schema order
    header_gate: bool = True             # invalid header stops value validation
    allow_extra_columns: bool = False    # tolerate CSV columns not in the schema

    # default date/timestamp formats, used when a column does not provide one
    default_date_format: str = "%Y-%m-%d"
    default_timestamp_format: str = "%Y-%m-%dT%H:%M:%S"

    # Rows per batch: bounds peak memory (a batch is evaluated then discarded).
    # Leave as None to size it automatically from the column count so peak memory
    # stays near `target_memory_mb` whatever the schema width; set an int to force it.
    row_batch_size: int | None = None
    target_memory_mb: int = 300          # memory budget used when auto-sizing the batch

    # Peak-memory model (calibrate on a real file — see benchmarks):
    #   peak_mb ~= baseline_mb + bytes_per_cell * rows * (columns + checks)
    # (columns + checks) is the in-flight Series count: one Utf8 column each, plus
    # one boolean mask per check. The auto batch is clamped to [min_batch, max_batch].
    baseline_mb: float = 60          # interpreter + Polars + one small block
    bytes_per_cell: float = 55       # per (row x series) at peak: Utf8 cell / bool mask + intermediates
    min_batch: int = 5_000           # keep some batching efficiency on very wide schemas
    max_batch: int = 200_000         # cap on very narrow schemas

    @property
    def engine_mode(self) -> str:
        """The Polars collect engine: streaming when enabled, else auto."""
        return "streaming" if self.streaming else "auto"

    def batch_for(self, num_columns: int, num_checks: int = 0) -> int:
        """Rows per batch for a schema of `num_columns` columns and `num_checks`
        total checks across those columns.

        Returns `row_batch_size` if set. Otherwise sizes the batch so peak memory
        stays near `target_memory_mb`. Peak grows with the number of in-flight
        Series — the text columns plus one boolean mask per check — so the row
        count is scaled down by (columns + checks), not columns alone. Clamped.
        """
        if self.row_batch_size is not None:
            return self.row_batch_size
        series = max(num_columns + num_checks, 1)
        budget_bytes = max(self.target_memory_mb - self.baseline_mb, 50) * 1_000_000
        rows = int(budget_bytes / (self.bytes_per_cell * series))
        return max(self.min_batch, min(rows, self.max_batch))
