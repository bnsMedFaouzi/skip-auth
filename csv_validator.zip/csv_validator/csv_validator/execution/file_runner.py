"""File-level validation runner: owns and runs the structure checks, builds metrics.

Responsible for the file's *structure* — not column values (those live in
`ColumnRunner`). It owns the list of `StructureCheck`s to run (the header is one
of them), aggregates their issues into a `StructureResult`, and assembles the
`FileMetrics`. New whole-file checks are added to `_checks` — nothing is injected
from the engine.
"""

from __future__ import annotations

from ..models import ColumnDef, EngineConfig, FileMetrics
from ..validators.structure import HeaderCheck, StructureCheck, StructureResult


class FileRunner:
    """Owns the file-structure checks, runs them, and builds the file metrics."""

    def __init__(self, config: EngineConfig, checks: list[StructureCheck] | None = None) -> None:
        self._config = config
        # FileRunner knows which checks to run; the header is just the first one.
        self._checks: list[StructureCheck] = checks if checks is not None else [HeaderCheck()]

    def check_structure(self, columns: list[ColumnDef], actual: list[str]) -> StructureResult:
        """Run every structure check and collect their issues into one result."""
        issues: list[str] = []
        for check in self._checks:
            issues.extend(check.check(columns, actual, self._config))
        return StructureResult(issues=issues)

    def metrics(
        self,
        *,
        rows: int,
        expected: int,
        present: int,
        structure: StructureResult,
        total_errors: int,
        stopped_at: str | None = None,
    ) -> FileMetrics:
        """Produce the file-level metrics from the structure result + the pass results."""
        return FileMetrics(
            rows=rows,
            columns_expected=expected,
            columns_present=present,
            structure_valid=structure.valid,
            structure_issues=structure.issues,
            stopped_at=stopped_at,
            total_errors=total_errors,
        )
