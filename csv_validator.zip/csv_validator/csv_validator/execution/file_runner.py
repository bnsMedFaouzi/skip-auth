"""File-level metrics, accumulated block by block."""

from __future__ import annotations

import polars as pl

from .runner import BlockProcessor


class FileRunner(BlockProcessor):
    """Accumulates file-wide facts. For now: the total row count.

    A new file-level metric (e.g. a duplicate-row count) would extend this
    processor without touching column validation.
    """

    def __init__(self) -> None:
        self._rows = 0

    def update(self, block: pl.DataFrame, offset: int) -> None:
        self._rows += block.height

    def result(self) -> int:
        return self._rows
