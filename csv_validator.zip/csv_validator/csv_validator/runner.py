"""Runner: evaluates checks on the LazyFrame (each method a blocking collect).

Kept separate from the engine so the primitives can be dispatched concurrently
on the event loop.
"""

from __future__ import annotations

import polars as pl

from .validators import BoundCheck

ROW_IDX = "__row__"


class Runner:
    """Low-level Polars execution primitives."""

    @staticmethod
    def count_rows(lf: pl.LazyFrame) -> int:
        return int(lf.select(pl.len()).collect(engine="streaming").item())

    @staticmethod
    def count_invalids(lf: pl.LazyFrame, checks: list[BoundCheck]) -> tuple:
        count_cols = [
            chk.invalid.fill_null(False).sum().alias(str(i))
            for i, chk in enumerate(checks)
        ]
        return lf.select(count_cols).collect(engine="streaming").row(0)

    @staticmethod
    def collect_sample(
        lf: pl.LazyFrame, chk: BoundCheck, sample_size: int
    ) -> list[tuple[int, str]]:
        sample_df = (
            lf.with_row_index(ROW_IDX)
            .filter(chk.invalid.fill_null(False))
            .select(
                (pl.col(ROW_IDX) + 1).alias("line"),   # 1 = first data row
                pl.col(chk.column).cast(pl.Utf8).alias("value"),
            )
            .head(sample_size)
            .collect(engine="streaming")
        )
        return [
            (int(r["line"]), r["value"] if r["value"] is not None else "")
            for r in sample_df.to_dicts()
        ]
