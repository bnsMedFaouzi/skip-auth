"""Runner: Polars execution in a single streaming pass.

`run()` computes, in ONE collect over the file: the row count, and per check the
error count plus a bounded sample of (line, value). Each per-check expression
reduces to a length-1 cell (an aggregate or a bounded imploded list), so they all
fit in a single result row — one scan instead of one-per-check.
"""

from __future__ import annotations

import polars as pl

from ..models import BoundCheck

ROW_IDX = "__row__"

# (check, error_count, sample[list of (line, value)])
CheckOutcome = tuple[BoundCheck, int, list[tuple[int, str]]]


class Runner:
    @staticmethod
    def run(
        lf: pl.LazyFrame,
        checks: list[BoundCheck],
        sample_size: int,
        engine: str = "streaming",
    ) -> tuple[int, list[CheckOutcome]]:
        lf = lf.with_row_index(ROW_IDX)
        exprs: list[pl.Expr] = [pl.len().alias("rows")]
        for i, chk in enumerate(checks):
            inv = chk.invalid.fill_null(False)
            line = (pl.col(ROW_IDX) + 1).filter(inv).head(sample_size).implode()
            val = pl.col(chk.column).cast(pl.Utf8).filter(inv).head(sample_size).implode()
            exprs += [
                inv.sum().alias(f"cnt_{i}"),
                line.alias(f"line_{i}"),
                val.alias(f"val_{i}"),
            ]

        row = lf.select(exprs).collect(engine=engine).row(0, named=True)

        rows = int(row["rows"])
        outcomes: list[CheckOutcome] = []
        for i, chk in enumerate(checks):
            n = int(row[f"cnt_{i}"] or 0)
            if n == 0:
                continue
            lines = row[f"line_{i}"] or []
            values = row[f"val_{i}"] or []
            sample = [
                (int(ln), v if v is not None else "")
                for ln, v in zip(lines, values)
            ]
            outcomes.append((chk, n, sample))
        return rows, outcomes
