"""Validator abstractions (Strategy + Template Method) and the mandatory check."""

from __future__ import annotations

from abc import ABC, abstractmethod

import polars as pl

from ..models.column import ColumnDef


def non_empty(name: str) -> pl.Expr:
    """Mask of cells that are actually filled (not null, not blank)."""
    cell = pl.col(name)
    return cell.is_not_null() & (cell.cast(pl.Utf8).str.strip_chars() != "")


class Validator(ABC):
    """A validation strategy that emits one check for a column."""

    @abstractmethod
    def applies(self, col: ColumnDef) -> bool:
        """Whether this validator concerns the given column."""

    @abstractmethod
    def build(self, col: ColumnDef) -> pl.Expr:
        """Boolean mask, True where the cell is invalid."""

    def check_name(self, col: ColumnDef) -> str:
        """The reported name of this check (its `name`, else the class name)."""
        return getattr(self, "name", type(self).__name__)


class GatedValidator(Validator):
    """Template Method: the non-empty gate is applied once; subclasses only
    provide `invalid_expr` (evaluated as if the cell were filled)."""

    @abstractmethod
    def invalid_expr(self, col: ColumnDef) -> pl.Expr:
        """Invalid mask, assuming the cell is non-empty."""

    def build(self, col: ColumnDef) -> pl.Expr:
        """Gate the invalid mask so only non-empty cells can fail."""
        return non_empty(col.name) & self.invalid_expr(col)


class MandatoryValidator(Validator):
    """Completeness: a mandatory cell must not be empty. Its own check."""

    name = "mandatory"

    def applies(self, col: ColumnDef) -> bool:
        """Applies to columns declared mandatory."""
        return col.mandatory

    def build(self, col: ColumnDef) -> pl.Expr:
        """Invalid where a mandatory cell is empty."""
        return ~non_empty(col.name)
