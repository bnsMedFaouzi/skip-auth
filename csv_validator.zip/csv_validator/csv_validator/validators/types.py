"""Type validators (Strategy), keyed by base_type."""

from __future__ import annotations

import polars as pl

from ..models.column import ColumnDef
from .base import GatedValidator


class TypeValidator(GatedValidator):
    """Base for type validators. `handles` lists the base_types it covers."""

    handles: tuple[str, ...] = ()

    def applies(self, col: ColumnDef) -> bool:
        return col.base_type in self.handles

    def check_name(self, col: ColumnDef) -> str:
        return f"type:{col.base_type}"


class StringType(TypeValidator):
    handles = ("string", "text")

    def invalid_expr(self, col: ColumnDef) -> pl.Expr:
        # Any non-empty text is a valid string (length is a separate constraint).
        return pl.lit(False)


class NumberType(TypeValidator):
    handles = ("number", "decimal", "float", "double")

    def invalid_expr(self, col: ColumnDef) -> pl.Expr:
        return ~pl.col(col.name).cast(pl.Utf8).str.contains(r"^[+-]?\d+(\.\d+)?$")


class IntegerType(TypeValidator):
    handles = ("integer",)

    def invalid_expr(self, col: ColumnDef) -> pl.Expr:
        return ~pl.col(col.name).cast(pl.Utf8).str.contains(r"^[+-]?\d+$")


class TimestampType(TypeValidator):
    handles = ("timestamp", "datetime")

    def __init__(self, default_format: str = "%Y-%m-%dT%H:%M:%S") -> None:
        self._default_format = default_format

    def invalid_expr(self, col: ColumnDef) -> pl.Expr:
        fmt = col.date_format or self._default_format
        parsed = pl.col(col.name).cast(pl.Utf8).str.to_datetime(format=fmt, strict=False)
        return parsed.is_null()


class DateType(TypeValidator):
    handles = ("date",)

    def __init__(self, default_format: str = "%Y-%m-%d") -> None:
        self._default_format = default_format

    def invalid_expr(self, col: ColumnDef) -> pl.Expr:
        fmt = col.date_format or self._default_format
        parsed = pl.col(col.name).cast(pl.Utf8).str.to_date(format=fmt, strict=False)
        return parsed.is_null()


class BooleanType(TypeValidator):
    handles = ("boolean",)

    def invalid_expr(self, col: ColumnDef) -> pl.Expr:
        ok = pl.col(col.name).cast(pl.Utf8).str.to_lowercase().is_in(
            ["true", "false", "0", "1", "y", "n", "yes", "no"]
        )
        return ~ok


TYPE_VALIDATORS = (StringType, NumberType, IntegerType, TimestampType, DateType, BooleanType)
