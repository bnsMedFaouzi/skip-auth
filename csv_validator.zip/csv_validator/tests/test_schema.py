"""Schema parsing tests."""

import pytest

from csv_validator import JsonSchemaParser


def test_parse_basic_and_order():
    schema = {"properties": {
        "B": {"type": "string", "ColumnIndex": 2, "Mandatory": "No"},
        "A": {"type": "number", "ColumnIndex": 1, "Mandatory": "Yes"},
    }}
    cols = JsonSchemaParser(schema).parse()
    assert [c.name for c in cols] == ["A", "B"]      # sorted by ColumnIndex
    assert cols[0].mandatory is True
    assert cols[0].base_type == "number"


def test_ref_resolution():
    schema = {
        "definitions": {"Ccy": {"type": "string", "pattern": "^.{3}$"}},
        "properties": {"Currency": {"$ref": "#/definitions/Ccy", "ColumnIndex": 1}},
    }
    col = JsonSchemaParser(schema).parse()[0]
    assert col.base_type == "string"
    assert col.pattern == "^.{3}$"


def test_invalid_schema_raises_with_column_name():
    schema = {"properties": {"X": {"type": "string", "ColumnIndex": "not-an-int"}}}
    with pytest.raises(ValueError, match="column 'X'"):
        JsonSchemaParser(schema).parse()


def test_future_field_flows_into_attributes():
    schema = {"properties": {"X": {"type": "number", "MaxValue": 100, "ColumnIndex": 1}}}
    col = JsonSchemaParser(schema).parse()[0]
    assert col.attr("MaxValue") == 100
