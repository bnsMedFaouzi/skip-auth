"""End-to-end and per-check validation tests."""

from pathlib import Path

import polars as pl

from csv_validator import (
    validate, EngineConfig, default_registry, Constraint, GatedValidator,
    JsonSchemaParser, CsvDataSource, ValidationEngine,
)

EXAMPLE = Path(__file__).parent.parent / "example"


def _checks(report):
    return {(c.column, ck.check): ck.error_count
            for c in report.columns for ck in c.checks}


def test_end_to_end_example():
    report = validate(EXAMPLE / "passive_sr_schema.json", EXAMPLE / "sample_data.csv")
    assert report.status == "INVALID_DATA"
    assert report.file.rows == 6
    assert report.file.structure_valid is True
    checks = _checks(report)
    assert checks[("PassSROrigin", "mandatory")] == 1
    assert checks[("ExtractionTS", "type:timestamp")] == 1
    assert checks[("Ccy", "type:string")] == 1   # pattern folded into the type check


def test_column_failure_rate():
    report = validate(EXAMPLE / "passive_sr_schema.json", EXAMPLE / "sample_data.csv")
    col = next(c for c in report.columns if c.column == "PassSROrigin")
    assert col.failing_rows == 2           # lines 3 and 5
    assert abs(col.failure_rate - 2 / 6) < 1e-9


def test_report_is_json_serializable():
    report = validate(EXAMPLE / "passive_sr_schema.json", EXAMPLE / "sample_data.csv")
    js = report.model_dump_json()
    assert '"file"' in js and '"columns"' in js


def _run(schema, rows, **cfg):
    import tempfile, os
    f = tempfile.NamedTemporaryFile("w", suffix=".csv", delete=False)
    f.write(rows); f.close()
    try:
        return validate(schema, f.name, config=EngineConfig(**cfg) if cfg else None)
    finally:
        os.unlink(f.name)


def test_mandatory_and_type():
    schema = {"properties": {"A": {"type": "number", "ColumnIndex": 1, "Mandatory": "Yes"}}}
    checks = _checks(_run(schema, "A\n1\n\nx\n"))
    assert checks[("A", "mandatory")] == 1
    assert checks[("A", "type:number")] == 1


def test_header_missing_column_gates():
    schema = {"properties": {
        "A": {"type": "string", "ColumnIndex": 1, "Mandatory": "Yes"},
        "B": {"type": "string", "ColumnIndex": 2, "Mandatory": "No"},
    }}
    report = _run(schema, "A\nx\n")           # B missing
    assert report.status == "INVALID_STRUCTURE"
    assert report.file.stopped_at == "header"
    assert "B" in report.file.missing_columns


def test_header_extra_column_flagged():
    schema = {"properties": {"A": {"type": "string", "ColumnIndex": 1, "Mandatory": "No"}}}
    report = _run(schema, "A;Z\nx;1\n")       # Z is extra
    assert "Z" in report.file.unexpected_columns
    assert report.file.structure_valid is False


def test_header_order_mismatch():
    schema = {"properties": {
        "A": {"type": "string", "ColumnIndex": 1, "Mandatory": "No"},
        "B": {"type": "string", "ColumnIndex": 2, "Mandatory": "No"},
    }}
    report = _run(schema, "B;A\n1;2\n")       # wrong order
    assert report.file.order_ok is False
    assert report.status == "INVALID_STRUCTURE"


def test_extra_column_tolerated_when_configured():
    schema = {"properties": {"A": {"type": "string", "ColumnIndex": 1, "Mandatory": "No"}}}
    report = _run(schema, "A;Z\nx;1\n", allow_extra_columns=True)
    assert report.file.structure_valid is True
    assert "Z" in report.file.unexpected_columns   # still reported, but not failing


def test_extensibility_fold_constraint():
    # a new Constraint folded into the number check via add_constraint
    class MaxValue(Constraint):
        def applies(self, col):
            return col.attr("MaxValue") is not None
        def mask(self, col):
            return pl.col(col.name).cast(pl.Utf8).cast(pl.Float64, strict=False) > float(col.attr("MaxValue"))

    import tempfile, os
    schema = {"properties": {"S": {"type": "number", "MaxValue": 100, "ColumnIndex": 1}}}
    f = tempfile.NamedTemporaryFile("w", suffix=".csv", delete=False)
    f.write("S\n50\n150\n"); f.close()
    try:
        reg = default_registry().add_constraint("number", MaxValue())
        report = ValidationEngine(JsonSchemaParser(schema), CsvDataSource(f.name), registry=reg).validate()
    finally:
        os.unlink(f.name)
    checks = _checks(report)
    assert checks[("S", "type:number")] == 1   # 150 > 100, folded into the type check


def test_extensibility_separate_check():
    # a custom validator registered as its own reported check
    class NotFortyTwo(GatedValidator):
        name = "not_42"
        def applies(self, col):
            return col.type == "integer"
        def invalid_expr(self, col):
            return pl.col(col.name).cast(pl.Utf8) == "42"

    import tempfile, os
    schema = {"properties": {"N": {"type": "integer", "ColumnIndex": 1}}}
    f = tempfile.NamedTemporaryFile("w", suffix=".csv", delete=False)
    f.write("N\n1\n42\n"); f.close()
    try:
        reg = default_registry().register(NotFortyTwo())
        report = ValidationEngine(JsonSchemaParser(schema), CsvDataSource(f.name), registry=reg).validate()
    finally:
        os.unlink(f.name)
    checks = _checks(report)
    assert checks[("N", "not_42")] == 1


def test_default_date_format_configurable():
    schema = {"properties": {"D": {"type": "Date", "Size": 8, "ColumnIndex": 1, "Mandatory": "No"}}}
    # with YYYYMMDD default, 20240115 is valid
    r = _run(schema, "D\n20240115\nbad\n", default_date_format="%Y%m%d")
    checks = _checks(r)
    assert checks.get(("D", "type:date")) == 1     # only "bad" fails the date type


def test_per_column_date_format_overrides_default():
    schema = {"properties": {"D": {"type": "Date", "Format": "%d/%m/%Y", "ColumnIndex": 1, "Mandatory": "No"}}}
    r = _run(schema, "D\n15/01/2024\n2024-01-15\n")
    checks = _checks(r)
    assert checks.get(("D", "type:date")) == 1     # ISO value fails the dd/mm/yyyy format


def test_trailing_empty_column_removed():
    import tempfile, os
    schema = {"properties": {"a": {"type": "number", "ColumnIndex": 1},
                             "b": {"type": "number", "ColumnIndex": 2}}}
    f = tempfile.NamedTemporaryFile("w", suffix=".csv", delete=False)
    f.write("a;b;\n1;2;\n3;4;\n"); f.close()          # trailing comma -> empty last column
    try:
        report = validate(schema, f.name)
    finally:
        os.unlink(f.name)
    assert report.file.columns_present == 2           # phantom column dropped
    assert report.file.unexpected_columns == []


def test_missing_trailing_column_warns(caplog):
    import tempfile, os, logging
    schema = {"properties": {"a": {"type": "number", "ColumnIndex": 1},
                             "b": {"type": "number", "ColumnIndex": 2}}}
    f = tempfile.NamedTemporaryFile("w", suffix=".csv", delete=False)
    f.write("a;b\n1;2\n"); f.close()                  # no trailing comma
    try:
        with caplog.at_level(logging.WARNING):
            report = validate(schema, f.name)
    finally:
        os.unlink(f.name)
    assert any("No trailing empty column" in m for m in caplog.messages)


def test_number_accepts_comma_and_leading_separator():
    # '.' or ',' decimal separator, and a leading separator ('.5', ',5').
    # Uses ';' as the CSV delimiter so a ',' decimal is not split into two fields.
    import tempfile, os
    schema = {"properties": {"N": {"type": "number", "ColumnIndex": 1}}}
    f = tempfile.NamedTemporaryFile("w", suffix=".csv", delete=False)
    f.write("N\n1.5\n1,5\n.5\n,5\n-,25\n+.5\nabc\n"); f.close()
    try:
        report = validate(schema, f.name, separator=";")
    finally:
        os.unlink(f.name)
    checks = _checks(report)
    assert checks.get(("N", "type:number")) == 1          # only 'abc' is not a number


def test_number_comma_respects_minimum_and_precision():
    import tempfile, os
    schema = {"properties": {"N": {"type": "number", "minimum": 0, "FractionDigit": 2,
                                    "ColumnIndex": 1}}}
    f = tempfile.NamedTemporaryFile("w", suffix=".csv", delete=False)
    f.write("N\n1,5\n-,5\n0,123\n"); f.close()
    try:
        report = validate(schema, f.name, separator=";")
    finally:
        os.unlink(f.name)
    checks = _checks(report)
    assert checks[("N", "type:number")] == 2              # '-,5' < 0, and '0,123' has 3 fraction digits
