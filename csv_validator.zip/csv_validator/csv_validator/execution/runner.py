"""Runner: Polars execution in a single streaming pass.

In ONE collect over the file, computes: the row count, and per column both the
distinct number of failing rows and, per check, the error count + a bounded
sample. Every per-check/per-column expression reduces to a length-1 cell, so they
all fit in one result row — a single scan.
"""

from __future__ import annotations

from functools import reduce

import polars as pl

from ..models import BoundCheck

ROW_IDX = "__row__"

# per check: (check_name, error_count, sample)
CheckData = tuple[str, int, list[tuple[int, str]]]
# per column: (column, failing_rows, [CheckData])
ColumnData = tuple[str, int, list[CheckData]]


class Runner:
    @staticmethod
    def run(
        lf: pl.LazyFrame,
        checks_by_column: dict[str, list[BoundCheck]],
        sample_size: int,
        engine: str = "streaming",
    ) -> tuple[int, list[ColumnData]]:
        lf = lf.with_row_index(ROW_IDX)
        flat = [(col, chk) for col, chks in checks_by_column.items() for chk in chks]

        exprs: list[pl.Expr] = [pl.len().alias("rows")]
        for i, (col, chk) in enumerate(flat):
            inv = chk.invalid.fill_null(False)
            exprs += [
                inv.sum().alias(f"cnt_{i}"),
                (pl.col(ROW_IDX) + 1).filter(inv).head(sample_size).implode().alias(f"line_{i}"),
                pl.col(col).cast(pl.Utf8).filter(inv).head(sample_size).implode().alias(f"val_{i}"),
            ]
        for j, (col, chks) in enumerate(checks_by_column.items()):
            any_fail = reduce(lambda a, b: a | b, (c.invalid.fill_null(False) for c in chks))
            exprs.append(any_fail.sum().alias(f"colfail_{j}"))

        row = lf.select(exprs).collect(engine=engine).row(0, named=True)
        rows = int(row["rows"])

        columns: list[ColumnData] = []
        i = 0
        for j, (col, chks) in enumerate(checks_by_column.items()):
            check_data: list[CheckData] = []
            for chk in chks:
                n = int(row[f"cnt_{i}"] or 0)
                sample = [
                    (int(ln), v if v is not None else "")
                    for ln, v in zip(row[f"line_{i}"] or [], row[f"val_{i}"] or [])
                ]
                check_data.append((chk.check, n, sample))
                i += 1
            failing_rows = int(row[f"colfail_{j}"] or 0)
            columns.append((col, failing_rows, check_data))
        return rows, columns
