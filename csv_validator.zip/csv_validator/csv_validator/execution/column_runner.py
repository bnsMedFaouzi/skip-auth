"""Per-column checks, evaluated block by block with Polars (bounded memory).

The checks are flattened into ``_flat = [(column, check), ...]``; a check's index
in that list is its identity in the parallel state lists. Per block, one streaming
collect computes every check's mask and reuses it three ways (error count,
column failing-row count, bounded sample); only a one-row result leaves Polars, so
peak memory tracks the block size, not the file size. Results are regrouped per
column at the end.
"""

from __future__ import annotations

import polars as pl

from ..models import BoundCheck
from .runner import BlockProcessor

ROW_IDX = "__row__"  # transient row-index column added per block to number samples

# Shapes returned by `result()`, consumed by the engine to build the report.
CheckData = tuple[str, int, list[tuple[int, str]]]     # (check, error_count, sample)
ColumnData = tuple[str, int, list[CheckData]]          # (column, failing_rows, checks)


class ColumnRunner(BlockProcessor):
    """Accumulates per-column check results across blocks.

    Key state: ``_flat`` (the flattened checks), ``_col_indices`` (column -> its
    check indices, in schema order), the precomputed Polars expressions
    (``_masks`` / ``_rows_expr`` / ``_count_exprs`` / ``_sample_exprs`` /
    ``_colfail_exprs``), and the accumulators ``_counts`` / ``_samples`` /
    ``_needs_sample`` (parallel to ``_flat``) and ``_colfail`` (per column).
    """

    def __init__(
        self,
        checks_by_column: dict[str, list[BoundCheck]],
        sample_size: int,
        engine: str = "streaming",
    ) -> None:
        """Flatten the checks and build the accumulators; expressions are built once."""
        self._sample_size = sample_size
        self._engine = engine
        self._flat = [(col, chk) for col, chks in checks_by_column.items() for chk in chks]
        self._col_indices = self._group_by_column()
        # Data-independent, so built once and reused every block.
        self._masks = self._mask_columns()
        self._rows_expr = pl.len().alias("rows")
        self._count_exprs = self._count_columns()
        self._sample_exprs = self._sample_columns()
        self._colfail_exprs = self._colfail_columns()
        self._counts = [0] * len(self._flat)
        self._samples: list[list[tuple[int, str]]] = [[] for _ in self._flat]
        self._needs_sample = [sample_size > 0 for _ in self._flat]
        self._colfail = {col: 0 for col in self._col_indices}

    def _group_by_column(self) -> dict[str, list[int]]:
        """Map each column to its check indices in ``_flat`` (schema order)."""
        indices: dict[str, list[int]] = {}
        for i, (col, _) in enumerate(self._flat):
            indices.setdefault(col, []).append(i)
        return indices

    # -- BlockProcessor interface -------------------------------------------

    def update(self, block: pl.LazyFrame, offset: int) -> int:
        """Evaluate one block, fold it in, and return its row count.

        ``offset`` (rows seen before this block) makes sample line numbers absolute.
        """
        row = self._evaluate(block)
        self._accumulate(row, offset)
        return int(row["rows"])

    def result(self) -> list[ColumnData]:
        """Return the accumulated per-column results."""
        return self._assemble()

    # -- one Polars pass over one block -------------------------------------

    def _evaluate(self, block: pl.LazyFrame) -> dict:
        """Attach masks + aggregates to the lazy block, collect once, return one row."""
        return (
            block.with_row_index(ROW_IDX)
            .with_columns(self._masks)
            .select(self._aggregates())
            .collect(engine=self._engine)
            .row(0, named=True)
        )

    def _aggregates(self) -> list[pl.Expr]:
        """The block's aggregates: row count, per-check counts and (still-needed) samples,
        per-column failing-row counts. Only the sample subset varies per block."""
        samples = [self._sample_exprs[i] for i in range(len(self._flat)) if self._needs_sample[i]]
        return [self._rows_expr, *self._count_exprs, *samples, *self._colfail_exprs]

    # -- expression builders (each list built once in __init__) -------------

    def _mask_columns(self) -> list[pl.Expr]:
        """One invalid-mask ``m{i}`` per check (null cells are not invalid here)."""
        return [chk.invalid.fill_null(False).alias(f"m{i}") for i, (_, chk) in enumerate(self._flat)]

    def _count_columns(self) -> list[pl.Expr]:
        """One error-count aggregate per check (the sum of its mask)."""
        return [pl.col(f"m{i}").sum().alias(f"count:{i}") for i in range(len(self._flat))]

    def _sample_columns(self) -> list[pl.Expr]:
        """One bounded ``(line, value)`` sample aggregate per check (lines 1-based per block)."""
        exprs = []
        for i, (column, _) in enumerate(self._flat):
            pair = pl.struct(
                (pl.col(ROW_IDX) + 1).alias("line"),
                pl.col(column).cast(pl.Utf8).alias("value"),
            )
            exprs.append(pair.filter(pl.col(f"m{i}")).head(self._sample_size).implode().alias(f"sample:{i}"))
        return exprs

    def _colfail_columns(self) -> list[pl.Expr]:
        """One failing-row count per column (a row failing several checks counts once)."""
        return [
            pl.any_horizontal([pl.col(f"m{k}") for k in idxs]).sum().alias(f"colfail:{col}")
            for col, idxs in self._col_indices.items()
        ]

    # -- accumulation across blocks -----------------------------------------

    def _accumulate(self, row: dict, offset: int) -> None:
        """Add one block's counts, samples, and failing-row counts to the totals."""
        for i in range(len(self._flat)):
            self._counts[i] += int(row[f"count:{i}"] or 0)
            if self._needs_sample[i]:
                self._collect_sample(i, row, offset)
        for column in self._colfail:
            self._colfail[column] += int(row[f"colfail:{column}"] or 0)

    def _collect_sample(self, i: int, row: dict, offset: int) -> None:
        """Append check ``i``'s sample rows (offset-shifted), stopping once it is full."""
        for pair in row[f"sample:{i}"] or []:
            if len(self._samples[i]) >= self._sample_size:
                self._needs_sample[i] = False
                return
            value = pair["value"]
            self._samples[i].append((offset + int(pair["line"]), value if value is not None else ""))

    def _assemble(self) -> list[ColumnData]:
        """Regroup the flat results under their column, in schema order."""
        return [
            (col, self._colfail[col],
             [(self._flat[i][1].check, self._counts[i], self._samples[i]) for i in idxs])
            for col, idxs in self._col_indices.items()
        ]
