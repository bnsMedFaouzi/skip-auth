"""Report models (Pydantic): file-level and column-level metrics.

- FileMetrics   : structure of the file/header (missing/extra/ordered columns,
                  row count, overall structure validity).
- ColumnMetrics : per-column quality (failure rate, per-check breakdown).

Being Pydantic models, reports serialize to JSON via `report.model_dump_json()`.
"""

from __future__ import annotations

from datetime import datetime, timezone

from pydantic import BaseModel, Field


def _now_iso() -> str:
    """Current UTC time as a second-precision ISO 8601 string."""
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


class ReportMetadata(BaseModel):
    """Run metadata: source file, when it was validated, and how long it took."""

    file_name: str | None = None
    validated_at: str = Field(default_factory=_now_iso)
    duration_seconds: float | None = None


class CheckMetric(BaseModel):
    """One check's outcome for a column: error count, rate, and a bounded sample."""

    check: str
    error_count: int
    failure_rate: float                                # error_count / rows
    sample: list[tuple[int, str]] = Field(default_factory=list)  # (line, value)


class ColumnMetrics(BaseModel):
    """One column's quality: failing rows, rate, and the per-check breakdown."""

    column: str
    failing_rows: int                                  # distinct rows failing >=1 check
    failure_rate: float                                # failing_rows / rows
    error_count: int                                   # sum of per-check counts
    checks: list[CheckMetric] = Field(default_factory=list)


class StructureIssue(BaseModel):
    """One structural problem found by a structure check."""

    check: str                                         # the check that reported it (e.g. "header")
    code: str                                          # machine-readable kind (e.g. "missing_columns")
    message: str                                       # human-readable description
    columns: list[str] = Field(default_factory=list)   # affected columns, when relevant


class FileMetrics(BaseModel):
    """File-level outcome: row count, header/structure status, and total errors."""

    rows: int
    columns_expected: int
    columns_present: int
    structure_valid: bool = True
    structure_issues: list[StructureIssue] = Field(default_factory=list)
    stopped_at: str | None = None
    total_errors: int = 0


class ValidationReport(BaseModel):
    """The full result: overall status, file metrics, and per-column metrics."""

    status: str                        # VALID / INVALID_STRUCTURE / INVALID_DATA
    file: FileMetrics
    columns: list[ColumnMetrics] = Field(default_factory=list)
    metadata: ReportMetadata | None = None

    @property
    def total_errors(self) -> int:
        """Total errors across all columns."""
        return self.file.total_errors

    @property
    def is_valid(self) -> bool:
        """True only when the file passed both structure and data checks."""
        return self.status == "VALID"

    def to_text(self, sample_limit: int = 5, show_clean: bool = False) -> str:
        """Render the report as a readable multi-line summary."""
        f = self.file
        out = [f"status : {self.status}"]
        if self.metadata:
            m = self.metadata
            out += ["", "metadata"]
            if m.file_name:
                out.append(f"  file            : {m.file_name}")
            out.append(f"  validated_at    : {m.validated_at}")
            if m.duration_seconds is not None:
                out.append(f"  duration        : {m.duration_seconds:.3f}s")
        out += ["", "file metrics"]
        out.append(f"  rows            : {f.rows}")
        out.append(f"  columns         : {f.columns_present}/{f.columns_expected} present")
        out.append(f"  structure_valid : {f.structure_valid}")
        for issue in f.structure_issues:
            out.append(f"  structure_issue : {issue.message}")
        if f.stopped_at:
            out.append(f"  stopped_at      : {f.stopped_at}")
        out.append(f"  total_errors    : {f.total_errors}")

        failing_cols = [c for c in self.columns if c.error_count > 0]
        shown_cols = self.columns if show_clean else failing_cols
        clean = len(self.columns) - len(failing_cols)
        if shown_cols:
            out.append("")
            out.append("column metrics" if show_clean else "column metrics (failing columns)")
            for c in shown_cols:
                out.append(
                    f"  {c.column:<16} failing {c.failing_rows}/{f.rows} "
                    f"(rate {c.failure_rate:.2%}) · errors {c.error_count}"
                )
                for ck in c.checks:
                    out.append(f"      {ck.check:<14} {ck.error_count} (rate {ck.failure_rate:.2%})")
                    for line_no, value in ck.sample[:sample_limit]:
                        shown = value if value not in (None, "") else "(empty)"
                        out.append(f"         line {line_no:<6} « {shown} »")
        if clean and not show_clean:
            out.append("")
            out.append(f"{clean} column(s) checked with no errors.")
        return "\n".join(out)


class ReportBuilder:
    """Assembles the final ValidationReport from file + column metrics."""

    def build(
        self,
        file: FileMetrics,
        columns: list[ColumnMetrics],
        *,
        file_name: str | None = None,
        duration_seconds: float | None = None,
    ) -> ValidationReport:
        """Assemble the report: derive the status, sort columns worst-first, attach metadata.

        Status is INVALID_STRUCTURE if the header/structure failed (or halted the
        run), INVALID_DATA if the structure held but values failed checks, else VALID.
        Columns are ordered by error count (then failing rows, then name) so the
        worst offenders come first; clean columns sink to the end.
        """
        if not file.structure_valid or file.stopped_at is not None:
            status = "INVALID_STRUCTURE"
        elif file.total_errors > 0:
            status = "INVALID_DATA"
        else:
            status = "VALID"
        ordered = sorted(columns, key=lambda c: (-c.error_count, -c.failing_rows, c.column))
        return ValidationReport(
            status=status,
            file=file,
            columns=ordered,
            metadata=ReportMetadata(file_name=file_name, duration_seconds=duration_seconds),
        )
