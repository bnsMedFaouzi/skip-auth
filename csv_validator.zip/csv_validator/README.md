# csv_validator

Validates a CSV file against a JSON schema (JSON-Schema draft-07 style).
Built-in checks: **value type** and **mandatory** (`Mandatory`).

Object-oriented and pattern-based, so the code is **extensible**: adding a check
= adding a class and registering it, without touching the engine.

## Install

```bash
pip install polars
```

## Usage

Simple facade:

```python
from csv_validator import validate

report = validate("schema.json", "data.csv")
print(report.to_text())
```

Explicit wiring (inject your own source / parser / registry):

```python
from csv_validator import ValidationEngine, JsonSchemaParser, CsvDataSource, default_registry

engine = ValidationEngine(
    schema_parser=JsonSchemaParser("schema.json"),
    data_source=CsvDataSource("data.csv"),
    registry=default_registry(),
)
report = engine.validate()
```

Async API (independent Polars collects run concurrently on the event loop):

```python
import asyncio
from csv_validator import validate_async

async def main():
    report = await validate_async("schema.json", "data.csv")
    print(report.to_text())

asyncio.run(main())
```

Or the bundled example:

```bash
python run_example.py
```

## Design patterns

| Pattern | Where | Purpose |
|---------|-------|---------|
| **Strategy** | `Validator` subclasses, `SchemaParser`, `DataSource` | interchangeable algorithms/implementations |
| **Template Method** | `GatedValidator` | shared "check non-empty cells only" logic; subclasses fill `invalid_expr` |
| **Registry** | `ValidatorRegistry` | the extension point: register validators |
| **Facade** | `ValidationEngine`, `validate()` | one entry point over parser + source + registry |
| **Builder** | `ReportBuilder` | assembles the `ValidationReport` step by step |

## Structure

```
csv_validator/
  column.py           # ColumnDef (normalized column)
  datasource.py       # DataSource (ABC) + CsvDataSource
  schema.py           # SchemaParser (ABC) + JsonSchemaParser
  validators/         # validator subpackage (extension point)
    base.py           #   Validator, GatedValidator, BoundCheck
    types.py          #   TypeValidator + StringType, NumberType, ...
    constraints.py    #   MandatoryValidator + Enum/Length/Minimum/Pattern
    registry.py       #   ValidatorRegistry, default_registry
  runner.py           # Runner: Polars execution primitives (concurrent collects)
  report.py           # CheckResult, ValidationReport, ReportBuilder
  engine.py           # ValidationEngine (Facade) + validate() / validate_async()
example/
  passive_sr_schema.json
  sample_data.csv
run_example.py
```

Files are kept small and single-purpose (largest ~120 lines).

## Validator hierarchy

```
Validator (ABC)
  MandatoryValidator                 -> flags empty cells of mandatory columns
  GatedValidator (ABC)               -> Template Method: only non-empty cells
    TypeValidator (ABC)              -> keyed by base_type
      StringType, NumberType, IntegerType, TimestampType, DateType, BooleanType
    ConstraintValidator (ABC)        -> applies when a constraint is present
      EnumConstraint, LengthConstraint, MinimumConstraint, PatternConstraint
```

Each validator returns a Polars expression that is **true where the value is
invalid**. Empty cells are excluded by `GatedValidator` (except `mandatory`,
which is precisely about empties).

## Extend: add a type

Subclass `TypeValidator` and register an instance. No engine change.

```python
import polars as pl
from csv_validator import TypeValidator, default_registry, validate

class EmailType(TypeValidator):
    handles = ("email",)
    def invalid_expr(self, col):
        return ~pl.col(col.name).cast(pl.Utf8).str.contains(r"^[^@]+@[^@]+\.[^@]+$")

registry = default_registry().register(EmailType())
report = validate("schema.json", "data.csv", registry=registry)
```

Any column with `"type": "email"` in the schema is now validated.

## Extend: add a constraint

```python
import polars as pl
from csv_validator import ConstraintValidator

class MinLengthConstraint(ConstraintValidator):
    name = "min_length"
    def applies(self, col):
        return getattr(col, "min_length", None) is not None
    def invalid_expr(self, col):
        return pl.col(col.name).cast(pl.Utf8).str.len_chars() < col.min_length
```

(Extend `ColumnDef` in `column.py` to carry new fields such as `min_length`.)

## Performance

The engine uses an **asyncio event loop** to overlap independent Polars
`collect()` calls. Polars releases the GIL during a collect, so work dispatched
via `asyncio.to_thread` runs in parallel across threads:

- the row-count pass and the invalid-count pass run concurrently;
- the per-failing-check sample collects all run concurrently.

Each individual collect is already multi-threaded internally by Polars (Rust);
the event loop adds *cross-query* parallelism on top. Use `validate_async()` in
an async context; `validate()` drives the loop for you via `asyncio.run`.

## Checks active by default

| Check | Triggered by | Origin |
|-------|--------------|--------|
| `mandatory` | `Mandatory: "Yes"` | mandatory |
| `type:string` / `number` / `integer` / `timestamp` / `date` / `boolean` | `type` | **value type** |
| `enum` | `AuthorizeValue` / `enum` | constraint |
| `length` | `Size` | constraint |
| `minimum` | `minimum` | constraint |
| `pattern` | `pattern` | constraint |

The first two (**type** and **mandatory**) are the requested core; the others
are provided as examples of the extension mechanism and are removed simply by not
registering them (build your own registry instead of `default_registry()`).
