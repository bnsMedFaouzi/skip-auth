"""Validation engine (Facade).

Orchestrates the pieces in order: parse the schema, gate on the file structure
(header), run a single streaming pass over the data, and assemble the report.
Each step is a small method so `validate_async` reads as a recipe.
"""

from __future__ import annotations

import asyncio
from pathlib import Path

from ..models import (
    CheckMetric, ColumnDef, ColumnMetrics, EngineConfig, ReportBuilder, ValidationReport,
)
from ..schema import JsonSchemaParser, SchemaParser
from ..sources import CsvDataSource, DataSource
from ..structure import HeaderResult
from ..validators import ValidatorRegistry, default_registry
from .column_runner import ColumnData, ColumnRunner
from .file_runner import FileRunner
from .runner import Runner


class ValidationEngine:
    """Ties the schema, data source, validators, and runners into one validation."""

    def __init__(
        self,
        schema_parser: SchemaParser,
        data_source: DataSource,
        registry: ValidatorRegistry | None = None,
        config: EngineConfig | None = None,
        runner: Runner | None = None,
    ) -> None:
        self._schema_parser = schema_parser
        self._data_source = data_source
        self._config = config or EngineConfig()
        self._registry = registry or default_registry(self._config)
        self._runner = runner or Runner()
        self._file_runner = FileRunner(self._config)
        self._builder = ReportBuilder()

    # -- entry points -------------------------------------------------------

    def validate(self) -> ValidationReport:
        """Synchronous entry point (runs the async pipeline on a fresh loop)."""
        try:
            asyncio.get_running_loop()
        except RuntimeError:
            return asyncio.run(self.validate_async())
        raise RuntimeError("An event loop is already running; use `await engine.validate_async()`.")

    async def validate_async(self) -> ValidationReport:
        """Parse, gate on structure, run the column pass, and build the report."""
        columns = self._schema_parser.parse()
        present, structure = self._resolve_structure(columns)

        if self._config.header_gate and not structure.valid:
            return self._gated_report(columns, present, structure)

        rows, column_data = await self._run_columns(present)
        return self._build_report(columns, present, structure, rows, column_data)

    # -- steps --------------------------------------------------------------

    def _resolve_structure(self, columns: list[ColumnDef]) -> tuple[list[ColumnDef], HeaderResult]:
        """Compare the schema to the CSV header; return the present columns + result."""
        actual = self._data_source.columns()
        structure = self._file_runner.check_structure(columns, actual)
        present = [c for c in columns if c.name in set(actual)]
        return present, structure

    async def _run_columns(self, present: list[ColumnDef]) -> tuple[int, list[ColumnData]]:
        """Run the single streaming pass; return the row count and per-column data."""
        checks_by_column = self._plan(present)
        batch_size = self._config.batch_for(len(present))
        blocks = self._data_source.iter_frames(batch_size)
        column_runner = ColumnRunner(checks_by_column, self._config.sample_size, self._config.engine_mode)
        rows, results = await self._runner.run(blocks, [column_runner])
        return rows, results[0]

    def _plan(self, present: list[ColumnDef]) -> dict[str, list]:
        """Map each present column to its applicable checks (skipping columns with none)."""
        return {
            col.name: checks
            for col in present
            if (checks := self._registry.checks_for(col))
        }

    # -- report assembly ----------------------------------------------------

    def _gated_report(
        self, columns: list[ColumnDef], present: list[ColumnDef], structure: HeaderResult
    ) -> ValidationReport:
        """Report produced when a broken header halts value validation."""
        file = self._file_runner.metrics(
            rows=0, expected=len(columns), present=len(present),
            structure=structure, total_errors=0, stopped_at="header",
        )
        return self._builder.build(file, [])

    def _build_report(
        self,
        columns: list[ColumnDef],
        present: list[ColumnDef],
        structure: HeaderResult,
        rows: int,
        column_data: list[ColumnData],
    ) -> ValidationReport:
        """Assemble the column metrics and the file metrics into the final report."""
        column_metrics = [self._to_metrics(col, failing, checks, rows)
                          for col, failing, checks in column_data]
        total_errors = sum(c.error_count for c in column_metrics)
        file = self._file_runner.metrics(
            rows=rows, expected=len(columns), present=len(present),
            structure=structure, total_errors=total_errors,
        )
        return self._builder.build(file, column_metrics)

    @staticmethod
    def _to_metrics(column: str, failing_rows: int, checks: list, rows: int) -> ColumnMetrics:
        """Turn one column's raw check results into its ColumnMetrics (rates, samples)."""
        check_metrics = [
            CheckMetric(check=name, error_count=count,
                        failure_rate=(count / rows) if rows else 0.0, sample=sample)
            for name, count, sample in checks if count > 0
        ]
        return ColumnMetrics(
            column=column,
            failing_rows=failing_rows,
            failure_rate=(failing_rows / rows) if rows else 0.0,
            error_count=sum(c.error_count for c in check_metrics),
            checks=check_metrics,
        )


# --- convenience facades ---------------------------------------------------

def _engine(schema_source, csv_path, registry, config, separator) -> ValidationEngine:
    """Wire a JSON schema + CSV path into a ready-to-run ValidationEngine."""
    source = CsvDataSource(csv_path, separator=separator)
    return ValidationEngine(JsonSchemaParser(schema_source), source, registry, config)


def validate(schema_source, csv_path: str | Path, *, config: EngineConfig | None = None,
             registry: ValidatorRegistry | None = None, separator: str = ",") -> ValidationReport:
    """Validate `csv_path` against `schema_source`; returns a ValidationReport."""
    return _engine(schema_source, csv_path, registry, config, separator).validate()


async def validate_async(schema_source, csv_path: str | Path, *, config: EngineConfig | None = None,
                         registry: ValidatorRegistry | None = None, separator: str = ",") -> ValidationReport:
    """Async variant of `validate`, for use inside a running event loop."""
    return await _engine(schema_source, csv_path, registry, config, separator).validate_async()
