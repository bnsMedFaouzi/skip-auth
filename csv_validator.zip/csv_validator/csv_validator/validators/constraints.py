"""Mandatory and constraint validators (Strategy)."""

from __future__ import annotations

import polars as pl

from ..models.column import ColumnDef
from .base import GatedValidator, Validator, non_empty


class MandatoryValidator(Validator):
    """Not gated: it is precisely about empty cells."""

    name = "mandatory"

    def applies(self, col: ColumnDef) -> bool:
        return col.mandatory

    def build(self, col: ColumnDef) -> pl.Expr:
        return ~non_empty(col.name)


class ConstraintValidator(GatedValidator):
    """Base for constraints applied when the matching field is present."""

    name = "constraint"

    def check_name(self, col: ColumnDef) -> str:
        return self.name


class EnumConstraint(ConstraintValidator):
    name = "enum"

    def applies(self, col: ColumnDef) -> bool:
        return bool(col.allowed_values)

    def invalid_expr(self, col: ColumnDef) -> pl.Expr:
        return ~pl.col(col.name).cast(pl.Utf8).is_in(col.allowed_values)


class LengthConstraint(ConstraintValidator):
    name = "length"

    def applies(self, col: ColumnDef) -> bool:
        return col.max_length is not None

    def invalid_expr(self, col: ColumnDef) -> pl.Expr:
        return pl.col(col.name).cast(pl.Utf8).str.len_chars() > col.max_length


class MinimumConstraint(ConstraintValidator):
    name = "minimum"

    def applies(self, col: ColumnDef) -> bool:
        return col.minimum is not None and col.base_type in ("number", "integer")

    def invalid_expr(self, col: ColumnDef) -> pl.Expr:
        return pl.col(col.name).cast(pl.Utf8).cast(pl.Float64, strict=False) < col.minimum


class PatternConstraint(ConstraintValidator):
    name = "pattern"

    def applies(self, col: ColumnDef) -> bool:
        return bool(col.pattern)

    def invalid_expr(self, col: ColumnDef) -> pl.Expr:
        return ~pl.col(col.name).cast(pl.Utf8).str.contains(col.pattern)


class DecimalPrecisionConstraint(ConstraintValidator):
    """Lexical decimal precision (preserves precision — no float cast).

    Checks total digits <= TotalDigits and fractional digits <= FractionDigits,
    directly on the text, so 25-digit decimals keep full precision.
    """

    name = "precision"

    def applies(self, col: ColumnDef) -> bool:
        return (col.total_digits is not None or col.fraction_digits is not None) \
            and col.base_type in ("number", "integer")

    def invalid_expr(self, col: ColumnDef) -> pl.Expr:
        s = pl.col(col.name).cast(pl.Utf8).str.strip_chars().str.replace(r"^[+-]", "")
        conditions: list[pl.Expr] = []
        if col.total_digits is not None:
            total = s.str.replace_all(r"[^0-9]", "").str.len_chars()
            conditions.append(total > col.total_digits)
        if col.fraction_digits is not None:
            frac = s.str.split_exact(".", 1).struct.field("field_1").str.len_chars().fill_null(0)
            conditions.append(frac > col.fraction_digits)
        expr = conditions[0]
        for c in conditions[1:]:
            expr = expr | c
        return expr


CONSTRAINT_VALIDATORS = (
    EnumConstraint, LengthConstraint, MinimumConstraint, PatternConstraint,
    DecimalPrecisionConstraint,
)
