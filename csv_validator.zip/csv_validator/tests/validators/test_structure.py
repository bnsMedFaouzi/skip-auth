"""Tests for validators/structure: the checks + FileRunner orchestration."""

from csv_validator import EngineConfig, JsonSchemaParser, MaxColumns, StructureCheck
from csv_validator.validators.structure import HeaderCheck
from csv_validator.execution.file_runner import FileRunner


def _cols(props):
    return JsonSchemaParser({"properties": props}).parse()


# -- end-to-end via validate() ---------------------------------------------- #

def test_missing_column_gates(run_csv):
    schema = {"properties": {
        "A": {"type": "string", "ColumnIndex": 1, "Mandatory": "Yes"},
        "B": {"type": "string", "ColumnIndex": 2, "Mandatory": "No"},
    }}
    report = run_csv(schema, "A\nx\n")
    assert report.status == "INVALID_STRUCTURE"
    assert report.file.stopped_at == "header"
    assert any(i.code == "missing_columns" and "B" in i.columns for i in report.file.structure_issues)


def test_extra_column_flagged(run_csv):
    schema = {"properties": {"A": {"type": "string", "ColumnIndex": 1, "Mandatory": "No"}}}
    report = run_csv(schema, "A;Z\nx;1\n")
    assert report.file.structure_valid is False
    assert any(i.code == "unexpected_columns" and "Z" in i.columns for i in report.file.structure_issues)


def test_order_mismatch(run_csv):
    schema = {"properties": {
        "A": {"type": "string", "ColumnIndex": 1, "Mandatory": "No"},
        "B": {"type": "string", "ColumnIndex": 2, "Mandatory": "No"},
    }}
    report = run_csv(schema, "B;A\n1;2\n")
    assert report.status == "INVALID_STRUCTURE"
    assert any(i.code == "out_of_order" for i in report.file.structure_issues)


def test_extra_column_tolerated_when_configured(run_csv):
    schema = {"properties": {"A": {"type": "string", "ColumnIndex": 1, "Mandatory": "No"}}}
    report = run_csv(schema, "A;Z\nx;1\n", allow_extra_columns=True)
    assert report.file.structure_valid is True


# -- units: the header check and the runner ---------------------------------- #

def test_header_check_reports_order():
    cols = _cols({"A": {"type": "string", "ColumnIndex": 1, "Mandatory": "No"},
                  "B": {"type": "string", "ColumnIndex": 2, "Mandatory": "No"}})
    issues = HeaderCheck().check(cols, ["B", "A"], EngineConfig())
    assert [i.code for i in issues] == ["out_of_order"]
    assert issues[0].check == "header"


def test_file_runner_owns_and_runs_checks():
    cols = _cols({"a": {"type": "string", "ColumnIndex": 1}})
    # header check passes, MaxColumns fails
    runner = FileRunner(EngineConfig(), checks=[HeaderCheck(), MaxColumns(2)])
    result = runner.check_structure(cols, ["a", "b", "c"])
    assert result.valid is False
    assert any(i.code == "too_many_columns" for i in result.issues)


def test_custom_structure_check():
    class RejectAll(StructureCheck):
        name = "reject_all"
        def check(self, columns, actual, config):
            return [self.issue("policy", "rejected by policy")]

    cols = _cols({"a": {"type": "string", "ColumnIndex": 1}})
    result = FileRunner(EngineConfig(), checks=[RejectAll()]).check_structure(cols, ["a"])
    assert result.valid is False
    assert result.issues[0].message == "rejected by policy" and result.issues[0].check == "reject_all"
