"""JSON schema parser (named-type convention), validated with Pydantic.

A property's `type` holds either a primitive or the name of a `definitions`
entry. Definitions are validated as `DefinitionSchema`, properties as
`PropertySchema`. Each property is *flattened* — the referenced definition
merged in — then mapped straight to a `ColumnDef` via `model_validate`.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from pydantic import ValidationError

from ..models import ColumnDef, PropertySchema, RawSchema
from ..models.column import PRIMITIVES
from .base import SchemaParser


class SchemaError(ValueError):
    """Raised for a malformed schema (invalid property, or circular type ref)."""


class JsonSchemaParser(SchemaParser):
    """Parses the JSON schema into ordered, normalized column definitions."""

    def __init__(self, source: str | Path | dict[str, Any]) -> None:
        self._source = source

    def parse(self) -> list[ColumnDef]:
        """Return the columns, flattened and normalized, ordered by ColumnIndex."""
        try:
            raw = RawSchema.model_validate(self._load())
        except ValidationError as exc:
            raise SchemaError(self._describe(exc)) from exc
        columns = [
            self._to_column(name, self._flatten(prop, raw.definitions))
            for name, prop in raw.properties.items()
        ]
        columns.sort(key=lambda c: (c.order is None, c.order or 0))
        return columns

    def _load(self) -> dict[str, Any]:
        """Load the raw schema from a dict, a file path, or a JSON string."""
        if isinstance(self._source, dict):
            return self._source
        path = Path(self._source)
        if path.exists():
            return json.loads(path.read_text(encoding="utf-8"))
        if isinstance(self._source, str) and self._source.lstrip()[:1] in "{[":
            return json.loads(self._source)
        raise FileNotFoundError(f"Schema file not found: {self._source}")

    @staticmethod
    def _describe(exc: ValidationError) -> str:
        """Turn a Pydantic error into a message that points at the column."""
        err = exc.errors()[0]
        loc = err.get("loc", ())
        if len(loc) >= 2 and loc[0] in ("properties", "definitions"):
            return f"Invalid schema for column '{loc[1]}': {err['msg']}"
        return f"Invalid schema: {exc}"

    @staticmethod
    def _flatten(prop: PropertySchema, definitions: dict) -> PropertySchema:
        """Merge the referenced definition into the property (one level).

        If `type` names a definition, the definition supplies the real type and
        its constraints; the property's own explicitly-set fields win. Definitions
        reference only primitives, so no recursion is needed.
        """
        ref = prop.type
        if ref.lower() in PRIMITIVES or ref not in definitions:
            return prop
        merged = definitions[ref].model_dump()
        merged.update({f: getattr(prop, f) for f in prop.model_fields_set if f != "type"})
        merged.update(prop.model_extra or {})
        return PropertySchema.model_validate(merged)

    def _to_column(self, name: str, prop: PropertySchema) -> ColumnDef:
        """Build a normalized ColumnDef directly from the flattened property."""
        try:
            return ColumnDef.model_validate({**prop.model_dump(), "name": name})
        except ValidationError as exc:
            raise SchemaError(f"Invalid schema for column '{name}': {exc}") from exc
