"""Normalized column definition — a schema property plus a name."""

from __future__ import annotations

from typing import Any

from pydantic import Field, field_validator

from .raw_schema import PropertySchema

# Primitive type tokens; any other `type` value names a definition to resolve.
_TYPE_ALIASES = {
    "str": "string", "text": "string",
    "int": "integer", "integer": "integer",
    "number": "number", "decimal": "number", "float": "number", "double": "number",
    "timestamp": "timestamp", "datetime": "timestamp",
    "date": "date", "boolean": "boolean", "bool": "boolean",
}
PRIMITIVES = set(_TYPE_ALIASES) | {"string"}


class ColumnDef(PropertySchema):
    """A validated column: every `PropertySchema` field, plus a `name`.

    Its `type` is normalized to a canonical primitive. Unknown schema fields are
    kept (extra='allow') and read via `attr(...)`, so a future rule needs no
    change here.
    """

    name: str
    checks: list = Field(default_factory=list, exclude=True, repr=False)  # planned by the engine

    @field_validator("type", mode="after")
    @classmethod
    def _normalize_type(cls, value: str) -> str:
        """Map a primitive type token to its canonical form (Timestamp->timestamp)."""
        token = (value or "string").lower()
        return _TYPE_ALIASES.get(token, token)

    def attr(self, key: str, default: Any = None) -> Any:
        """Read a raw schema attribute kept from the source (for future rules)."""
        return (self.model_extra or {}).get(key, default)

    def max_bytes(self, config) -> int:
        """Maximum text width (bytes) a cell of this column can hold, from the schema.

        Uses the tightest bound the schema gives: `Size`, or `TotalDigit` for
        numbers, else a per-kind default. Everything is read as Utf8, so what
        matters is the textual width, not the logical type.
        """
        if self.max_length:
            return self.max_length
        if self.type in ("number", "integer") and self.total_digits:
            return self.total_digits + 2                          # digits + sign + decimal point
        if self.type == "string":                                 # un-sized string
            return config.default_string_bytes
        return config.default_other_bytes                         # number w/o digits, date, bool...

    def weight(self, config) -> int:
        """This column's contribution to the per-row weight W: its max cell width
        plus one byte per planned check (the boolean masks held in flight)."""
        return self.max_bytes(config) + len(self.checks) * config.mask_bytes
