"""Tests for schema/json_parser.py: parsing, named types, and error reporting."""

import pytest

from csv_validator import JsonSchemaParser
from csv_validator.schema.json_parser import SchemaError


def test_parse_basic_and_order():
    schema = {"properties": {
        "B": {"type": "string", "ColumnIndex": 2, "Mandatory": "No"},
        "A": {"type": "number", "ColumnIndex": 1, "Mandatory": "Yes"},
    }}
    cols = JsonSchemaParser(schema).parse()
    assert [c.name for c in cols] == ["A", "B"]             # sorted by ColumnIndex
    assert cols[0].mandatory is True
    assert cols[0].type == "number"


def test_named_type_reference_resolves_definition():
    # real-schema convention: `type` IS a definition name (not $ref)
    schema = {
        "definitions": {
            "Currency": {"type": "string", "Size": 3, "pattern": "^.{3}$"},
            "Sign": {"type": "string", "enum": ["+", "-"]},
        },
        "properties": {
            "Ccy": {"type": "Currency", "ColumnIndex": 1},
            "Sgn": {"type": "Sign", "ColumnIndex": 2},
        },
    }
    cols = {c.name: c for c in JsonSchemaParser(schema).parse()}
    assert cols["Ccy"].type == "string" and cols["Ccy"].pattern == "^.{3}$" and cols["Ccy"].max_length == 3
    assert cols["Sgn"].type == "string" and cols["Sgn"].allowed_values == ["+", "-"]


def test_decimal_digits_plural_and_singular():
    schema = {
        "definitions": {"decimal257": {"type": "number", "TotalDigits": 25, "FractionDigits": 7}},
        "properties": {
            "A": {"type": "decimal257", "ColumnIndex": 1},
            "B": {"type": "number", "TotalDigit": 25, "FractionDigit": 7, "ColumnIndex": 2},
        },
    }
    cols = {c.name: c for c in JsonSchemaParser(schema).parse()}
    assert (cols["A"].total_digits, cols["A"].fraction_digits) == (25, 7)
    assert (cols["B"].total_digits, cols["B"].fraction_digits) == (25, 7)


def test_future_field_flows_into_attributes():
    schema = {"properties": {"X": {"type": "number", "MaxValue": 100, "ColumnIndex": 1}}}
    col = JsonSchemaParser(schema).parse()[0]
    assert col.attr("MaxValue") == 100


def test_invalid_schema_raises_with_column_name():
    schema = {"properties": {"X": {"type": "string", "ColumnIndex": "not-an-int"}}}
    with pytest.raises(ValueError, match="column 'X'"):
        JsonSchemaParser(schema).parse()


def test_invalid_field_raises_schema_error():
    with pytest.raises(SchemaError):
        JsonSchemaParser('{"properties": {"A": {"type": "number", "minimum": "abc", "ColumnIndex": 1}}}').parse()


def test_missing_file_raises_filenotfound():
    with pytest.raises(FileNotFoundError):
        JsonSchemaParser("does_not_exist.json").parse()
