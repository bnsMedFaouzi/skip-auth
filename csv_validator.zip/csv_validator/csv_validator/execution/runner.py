"""Runner: evaluates every check in a single streaming Polars pass.

The whole validation is one `select`: the row count, plus — for each check — its
error count and a bounded sample, plus — for each column — how many rows fail at
least one of its checks. Each expression reduces to a length-1 cell, so they all
fit in one result row (one scan of the file).

Reading is keyed by the check's position in `flat` and by the column name, so the
build phase and the read phase never rely on a separate hand-kept counter.
"""

from __future__ import annotations

import polars as pl

from ..models import BoundCheck

ROW_IDX = "__row__"

# per check: (check_name, error_count, sample[(line, value)])
CheckData = tuple[str, int, list[tuple[int, str]]]
# per column: (column, failing_rows, [CheckData])
ColumnData = tuple[str, int, list[CheckData]]


class Runner:
    def run(
        self,
        lf: pl.LazyFrame,
        checks_by_column: dict[str, list[BoundCheck]],
        sample_size: int,
        engine: str = "streaming",
    ) -> tuple[int, list[ColumnData]]:
        lf = lf.with_row_index(ROW_IDX)
        flat = [(col, chk) for col, chks in checks_by_column.items() for chk in chks]

        exprs: list[pl.Expr] = [pl.len().alias("rows")]
        for i, (col, chk) in enumerate(flat):
            exprs += self._check_exprs(i, col, chk, sample_size)
        for col, chks in checks_by_column.items():
            exprs.append(self._column_fail_expr(col, chks))

        row = lf.select(exprs).collect(engine=engine).row(0, named=True)

        return int(row["rows"]), self._read(row, checks_by_column, flat)

    # -- expression building ------------------------------------------------

    @staticmethod
    def _check_exprs(i: int, column: str, chk: BoundCheck, sample_size: int) -> list[pl.Expr]:
        """count + a bounded sample of (line, value) for one check."""
        invalid = chk.invalid.fill_null(False)
        line = (pl.col(ROW_IDX) + 1).filter(invalid).head(sample_size)
        value = pl.col(column).cast(pl.Utf8).filter(invalid).head(sample_size)
        return [
            invalid.sum().alias(f"count:{i}"),
            line.implode().alias(f"lines:{i}"),
            value.implode().alias(f"values:{i}"),
        ]

    @staticmethod
    def _column_fail_expr(column: str, chks: list[BoundCheck]) -> pl.Expr:
        """count of rows failing at least one of the column's checks."""
        any_fail = pl.any_horizontal([c.invalid.fill_null(False) for c in chks])
        return any_fail.sum().alias(f"colfail:{column}")

    # -- result reading -----------------------------------------------------

    @staticmethod
    def _read(row: dict, checks_by_column: dict[str, list[BoundCheck]], flat: list) -> list[ColumnData]:
        # 1) one CheckData per check, grouped under its column
        by_column: dict[str, list[CheckData]] = {col: [] for col in checks_by_column}
        for i, (col, chk) in enumerate(flat):
            count = int(row[f"count:{i}"] or 0)
            sample = [
                (int(line), value if value is not None else "")
                for line, value in zip(row[f"lines:{i}"] or [], row[f"values:{i}"] or [])
            ]
            by_column[col].append((chk.check, count, sample))

        # 2) assemble per column, preserving column order
        return [
            (col, int(row[f"colfail:{col}"] or 0), by_column[col])
            for col in checks_by_column
        ]
