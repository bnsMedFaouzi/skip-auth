"""CSV data source (bounded-memory, block-by-block)."""

from __future__ import annotations

import io
import itertools
import logging
from collections.abc import Iterator
from pathlib import Path

import polars as pl

from .base import DataSource

logger = logging.getLogger(__name__)


class CsvDataSource(DataSource):
    """CSV file read in row blocks, every column as text.

    Each block is a small lazy scan collected by the caller, so peak memory
    depends on the block size, not the file size. Reading as text avoids implicit
    conversions and enables faithful lexical validation.

    Note: blocks are split on physical newlines; this assumes fields do not
    contain embedded newlines (true for the target inventory files).
    """

    def __init__(self, path: str | Path) -> None:
        self._path = Path(path)
        self._header: list[str] | None = None
        self._columns: list[str] | None = None
        self._trailing_empty: bool | None = None

    def _raw_columns(self) -> list[str]:
        """The CSV header exactly as written (may include a trailing empty column)."""
        if self._header is None:
            # Lazy: resolves the schema from the header only (does not read the
            # whole file, unlike `read_csv(path, n_rows=0)`).
            self._header = pl.scan_csv(self._path).collect_schema().names()
        return self._header

    def columns(self) -> list[str]:
        """The logical columns to validate.

        A trailing comma produces an empty-named last column; it is detected and
        dropped here so it is not validated as a real column. If none is present,
        a warning is logged.
        """
        if self._columns is None:
            raw = list(self._raw_columns())
            self._trailing_empty = bool(raw) and raw[-1].strip() == ""
            self._columns = raw[:-1] if self._trailing_empty else raw
            if not self._trailing_empty:
                logger.warning("No trailing empty column found (expected a trailing comma).")
        return self._columns

    def iter_frames(self, batch_size: int) -> Iterator[pl.LazyFrame]:
        overrides = {c: pl.Utf8 for c in self._raw_columns()}
        with open(self._path, "rb") as fh:
            header = fh.readline()
            while True:
                lines = list(itertools.islice(fh, batch_size))
                if not lines:
                    break
                # Yield a lazy scan of this N-line block; the caller adds its
                # expressions and collects once. Boundedness comes from slicing
                # to N lines here, not from the reader.
                yield pl.scan_csv(
                    io.BytesIO(header + b"".join(lines)),
                    schema_overrides=overrides,
                    infer_schema_length=0,
                    low_memory=True,
                )
