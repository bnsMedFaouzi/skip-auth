"""Runner: evaluates checks block by block, in bounded memory.

Per block, each check's boolean mask is materialized once (`with_columns`), then
reused for its count, for the column's failing-row count, and for its sample —
so the expensive regex/date/precision work is done a single time. Samples are
collected only while a check still needs them (stops once `sample_size` reached),
and line + value are pulled in one filter via a struct.

Peak memory is bounded by the block size, independent of the file size.
"""

from __future__ import annotations

from collections.abc import Iterable

import polars as pl

from ..models import BoundCheck

ROW_IDX = "__row__"

CheckData = tuple[str, int, list[tuple[int, str]]]     # (check, error_count, sample)
ColumnData = tuple[str, int, list[CheckData]]          # (column, failing_rows, checks)


class Runner:
    def run(
        self,
        blocks: Iterable[pl.DataFrame],
        checks_by_column: dict[str, list[BoundCheck]],
        sample_size: int,
        engine: str = "streaming",
    ) -> tuple[int, list[ColumnData]]:
        flat = [(col, chk) for col, chks in checks_by_column.items() for chk in chks]
        col_indices: dict[str, list[int]] = {}
        for i, (col, _) in enumerate(flat):
            col_indices.setdefault(col, []).append(i)

        total_rows = 0
        counts = [0] * len(flat)
        samples: list[list[tuple[int, str]]] = [[] for _ in flat]
        needs_sample = [sample_size > 0 for _ in flat]
        colfail = {col: 0 for col in checks_by_column}

        for block in blocks:
            offset = total_rows
            row = self._eval_block(block, flat, col_indices, sample_size, needs_sample, engine)
            total_rows += int(row["rows"])
            self._accumulate(row, flat, offset, sample_size, counts, samples, needs_sample, colfail)

        return total_rows, self._assemble(checks_by_column, flat, counts, samples, colfail)

    # -- one select over one block (masks materialized once) ----------------

    def _eval_block(self, block, flat, col_indices, sample_size, needs_sample, engine) -> dict:
        lf = block.lazy().with_row_index(ROW_IDX).with_columns(
            [chk.invalid.fill_null(False).alias(f"m{i}") for i, (_, chk) in enumerate(flat)]
        )
        exprs: list[pl.Expr] = [pl.len().alias("rows")]
        for i, (col, _) in enumerate(flat):
            exprs.append(pl.col(f"m{i}").sum().alias(f"count:{i}"))
            if needs_sample[i]:
                exprs.append(self._sample_expr(i, col, sample_size))
        for col, idxs in col_indices.items():
            exprs.append(
                pl.any_horizontal([pl.col(f"m{k}") for k in idxs]).sum().alias(f"colfail:{col}")
            )
        return lf.select(exprs).collect(engine=engine).row(0, named=True)

    @staticmethod
    def _sample_expr(i: int, column: str, sample_size: int) -> pl.Expr:
        pair = pl.struct(
            (pl.col(ROW_IDX) + 1).alias("line"),
            pl.col(column).cast(pl.Utf8).alias("value"),
        )
        return pair.filter(pl.col(f"m{i}")).head(sample_size).implode().alias(f"sample:{i}")

    # -- accumulation across blocks -----------------------------------------

    @staticmethod
    def _accumulate(row, flat, offset, sample_size, counts, samples, needs_sample, colfail) -> None:
        for i, _ in enumerate(flat):
            counts[i] += int(row[f"count:{i}"] or 0)
            if needs_sample[i]:
                for pair in row[f"sample:{i}"] or []:
                    if len(samples[i]) >= sample_size:
                        break
                    value = pair["value"]
                    samples[i].append((offset + int(pair["line"]), value if value is not None else ""))
                if len(samples[i]) >= sample_size:
                    needs_sample[i] = False
        for col in colfail:
            colfail[col] += int(row[f"colfail:{col}"] or 0)

    @staticmethod
    def _assemble(checks_by_column, flat, counts, samples, colfail) -> list[ColumnData]:
        by_column: dict[str, list[CheckData]] = {col: [] for col in checks_by_column}
        for i, (col, chk) in enumerate(flat):
            by_column[col].append((chk.check, counts[i], samples[i]))
        return [(col, colfail[col], by_column[col]) for col in checks_by_column]
