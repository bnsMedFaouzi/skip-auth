"""Tests for models/config.py: schema-weight memory model and batch sizing."""

from csv_validator import EngineConfig


class _Col:
    """Minimal stand-in for ColumnDef (row_weight only reads type + max_length)."""
    def __init__(self, type, max_length=None):
        self.type = type
        self.max_length = max_length


def test_forced_batch_size_wins():
    assert EngineConfig(row_batch_size=1234).batch_for(1000.0) == 1234


def test_row_weight_from_schema():
    cfg = EngineConfig()
    cols = [_Col("string", 40), _Col("number"), _Col("string")]   # 40 + numeric(12) + string default(64)
    assert cfg.row_weight(cols, num_checks=3) == 40 + 12 + 64 + 3   # + 1 byte per check


def test_heavier_schema_gives_smaller_batch():
    cfg = EngineConfig()
    light = cfg.batch_for(100.0)
    heavy = cfg.batch_for(3000.0)
    assert heavy < light
    assert cfg.min_batch <= heavy <= cfg.max_batch
    assert cfg.min_batch <= light <= cfg.max_batch


def test_auto_batch_hits_margined_target():
    cfg = EngineConfig()
    W = 1000.0
    b = cfg.batch_for(W)
    if cfg.min_batch < b < cfg.max_batch:                          # not clamped
        peak = cfg.estimated_peak_mb(b, W)
        assert abs(peak - cfg.target_memory_mb * (1 - cfg.safety_margin)) < 5


def test_model_fields_are_configurable():
    cfg = EngineConfig(mem_base=80, mem_coeff=0.01, mem_exponent=0.5,
                       min_batch=1000, max_batch=50_000)
    assert cfg.min_batch <= cfg.batch_for(500.0) <= cfg.max_batch
