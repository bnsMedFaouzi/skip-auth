"""JSON schema parser (JSON-Schema draft-07 style), validated with Pydantic.

Resolves references two ways (both seen in real schemas):
  - `$ref`: {"$ref": "#/definitions/Currency"}
  - named type: {"type": "Currency"}   (the type IS a definition name)

Then validates each entry into a `PropertySchema` and maps it to a `ColumnDef`.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from pydantic import ValidationError

from ..models import ColumnDef, PropertySchema, RawSchema
from .base import SchemaParser

_TYPE_ALIASES = {
    "str": "string", "text": "string",
    "int": "integer", "integer": "integer",
    "number": "number", "decimal": "number", "float": "number", "double": "number",
    "timestamp": "timestamp", "datetime": "timestamp",
    "date": "date", "boolean": "boolean", "bool": "boolean",
}
# primitive type tokens: anything else in `type` is treated as a definition name
_PRIMITIVES = set(_TYPE_ALIASES) | {"string"}
_TRUE = {"yes", "true", "y", "1"}


class SchemaError(ValueError):
    """Raised for malformed schemas (bad ref, cycle, invalid property)."""


class JsonSchemaParser(SchemaParser):
    def __init__(self, source: str | Path | dict[str, Any]) -> None:
        self._source = source

    def parse(self) -> list[ColumnDef]:
        raw = RawSchema.model_validate(self._load())
        columns = [
            self._to_column(name, self._resolve(name, node, raw.definitions, frozenset()))
            for name, node in raw.properties.items()
        ]
        columns.sort(key=lambda c: (c.order is None, c.order if c.order is not None else 0))
        return columns

    # -- loading ------------------------------------------------------------

    def _load(self) -> dict[str, Any]:
        if isinstance(self._source, dict):
            return self._source
        p = Path(self._source)
        if p.exists():
            return json.loads(p.read_text(encoding="utf-8"))
        if isinstance(self._source, str) and self._source.lstrip()[:1] in "{[":
            return json.loads(self._source)
        raise FileNotFoundError(f"Schema file not found: {self._source}")

    # -- reference resolution ($ref + named type) ---------------------------

    def _resolve(
        self, name: str, node: dict[str, Any], definitions: dict[str, dict], seen: frozenset
    ) -> dict[str, Any]:
        # 1) $ref
        ref = node.get("$ref")
        if ref:
            key = ref.split("/")[-1]
            if key not in definitions:
                raise SchemaError(f"Column '{name}': unknown $ref '{ref}'")
            if key in seen:
                raise SchemaError(f"Column '{name}': circular $ref via '{key}'")
            base = self._resolve(name, dict(definitions[key]), definitions, seen | {key})
            node = {**base, **{k: v for k, v in node.items() if k != "$ref"}}

        # 2) named type: `type` is a definition name (not a primitive)
        t = node.get("type")
        if isinstance(t, str) and t.lower() not in _PRIMITIVES and t in definitions:
            if t in seen:
                raise SchemaError(f"Column '{name}': circular type reference via '{t}'")
            base = self._resolve(name, dict(definitions[t]), definitions, seen | {t})
            # definition provides the real type + constraints; property keys win
            node = {**base, **{k: v for k, v in node.items() if k != "type"}}

        return node

    # -- mapping to ColumnDef ----------------------------------------------

    def _to_column(self, name: str, node: dict[str, Any]) -> ColumnDef:
        try:
            prop = PropertySchema.model_validate(node)
        except ValidationError as exc:
            raise SchemaError(f"Invalid schema for column '{name}': {exc}") from exc

        raw_type = (prop.type or "string").lower()
        base_type = _TYPE_ALIASES.get(raw_type, raw_type)
        return ColumnDef(
            name=name,
            base_type=base_type,
            mandatory=prop.mandatory.strip().lower() in _TRUE,
            order=prop.column_index,
            max_length=prop.size,
            allowed_values=prop.authorize_value or prop.enum,
            pattern=prop.pattern,
            minimum=prop.minimum,
            total_digits=int(prop.total_digits) if prop.total_digits is not None else None,
            fraction_digits=int(prop.fraction_digits) if prop.fraction_digits is not None else None,
            date_format=prop.date_format,
            label=prop.information_item,
            attributes=node,
        )
