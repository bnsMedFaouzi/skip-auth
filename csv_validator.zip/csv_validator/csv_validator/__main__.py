"""Command-line interface.

    python -m csv_validator SCHEMA.json DATA.csv [--json] [--sample N]
"""

from __future__ import annotations

import argparse
import sys

from .models import EngineConfig
from .execution import validate


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="csv_validator", description="Validate a CSV against a JSON schema.")
    parser.add_argument("schema", help="path to the JSON schema")
    parser.add_argument("csv", help="path to the CSV file")
    parser.add_argument("--json", action="store_true", help="output the report as JSON")
    parser.add_argument("--sample", type=int, default=20, help="error sample size per check")
    parser.add_argument("--no-streaming", action="store_true", help="disable the Polars streaming engine")
    parser.add_argument("--show-clean", action="store_true", help="also show columns with no errors")
    args = parser.parse_args(argv)

    config = EngineConfig(sample_size=args.sample, streaming=not args.no_streaming)
    report = validate(args.schema, args.csv, config=config)

    print(report.model_dump_json(indent=2) if args.json else report.to_text(show_clean=args.show_clean))
    return 0 if report.status == "VALID" else 1


if __name__ == "__main__":
    sys.exit(main())
