"""Pydantic models of the raw JSON schema.

A `DefinitionSchema` describes a reusable named type (its type + constraints).
A `PropertySchema` is a column spec: it *is* a definition (same constraints)
plus column-level fields (Size, Mandatory, ColumnIndex...). It may reference a
definition through its `type`. Both normalize source keys to clean field names
and coerce values, so a `ColumnDef` can be built straight from a property.
"""

from __future__ import annotations

from pydantic import AliasChoices, BaseModel, ConfigDict, Field, field_validator

_TRUE = {"yes", "true", "y", "1"}


class DefinitionSchema(BaseModel):
    """A reusable named type: a base type and its value constraints."""

    model_config = ConfigDict(populate_by_name=True, extra="allow")

    type: str = "string"
    pattern: str | None = None
    allowed_values: list[str] | None = Field(
        None, validation_alias=AliasChoices("AuthorizeValue", "enum", "allowed_values")
    )
    minimum: float | None = None
    total_digits: int | None = Field(
        None, validation_alias=AliasChoices("TotalDigits", "TotalDigit", "total_digits")
    )
    fraction_digits: int | None = Field(
        None, validation_alias=AliasChoices("FractionDigits", "FractionDigit", "fraction_digits")
    )
    date_format: str | None = Field(
        None, validation_alias=AliasChoices("Format", "DateFormat", "date_format")
    )

    @field_validator("total_digits", "fraction_digits", mode="before")
    @classmethod
    def _to_int(cls, value: object) -> int | None:
        """Coerce a digit count to int (tolerates float typos like 9.9)."""
        return int(value) if value is not None else None


class PropertySchema(DefinitionSchema):
    """A column spec: a definition plus column-level fields."""

    mandatory: bool = Field(False, validation_alias=AliasChoices("Mandatory", "mandatory"))
    max_length: int | None = Field(None, validation_alias=AliasChoices("Size", "max_length"))
    order: int | None = Field(None, validation_alias=AliasChoices("ColumnIndex", "order"))
    label: str | None = Field(None, validation_alias=AliasChoices("InformationItem", "label"))

    @field_validator("mandatory", mode="before")
    @classmethod
    def _to_bool(cls, value: object) -> bool:
        """Accept a bool or a 'Yes'/'No'-style string."""
        return value if isinstance(value, bool) else str(value).strip().lower() in _TRUE


class RawSchema(BaseModel):
    """Top level of the JSON schema — definitions and properties, both validated."""

    model_config = ConfigDict(populate_by_name=True, extra="ignore")

    definitions: dict[str, DefinitionSchema] = Field(default_factory=dict)
    properties: dict[str, PropertySchema] = Field(default_factory=dict)
