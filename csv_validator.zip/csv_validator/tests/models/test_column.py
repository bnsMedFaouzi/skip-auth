"""Tests for models/column.py: per-column max width and weight."""

from csv_validator import EngineConfig, JsonSchemaParser


def _col(**props):
    return JsonSchemaParser({"properties": {"C": {"ColumnIndex": 1, **props}}}).parse()[0]


def test_max_bytes_uses_size():
    assert _col(type="string", Size=40).max_bytes(EngineConfig()) == 40


def test_max_bytes_uses_total_digits():
    assert _col(type="number", TotalDigit=25).max_bytes(EngineConfig()) == 27   # digits + sign + point


def test_max_bytes_defaults_per_kind():
    cfg = EngineConfig()
    assert _col(type="string").max_bytes(cfg) == cfg.default_string_bytes        # un-sized string
    assert _col(type="number").max_bytes(cfg) == cfg.default_other_bytes         # no TotalDigit


def test_weight_adds_one_byte_per_check():
    cfg = EngineConfig()
    col = _col(type="string", Size=40)
    col.checks = [object(), object(), object()]                                  # 3 masks
    assert col.weight(cfg) == 40 + 3 * cfg.mask_bytes
