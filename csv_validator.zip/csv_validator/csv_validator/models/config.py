"""Engine configuration (Pydantic)."""

from __future__ import annotations

from pydantic import BaseModel


class EngineConfig(BaseModel):
    """Centralized engine parameters."""

    sample_size: int = 20            # bounded error sample per check
    streaming: bool = True           # use the Polars streaming engine

    # header / file structure
    strict_column_order: bool = True     # columns must match the schema order
    header_gate: bool = True             # invalid header stops value validation
    allow_extra_columns: bool = False    # tolerate CSV columns not in the schema

    # default date/timestamp formats, used when a column does not provide one
    default_date_format: str = "%Y-%m-%d"
    default_timestamp_format: str = "%Y-%m-%dT%H:%M:%S"

    # Rows per batch: bounds peak memory (a batch is evaluated then discarded).
    # Leave as None to size it automatically so peak memory stays near
    # `target_memory_mb`; set an int to force it (best for known, measured files).
    row_batch_size: int | None = None
    target_memory_mb: int = 300          # memory budget the auto batch aims for
    safety_margin: float = 0.15          # aim for (1 - margin) x target, since we predict

    # --- Peak-memory model -------------------------------------------------- #
    # Peak is driven by the bytes held in one batch, which is
    #   x = batch_rows * W,  W = sum of per-column text widths + one byte per check.
    # Memory grows SUB-linearly with x (buffers amortize), so:
    #   peak_mb ~= mem_base + mem_coeff * x ** mem_exponent
    # W is computed from the schema (types + Size), so no per-file measurement is
    # needed. IMPORTANT: the coefficients below are calibrated on SYNTHETIC data;
    # recalibrate them on your own corpus (see the calibration tool) — real values
    # have variable text length, so `mem_coeff` in particular will differ.
    mem_base: float = 50.0           # fixed floor: interpreter + Polars
    mem_coeff: float = 0.00155        # scale of the sub-linear term
    mem_exponent: float = 0.700      # sub-linear exponent (< 1)

    # Per-cell MAX text width (bytes) for columns WITHOUT a `Size` in the schema.
    # Un-sized strings can be wide (use the large default); numbers/dates/booleans
    # are genuinely small. Raise `default_string_bytes` if you have wide un-sized
    # text columns; it only affects columns that lack a Size.
    default_string_bytes: int = 64   # string column with no Size
    default_numeric_bytes: int = 12  # number / date / boolean (small, fixed width)
    mask_bytes: int = 1              # per-check boolean mask contribution to W

    min_batch: int = 5_000           # keep batching efficiency on very wide schemas
    max_batch: int = 200_000         # cap on very narrow schemas

    @property
    def engine_mode(self) -> str:
        """The Polars collect engine: streaming when enabled, else auto."""
        return "streaming" if self.streaming else "auto"

    def row_weight(self, columns, num_checks: int = 0) -> float:
        """Maximum bytes held per row for this schema (the model's `W`).

        Each column contributes its `Size` when the schema gives one, else a
        default (large for un-sized strings, small for numbers/dates), plus one
        byte per check. Computed from the schema alone — an upper bound, so the
        sized batch never under-provisions.
        """
        total = 0
        for col in columns:
            if col.max_length:
                total += col.max_length
            elif col.type == "string":
                total += self.default_string_bytes
            else:
                total += self.default_numeric_bytes
        return total + num_checks * self.mask_bytes

    def batch_for(self, row_weight: float) -> int:
        """Rows per batch for a schema whose per-row weight is `row_weight`.

        Returns `row_batch_size` if set. Otherwise inverts the peak-memory model
        to find the largest batch whose predicted peak stays under the (margined)
        target, clamped to [min_batch, max_batch].
        """
        if self.row_batch_size is not None:
            return self.row_batch_size
        target = self.target_memory_mb * (1.0 - self.safety_margin)
        budget = max(target - self.mem_base, 1.0)
        x = (budget / self.mem_coeff) ** (1.0 / self.mem_exponent)   # = batch * row_weight
        rows = int(x / max(row_weight, 1.0))
        return max(self.min_batch, min(rows, self.max_batch))

    def estimated_peak_mb(self, batch_rows: int, row_weight: float) -> float:
        """Predicted peak memory (MB) for a given batch and schema weight."""
        return self.mem_base + self.mem_coeff * (batch_rows * row_weight) ** self.mem_exponent
