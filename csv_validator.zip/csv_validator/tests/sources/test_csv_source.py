"""Tests for sources/csv_source.py: header handling and the source name."""

import logging

from csv_validator import CsvDataSource, validate

_SCHEMA = {"properties": {"a": {"type": "number", "ColumnIndex": 1},
                          "b": {"type": "number", "ColumnIndex": 2}}}


def test_trailing_empty_column_removed(tmp_file):
    csv = tmp_file("a;b;\n1;2;\n3;4;\n")                    # trailing separator -> empty last column
    report = validate(_SCHEMA, csv)
    assert report.file.columns_present == 2                # phantom column dropped
    assert report.file.unexpected_columns == []


def test_missing_trailing_column_warns(tmp_file, caplog):
    csv = tmp_file("a;b\n1;2\n")                            # no trailing separator
    with caplog.at_level(logging.WARNING):
        validate(_SCHEMA, csv)
    assert any("No trailing empty column" in m for m in caplog.messages)


def test_source_exposes_name(tmp_file):
    csv = tmp_file("a;b\n1;2\n")
    assert CsvDataSource(csv).name.endswith(".csv")
