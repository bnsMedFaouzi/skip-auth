"""Constraints: atomic validity rules, as objects (Strategy).

A `Constraint` knows when it concerns a column (`applies`) and the invalid mask
it produces (`mask`). A type validator folds the applicable ones into a single
check. Adding a rule = a new `Constraint` class, reusable across types and
attachable at runtime via `registry.add_constraint(...)` — no existing code
changes (open/closed).
"""

from __future__ import annotations

from abc import ABC, abstractmethod

import polars as pl

from ..models.column import ColumnDef


def text(name: str) -> pl.Expr:
    """The column read as text (all validation is lexical)."""
    return pl.col(name).cast(pl.Utf8)


class Constraint(ABC):
    """One validity rule producing an 'invalid' mask when it concerns a column."""

    @abstractmethod
    def applies(self, col: ColumnDef) -> bool:
        """Whether this rule concerns the column (e.g. the field is present)."""

    @abstractmethod
    def mask(self, col: ColumnDef) -> pl.Expr:
        """Boolean mask, True where the (non-empty) cell violates the rule."""


# --- base-type format constraints (always active inside their type) ----------

class NumberFormat(Constraint):
    """The text must be a decimal number.

    Accepts '.' or ',' as the decimal separator, and a leading separator with no
    integer part ('.5', ',5'). Examples: 1, -1, 1.5, 1,5, +.5, -,25.
    """

    _RE = r"^[+-]?(\d+([.,]\d+)?|[.,]\d+)$"

    def applies(self, col: ColumnDef) -> bool:
        return True

    def mask(self, col: ColumnDef) -> pl.Expr:
        return ~text(col.name).str.contains(self._RE)


class IntegerFormat(Constraint):
    """The text must be an integer."""

    _RE = r"^[+-]?\d+$"

    def applies(self, col: ColumnDef) -> bool:
        return True

    def mask(self, col: ColumnDef) -> pl.Expr:
        return ~text(col.name).str.contains(self._RE)


class BooleanFormat(Constraint):
    """The text must be a recognized boolean token."""

    _OK = ["true", "false", "0", "1", "y", "n", "yes", "no"]

    def applies(self, col: ColumnDef) -> bool:
        return True

    def mask(self, col: ColumnDef) -> pl.Expr:
        return ~text(col.name).str.to_lowercase().is_in(self._OK)


class DateFormat(Constraint):
    """The text must parse as a date in the column's format (or a default)."""

    def __init__(self, default_format: str) -> None:
        self._default = default_format

    def applies(self, col: ColumnDef) -> bool:
        return True

    def mask(self, col: ColumnDef) -> pl.Expr:
        fmt = col.date_format or self._default
        return text(col.name).str.to_date(format=fmt, strict=False).is_null()


class TimestampFormat(Constraint):
    """The text must parse as a datetime in the column's format (or a default)."""

    def __init__(self, default_format: str) -> None:
        self._default = default_format

    def applies(self, col: ColumnDef) -> bool:
        return True

    def mask(self, col: ColumnDef) -> pl.Expr:
        fmt = col.date_format or self._default
        return text(col.name).str.to_datetime(format=fmt, strict=False).is_null()


# --- value constraints (active when the matching field is present) -----------

class Minimum(Constraint):
    """The numeric value must be >= the column's minimum."""

    def applies(self, col: ColumnDef) -> bool:
        return col.minimum is not None

    def mask(self, col: ColumnDef) -> pl.Expr:
        numeric = text(col.name).str.replace(",", ".", literal=True).cast(pl.Float64, strict=False)
        return numeric < col.minimum


class Precision(Constraint):
    """Lexical decimal precision (preserves precision — no float cast).

    Counts digits directly (`count_matches`) and reads the fractional part with a
    single `extract`, avoiding per-cell intermediate strings — ~25% faster than
    strip/replace/split while giving identical results.
    """

    def applies(self, col: ColumnDef) -> bool:
        return col.total_digits is not None or col.fraction_digits is not None

    def mask(self, col: ColumnDef) -> pl.Expr:
        cell = text(col.name)
        conditions: list[pl.Expr] = []
        if col.total_digits is not None:
            conditions.append(cell.str.count_matches(r"[0-9]") > col.total_digits)
        if col.fraction_digits is not None:
            frac_len = cell.str.extract(r"[.,](\d+)", 1).str.len_chars().fill_null(0)
            conditions.append(frac_len > col.fraction_digits)
        return pl.any_horizontal(conditions)


class MaxLength(Constraint):
    """The text must not exceed the column's max length."""

    def applies(self, col: ColumnDef) -> bool:
        return col.max_length is not None

    def mask(self, col: ColumnDef) -> pl.Expr:
        return text(col.name).str.len_chars() > col.max_length


class Enum(Constraint):
    """The text must be one of the column's allowed values."""

    def applies(self, col: ColumnDef) -> bool:
        return bool(col.allowed_values)

    def mask(self, col: ColumnDef) -> pl.Expr:
        return ~text(col.name).is_in(col.allowed_values)


class Pattern(Constraint):
    """The text must match the column's pattern."""

    def applies(self, col: ColumnDef) -> bool:
        return bool(col.pattern)

    def mask(self, col: ColumnDef) -> pl.Expr:
        return ~text(col.name).str.contains(col.pattern)
