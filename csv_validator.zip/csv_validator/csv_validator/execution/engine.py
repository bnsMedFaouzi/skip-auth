"""Validation engine (Facade).

- One streaming pass per file (Runner.run).
- `validate_async` runs the pass off the event loop (non-blocking).
- `validate_many_async` validates several files concurrently on the loop — the
  case where the event loop genuinely pays off (Polars releases the GIL, so the
  file passes run in parallel).
"""

from __future__ import annotations

import asyncio
from pathlib import Path

from ..models import CheckResult, EngineConfig, ReportBuilder, ValidationReport
from ..schema import JsonSchemaParser, SchemaParser
from ..sources import CsvDataSource, DataSource
from ..validators import ValidatorRegistry, default_registry
from .runner import Runner


class ValidationEngine:
    """Orchestrates parsing (Planner) and running (Runner)."""

    def __init__(
        self,
        schema_parser: SchemaParser,
        data_source: DataSource,
        registry: ValidatorRegistry | None = None,
        config: EngineConfig | None = None,
        runner: Runner | None = None,
    ) -> None:
        self._schema_parser = schema_parser
        self._data_source = data_source
        self._registry = registry or default_registry()
        self._config = config or EngineConfig()
        self._runner = runner or Runner()

    def validate(self) -> ValidationReport:
        try:
            asyncio.get_running_loop()
        except RuntimeError:
            return asyncio.run(self.validate_async())
        raise RuntimeError("An event loop is already running; use `await engine.validate_async()`.")

    async def validate_async(self) -> ValidationReport:
        columns = self._schema_parser.parse()
        csv_columns = set(self._data_source.columns())
        lf = self._data_source.frame()

        present = [c for c in columns if c.name in csv_columns]
        missing = [c.name for c in columns if c.name not in csv_columns]
        builder = ReportBuilder().set_missing_columns(missing)

        checks = self._plan(present)
        rows, outcomes = await asyncio.to_thread(
            self._runner.run, lf, checks, self._config.sample_size, self._config.engine_mode
        )
        for chk, count, sample in outcomes:
            builder.add_result(CheckResult(column=chk.column, check=chk.check,
                                           error_count=count, sample=sample))
        return builder.build(rows, len(present))

    def _plan(self, present):
        return [chk for col in present for chk in self._registry.checks_for(col)]


# --- convenience facades ---------------------------------------------------

def _engine(schema_source, csv_path, registry, config) -> ValidationEngine:
    return ValidationEngine(
        JsonSchemaParser(schema_source), CsvDataSource(csv_path), registry, config
    )


def validate(schema_source, csv_path: str | Path, *,
             config: EngineConfig | None = None,
             registry: ValidatorRegistry | None = None) -> ValidationReport:
    """Sync facade: validate one CSV against a JSON schema."""
    return _engine(schema_source, csv_path, registry, config).validate()


async def validate_async(schema_source, csv_path: str | Path, *,
                         config: EngineConfig | None = None,
                         registry: ValidatorRegistry | None = None) -> ValidationReport:
    """Async facade: awaitable validation of one file."""
    return await _engine(schema_source, csv_path, registry, config).validate_async()


async def validate_many_async(jobs, *, config: EngineConfig | None = None,
                              registry: ValidatorRegistry | None = None) -> list[ValidationReport]:
    """Validate several (schema, csv) pairs concurrently on the event loop."""
    tasks = [
        _engine(schema, csv, registry, config).validate_async()
        for schema, csv in jobs
    ]
    return await asyncio.gather(*tasks)


def validate_many(jobs, *, config: EngineConfig | None = None,
                  registry: ValidatorRegistry | None = None) -> list[ValidationReport]:
    """Sync wrapper around `validate_many_async`."""
    return asyncio.run(validate_many_async(jobs, config=config, registry=registry))
