"""Tests for models/report.py: ReportBuilder + ValidationReport rendering."""

from csv_validator import validate
from csv_validator.models.report import (
    CheckMetric, ColumnMetrics, FileMetrics, ReportBuilder, ReportMetadata, ValidationReport,
)


def _sample_report(**file_kw) -> ValidationReport:
    file = FileMetrics(rows=10, columns_expected=3, columns_present=3, total_errors=3, **file_kw)
    cols = [
        ColumnMetrics(column="C", failing_rows=0, failure_rate=0.0, error_count=0, checks=[]),
        ColumnMetrics(column="A", failing_rows=2, failure_rate=0.2, error_count=2, checks=[
            CheckMetric(check="type:number", error_count=2, failure_rate=0.2,
                        sample=[(2, "x"), (3, "")])]),
        ColumnMetrics(column="B", failing_rows=1, failure_rate=0.1, error_count=1, checks=[
            CheckMetric(check="mandatory", error_count=1, failure_rate=0.1, sample=[(4, "")])]),
    ]
    return ReportBuilder().build(file, cols, file_name="data.csv", duration_seconds=1.2345)


def test_builder_status_sort_and_metadata():
    r = _sample_report()
    assert r.status == "INVALID_DATA"
    assert r.is_valid is False
    assert r.total_errors == 3
    assert [c.column for c in r.columns] == ["A", "B", "C"]      # worst-first
    assert r.metadata.file_name == "data.csv"
    assert r.metadata.validated_at                                # auto-filled


def test_to_text_failing_only_and_empty_value():
    text = _sample_report().to_text()
    assert "status : INVALID_DATA" in text
    assert "file            : data.csv" in text
    assert "duration        : 1.234s" in text
    assert "column metrics (failing columns)" in text
    assert "(empty)" in text                                     # empty sample value rendered
    assert "1 column(s) checked with no errors." in text         # the clean column C


def test_to_text_show_clean_and_structure_flags():
    r = _sample_report(missing_columns=["X"], unexpected_columns=["Y"],
                       order_ok=False, structure_valid=False, stopped_at="header")
    text = r.to_text(show_clean=True)
    assert r.status == "INVALID_STRUCTURE"                        # structure invalid wins
    assert "missing_columns : X" in text
    assert "extra_columns   : Y" in text
    assert "stopped_at      : header" in text
    assert "column metrics" in text and "no errors" not in text  # show_clean lists every column


def test_valid_report_and_metadata_defaults():
    file = FileMetrics(rows=5, columns_expected=1, columns_present=1, total_errors=0)
    r = ReportBuilder().build(file, [])
    assert r.status == "VALID" and r.is_valid is True
    assert "status : VALID" in r.to_text()
    assert ReportMetadata().validated_at                         # default factory runs


def test_report_is_json_serializable(example):
    report = validate(example / "passive_sr_schema.json", example / "sample_data.csv")
    js = report.model_dump_json()
    assert '"file"' in js and '"columns"' in js
