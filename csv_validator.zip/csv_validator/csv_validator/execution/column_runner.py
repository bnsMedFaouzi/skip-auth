"""Per-column checks, evaluated block by block with Polars (bounded memory).

For each block, every check's boolean mask is materialized once and reused for
its error count, its column's failing-row count, and its bounded sample; a
check's sample collection stops once it is full. Line numbers are offset by the
number of rows seen before the block.
"""

from __future__ import annotations

import polars as pl

from ..models import BoundCheck
from .runner import BlockProcessor

ROW_IDX = "__row__"

CheckData = tuple[str, int, list[tuple[int, str]]]     # (check, error_count, sample)
ColumnData = tuple[str, int, list[CheckData]]          # (column, failing_rows, checks)


class ColumnRunner(BlockProcessor):
    """Accumulates per-column check results across blocks."""

    def __init__(self, checks_by_column: dict[str, list[BoundCheck]], sample_size: int) -> None:
        self._by_column = checks_by_column
        self._sample_size = sample_size
        self._flat = [(col, chk) for col, chks in checks_by_column.items() for chk in chks]
        self._col_indices = self._group_by_column()
        self._counts = [0] * len(self._flat)
        self._samples: list[list[tuple[int, str]]] = [[] for _ in self._flat]
        self._needs_sample = [sample_size > 0 for _ in self._flat]
        self._colfail = {col: 0 for col in checks_by_column}

    def _group_by_column(self) -> dict[str, list[int]]:
        """Map each column to the indices of its checks in the flat list."""
        indices: dict[str, list[int]] = {col: [] for col in self._by_column}
        for i, (col, _) in enumerate(self._flat):
            indices[col].append(i)
        return indices

    # -- BlockProcessor interface -------------------------------------------

    def update(self, block: pl.LazyFrame, offset: int) -> int:
        row = self._evaluate(block)
        self._accumulate(row, offset)
        return int(row["rows"])

    def result(self) -> list[ColumnData]:
        return self._assemble()

    # -- one Polars pass over one block -------------------------------------

    def _evaluate(self, block: pl.LazyFrame) -> dict:
        """Add the masks and aggregates to the lazy block, then collect once.

        The single collect lets Polars fuse scan + masks + aggregation, so only
        the one-row result is materialized.
        """
        return (
            block.with_row_index(ROW_IDX)
            .with_columns(self._mask_columns())
            .select(self._aggregates())
            .collect()
            .row(0, named=True)
        )

    def _mask_columns(self) -> list[pl.Expr]:
        """One boolean column per check, computed a single time."""
        return [chk.invalid.fill_null(False).alias(f"m{i}") for i, (_, chk) in enumerate(self._flat)]

    def _aggregates(self) -> list[pl.Expr]:
        """Row count + per-check count and sample + per-column failing-row count."""
        counts = (pl.col(f"m{i}").sum().alias(f"count:{i}") for i in range(len(self._flat)))
        samples = (self._sample_expr(i) for i in range(len(self._flat)) if self._needs_sample[i])
        colfail = (self._colfail_expr(col, idxs) for col, idxs in self._col_indices.items())
        return [pl.len().alias("rows"), *counts, *samples, *colfail]

    def _sample_expr(self, i: int) -> pl.Expr:
        """A bounded (line, value) sample for check `i`, pulled in one filter."""
        column = self._flat[i][0]
        pair = pl.struct(
            (pl.col(ROW_IDX) + 1).alias("line"),
            pl.col(column).cast(pl.Utf8).alias("value"),
        )
        return pair.filter(pl.col(f"m{i}")).head(self._sample_size).implode().alias(f"sample:{i}")

    @staticmethod
    def _colfail_expr(column: str, indices: list[int]) -> pl.Expr:
        """Count of rows failing at least one of the column's checks."""
        return pl.any_horizontal([pl.col(f"m{k}") for k in indices]).sum().alias(f"colfail:{column}")

    # -- accumulation across blocks -----------------------------------------

    def _accumulate(self, row: dict, offset: int) -> None:
        for i in range(len(self._flat)):
            self._counts[i] += int(row[f"count:{i}"] or 0)
            if self._needs_sample[i]:
                self._collect_sample(i, row, offset)
        for column in self._colfail:
            self._colfail[column] += int(row[f"colfail:{column}"] or 0)

    def _collect_sample(self, i: int, row: dict, offset: int) -> None:
        """Append this block's sample rows for check `i`, up to `sample_size`."""
        for pair in row[f"sample:{i}"] or []:
            if len(self._samples[i]) >= self._sample_size:
                self._needs_sample[i] = False
                return
            value = pair["value"]
            self._samples[i].append((offset + int(pair["line"]), value if value is not None else ""))

    def _assemble(self) -> list[ColumnData]:
        """Group per-check results back under their column, preserving order."""
        by_column: dict[str, list[CheckData]] = {col: [] for col in self._by_column}
        for i, (col, chk) in enumerate(self._flat):
            by_column[col].append((chk.check, self._counts[i], self._samples[i]))
        return [(col, self._colfail[col], by_column[col]) for col in self._by_column]
