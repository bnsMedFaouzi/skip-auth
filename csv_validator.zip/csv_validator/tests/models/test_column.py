"""Tests for models/column.py: per-column maximum cell width."""

from csv_validator import JsonSchemaParser


def _col(**props):
    return JsonSchemaParser({"properties": {"C": {"ColumnIndex": 1, **props}}}).parse()[0]


def test_max_bytes_uses_size():
    assert _col(type="string", Size=40).max_bytes() == 40


def test_max_bytes_uses_total_digits():
    assert _col(type="number", TotalDigit=25).max_bytes() == 27   # digits + sign + decimal point


def test_max_bytes_defaults_per_kind():
    assert _col(type="string").max_bytes(string_default=48) == 48     # un-sized string
    assert _col(type="number").max_bytes(other_default=16) == 16      # no TotalDigit
