"""Tests for execution/engine.py: end-to-end orchestration + async facade."""

import asyncio

import pytest

from csv_validator import validate, validate_async


def test_end_to_end_example(example, checks):
    report = validate(example / "passive_sr_schema.json", example / "sample_data.csv")
    assert report.status == "INVALID_DATA"
    assert report.file.rows == 6
    assert report.file.structure_valid is True
    c = checks(report)
    assert c[("PassSROrigin", "mandatory")] == 1
    assert c[("ExtractionTS", "type:timestamp")] == 1
    assert c[("Ccy", "type:string")] == 1                  # pattern folded into the type check


def test_column_failure_rate(example):
    report = validate(example / "passive_sr_schema.json", example / "sample_data.csv")
    col = next(c for c in report.columns if c.column == "PassSROrigin")
    assert col.failing_rows == 2                            # lines 3 and 5
    assert abs(col.failure_rate - 2 / 6) < 1e-9


def test_validate_async_and_sync_guard(tmp_file):
    schema = {"properties": {"A": {"type": "integer", "ColumnIndex": 1}}}
    csv = tmp_file("A\n1\n2\n")

    report = asyncio.run(validate_async(schema, csv))
    assert report.status == "VALID"

    async def _guard():
        with pytest.raises(RuntimeError):
            validate(schema, csv)                          # sync call inside a running loop
    asyncio.run(_guard())
