"""Tests for sources/csv_source.py: header handling and the source name."""

import logging

from csv_validator import CsvDataSource, validate

_SCHEMA = {"properties": {"a": {"type": "number", "ColumnIndex": 1},
                          "b": {"type": "number", "ColumnIndex": 2}}}


def test_trailing_empty_column_removed(tmp_file):
    csv = tmp_file("a;b;\n1;2;\n3;4;\n")                    # trailing separator -> empty last column
    report = validate(_SCHEMA, csv)
    assert report.file.columns_present == 2                # phantom column dropped
    assert report.file.unexpected_columns == []


def test_missing_trailing_column_warns(tmp_file, caplog):
    csv = tmp_file("a;b\n1;2\n")                            # no trailing separator
    with caplog.at_level(logging.WARNING):
        validate(_SCHEMA, csv)
    assert any("No trailing empty column" in m for m in caplog.messages)


def test_source_exposes_name(tmp_file):
    csv = tmp_file("a;b\n1;2\n")
    assert CsvDataSource(csv).name.endswith(".csv")


def _cols(schema):
    from csv_validator import JsonSchemaParser
    return JsonSchemaParser(schema).parse()


def test_batch_for_is_forced_by_row_batch_size(tmp_file):
    from csv_validator import EngineConfig
    ds = CsvDataSource(tmp_file("a;b\n1;2\n"))
    cols = _cols({"properties": {"a": {"type": "number", "ColumnIndex": 1}}})
    assert ds.batch_for(cols, EngineConfig(row_batch_size=999)) == 999


def test_batch_for_heavier_schema_is_smaller(tmp_file):
    from csv_validator import EngineConfig
    ds = CsvDataSource(tmp_file("a\n1\n"))
    light = _cols({"properties": {"a": {"type": "number", "ColumnIndex": 1}}})
    heavy = _cols({"properties": {"a": {"type": "string", "Size": 500, "ColumnIndex": 1}}})
    cfg = EngineConfig()
    assert ds.batch_for(heavy, cfg) < ds.batch_for(light, cfg)


def test_estimated_peak_stays_under_target(tmp_file):
    from csv_validator import EngineConfig
    ds = CsvDataSource(tmp_file("a\n1\n"))
    cfg = EngineConfig()
    cols = _cols({"properties": {"a": {"type": "string", "Size": 100, "ColumnIndex": 1}}})
    b = ds.batch_for(cols, cfg)
    W = sum(c.weight(cfg) for c in cols)
    if cfg.min_batch < b < cfg.max_batch:
        assert ds.estimated_peak_mb(b, W) <= cfg.target_memory_mb * (1 - cfg.safety_margin) + 1
