"""Shared fixtures for the test suite (mirrors the source package layout)."""

from pathlib import Path

import pytest

from csv_validator import EngineConfig, validate

EXAMPLE = Path(__file__).parent.parent / "example"


@pytest.fixture
def example() -> Path:
    """Directory holding the bundled example schema + CSV."""
    return EXAMPLE


@pytest.fixture
def checks():
    """Flatten a report into {(column, check): error_count}."""
    def _checks(report) -> dict:
        return {(c.column, ck.check): ck.error_count
                for c in report.columns for ck in c.checks}
    return _checks


@pytest.fixture
def tmp_file(tmp_path):
    """Write text to a fresh temp file and return its path."""
    counter = {"n": 0}
    def _make(text: str, suffix: str = ".csv") -> str:
        counter["n"] += 1
        p = tmp_path / f"f{counter['n']}{suffix}"
        p.write_text(text)
        return str(p)
    return _make


@pytest.fixture
def run_csv(tmp_file):
    """Validate an inline CSV against a schema, with optional EngineConfig kwargs."""
    def _run(schema, rows: str, **cfg):
        config = EngineConfig(**cfg) if cfg else None
        return validate(schema, tmp_file(rows), config=config)
    return _run
