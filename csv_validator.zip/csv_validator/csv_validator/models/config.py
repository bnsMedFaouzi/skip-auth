"""Engine configuration (Pydantic)."""

from __future__ import annotations

from pydantic import BaseModel

# --- Peak-memory model (internal constants) --------------------------------- #
# We assume every cell holds its MAXIMUM width (from the schema), and peak memory
# is LINEAR in the bytes held by one batch:
#   x = batch_rows * W,  W = sum of per-column MAX widths + one byte per check
#   peak_mb ~= _BASELINE_MB + _MB_PER_UNIT * x
# These are a CONSERVATIVE UPPER-BOUND envelope (predicted peak stays above the
# real peak across a diverse corpus), so the model over-provisions by design and
# needs NO per-file calibration. Edit only if you deliberately recalibrate.
_BASELINE_MB = 100.0     # fixed floor: interpreter + Polars (rounded up)
_MB_PER_UNIT = 1.0e-5    # MB of peak per (batch_row x byte-of-W) held


class EngineConfig(BaseModel):
    """Centralized engine parameters."""

    sample_size: int = 20            # bounded error sample per check
    streaming: bool = True           # use the Polars streaming engine

    # header / file structure
    strict_column_order: bool = True     # columns must match the schema order
    header_gate: bool = True             # invalid header stops value validation
    allow_extra_columns: bool = False    # tolerate CSV columns not in the schema

    # default date/timestamp formats, used when a column does not provide one
    default_date_format: str = "%Y-%m-%d"
    default_timestamp_format: str = "%Y-%m-%dT%H:%M:%S"

    # Rows per batch: bounds peak memory (a batch is evaluated then discarded).
    # Leave as None to size it automatically so peak stays under `target_memory_mb`;
    # set an int to force it (best for known, measured files).
    row_batch_size: int | None = None
    target_memory_mb: int = 300          # memory budget the auto batch stays under
    safety_margin: float = 0.25          # aim for (1 - margin) x target, since we predict

    # Per-cell MAX text width (bytes) for columns the schema does not bound with a
    # `Size` or `TotalDigit`. Un-sized strings can be wide; everything else is small.
    default_string_bytes: int = 64   # string column with no Size
    default_other_bytes: int = 20    # number w/o TotalDigit, date, timestamp, boolean
    mask_bytes: int = 1              # per-check boolean mask contribution to W

    min_batch: int = 5_000           # keep batching efficiency on very wide schemas
    max_batch: int = 200_000         # cap on very narrow schemas

    @property
    def engine_mode(self) -> str:
        """The Polars collect engine: streaming when enabled, else auto."""
        return "streaming" if self.streaming else "auto"
