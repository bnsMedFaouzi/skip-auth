"""Data source abstraction (Strategy)."""

from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import Iterator

import polars as pl


class DataSource(ABC):
    """Abstract source of tabular data."""

    @abstractmethod
    def columns(self) -> list[str]:
        """Return the column names, in order."""

    @abstractmethod
    def iter_frames(self, batch_size: int) -> Iterator[pl.LazyFrame]:
        """Yield the data as lazy frames of `batch_size` rows (all columns as text).

        Each block is a small, independent lazy scan: the caller adds its
        expressions and collects once, so only the aggregated result is
        materialized and peak memory stays bounded regardless of file size.
        """
