"""Tests for validators/constraint.py: per-constraint behavior."""


def test_mandatory_and_type(run_csv, checks):
    schema = {"properties": {"A": {"type": "number", "ColumnIndex": 1, "Mandatory": "Yes"}}}
    c = checks(run_csv(schema, "A\n1\n\nx\n"))
    assert c[("A", "mandatory")] == 1
    assert c[("A", "type:number")] == 1


def test_number_accepts_comma_and_leading_separator(run_csv, checks):
    # '.' or ',' decimal separator, and a leading separator ('.5', ',5').
    schema = {"properties": {"N": {"type": "number", "ColumnIndex": 1}}}
    c = checks(run_csv(schema, "N\n1.5\n1,5\n.5\n,5\n-,25\n+.5\nabc\n"))
    assert c.get(("N", "type:number")) == 1                # only 'abc' is not a number


def test_number_comma_respects_minimum_and_precision(run_csv, checks):
    schema = {"properties": {"N": {"type": "number", "minimum": 0, "FractionDigit": 2,
                                   "ColumnIndex": 1}}}
    c = checks(run_csv(schema, "N\n1,5\n-,5\n0,123\n"))
    assert c[("N", "type:number")] == 2                    # '-,5' < 0, and '0,123' has 3 fraction digits


def test_boolean_type_validation(run_csv):
    schema = {"properties": {"B": {"type": "boolean", "ColumnIndex": 1}}}
    report = run_csv(schema, "B\ntrue\nNO\n1\nmaybe\n")     # only 'maybe' is invalid
    assert report.file.total_errors == 1


def test_total_digits_constraint(run_csv):
    schema = {"properties": {"N": {"type": "number", "TotalDigit": 3, "ColumnIndex": 1}}}
    report = run_csv(schema, "N\n12\n1234\n")               # 1234 has 4 digits > 3
    assert report.file.total_errors == 1
