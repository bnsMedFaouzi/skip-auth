"""Validation engine (Facade).

Order: parse schema -> validate header (structure, gate) -> single streaming pass
over the data -> build the file + column metrics report.
"""

from __future__ import annotations

import asyncio
from pathlib import Path

from ..models import (
    CheckMetric, ColumnMetrics, EngineConfig, ReportBuilder, ValidationReport,
)
from ..schema import JsonSchemaParser, SchemaParser
from ..sources import CsvDataSource, DataSource
from ..structure import HeaderValidator
from ..validators import ValidatorRegistry, default_registry
from .runner import Runner


class ValidationEngine:
    def __init__(
        self,
        schema_parser: SchemaParser,
        data_source: DataSource,
        registry: ValidatorRegistry | None = None,
        config: EngineConfig | None = None,
        runner: Runner | None = None,
    ) -> None:
        self._schema_parser = schema_parser
        self._data_source = data_source
        self._config = config or EngineConfig()
        self._registry = registry or default_registry(self._config)
        self._runner = runner or Runner()
        self._header = HeaderValidator()
        self._builder = ReportBuilder()

    def validate(self) -> ValidationReport:
        try:
            asyncio.get_running_loop()
        except RuntimeError:
            return asyncio.run(self.validate_async())
        raise RuntimeError("An event loop is already running; use `await engine.validate_async()`.")

    async def validate_async(self) -> ValidationReport:
        cfg = self._config
        columns = self._schema_parser.parse()
        actual = self._data_source.columns()

        header = self._header.check(columns, actual, cfg)
        present = [c for c in columns if c.name in set(actual)]

        # Gate: a broken header stops value validation.
        if cfg.header_gate and not header.valid:
            return self._builder.build(
                rows=0, columns_expected=len(columns), columns_present=len(present),
                missing=header.missing, unexpected=header.unexpected,
                order_ok=header.order_ok, structure_valid=False,
                columns=[], stopped_at="header",
            )

        checks_by_column = self._plan(present)
        blocks = self._data_source.iter_frames(cfg.row_batch_size)
        rows, column_data = await asyncio.to_thread(
            self._runner.run, blocks,
            checks_by_column, cfg.sample_size, cfg.engine_mode,
        )

        columns_metrics = [self._to_metrics(col, failing, checks, rows)
                           for col, failing, checks in column_data]

        return self._builder.build(
            rows=rows, columns_expected=len(columns), columns_present=len(present),
            missing=header.missing, unexpected=header.unexpected,
            order_ok=header.order_ok, structure_valid=header.valid,
            columns=columns_metrics,
        )

    # -- helpers ------------------------------------------------------------

    def _plan(self, present) -> dict:
        by_col: dict = {}
        for col in present:
            checks = self._registry.checks_for(col)
            if checks:
                by_col[col.name] = checks
        return by_col

    @staticmethod
    def _to_metrics(column, failing_rows, checks, rows) -> ColumnMetrics:
        rate = (failing_rows / rows) if rows else 0.0
        check_metrics = [
            CheckMetric(check=name, error_count=count,
                        failure_rate=(count / rows) if rows else 0.0, sample=sample)
            for name, count, sample in checks if count > 0
        ]
        return ColumnMetrics(
            column=column, failing_rows=failing_rows, failure_rate=rate,
            error_count=sum(c.error_count for c in check_metrics), checks=check_metrics,
        )


# --- convenience facades ---------------------------------------------------

def _engine(schema_source, csv_path, registry, config) -> ValidationEngine:
    return ValidationEngine(JsonSchemaParser(schema_source), CsvDataSource(csv_path), registry, config)


def validate(schema_source, csv_path: str | Path, *, config: EngineConfig | None = None,
             registry: ValidatorRegistry | None = None) -> ValidationReport:
    return _engine(schema_source, csv_path, registry, config).validate()


async def validate_async(schema_source, csv_path: str | Path, *, config: EngineConfig | None = None,
                         registry: ValidatorRegistry | None = None) -> ValidationReport:
    return await _engine(schema_source, csv_path, registry, config).validate_async()
