"""Normalized column definition (internal model)."""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field


class ColumnDef(BaseModel):
    """Normalized column, independent of the source schema format.

    `attributes` carries the full resolved schema node (original keys). It is the
    hook for **future rules**: a new validator can read a new JSON field from
    `attributes` without changing this model or the parser.
    """

    name: str
    base_type: str                            # "string", "number", "timestamp"...
    mandatory: bool = False
    order: int | None = None                  # ColumnIndex
    max_length: int | None = None             # Size
    allowed_values: list[str] | None = None   # AuthorizeValue / enum
    pattern: str | None = None
    minimum: float | None = None
    label: str | None = None                  # InformationItem (human-readable)
    attributes: dict[str, Any] = Field(default_factory=dict)  # full schema node

    def attr(self, key: str, default: Any = None) -> Any:
        """Read a raw schema attribute (for future/custom rules)."""
        return self.attributes.get(key, default)
