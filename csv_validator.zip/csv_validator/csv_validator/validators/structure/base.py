"""Structure validation — the check abstraction and its result.

A structure check inspects the file's columns (header) before any value
validation. All checks share one contract: `check(...)` returns the issues it
finds (an empty list means the file passes that check). The header is just one
such check (see `checks.py`); `FileRunner` owns and runs them.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field

from ...models import ColumnDef, EngineConfig


@dataclass
class StructureResult:
    """Outcome of the file-structure validation: the issues found across all checks."""

    issues: list[str] = field(default_factory=list)

    @property
    def valid(self) -> bool:
        """The structure is valid when no check reported an issue."""
        return not self.issues


class StructureCheck(ABC):
    """A file-structure check: returns its issue messages (empty when satisfied)."""

    name: str = "structure"

    @abstractmethod
    def check(self, columns: list[ColumnDef], actual: list[str], config: EngineConfig) -> list[str]:
        """Issue messages for this check, empty when the header satisfies it."""
