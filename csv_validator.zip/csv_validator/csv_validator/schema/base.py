"""Schema parser abstraction (Strategy)."""

from __future__ import annotations

from abc import ABC, abstractmethod

from ..models import ColumnDef


class SchemaParser(ABC):
    """Abstract schema parser: produces normalized columns."""

    @abstractmethod
    def parse(self) -> list[ColumnDef]:
        """Return the ordered list of normalized columns."""
