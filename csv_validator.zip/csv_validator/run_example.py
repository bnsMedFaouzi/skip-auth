"""Example run of the engine.

    python run_example.py

Validates example/sample_data.csv against example/passive_sr_schema.json and
prints the report.
"""

from pathlib import Path

from csv_validator import validate

HERE = Path(__file__).parent
SCHEMA = HERE / "example" / "passive_sr_schema.json"
CSV = HERE / "example" / "sample_data.csv"


def main() -> None:
    report = validate(SCHEMA, CSV, sample_size=20)
    print(report.to_text())


if __name__ == "__main__":
    main()
