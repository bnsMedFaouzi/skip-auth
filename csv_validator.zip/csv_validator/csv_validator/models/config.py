"""Engine configuration (Pydantic)."""

from __future__ import annotations

from pydantic import BaseModel


class EngineConfig(BaseModel):
    """Centralized engine parameters."""

    sample_size: int = 20            # bounded error sample per check
    streaming: bool = True           # use the Polars streaming engine

    # header / file structure
    strict_column_order: bool = True     # columns must match the schema order
    header_gate: bool = True             # invalid header stops value validation
    allow_extra_columns: bool = False    # tolerate CSV columns not in the schema

    # default date/timestamp formats, used when a column does not provide one
    default_date_format: str = "%Y-%m-%d"
    default_timestamp_format: str = "%Y-%m-%dT%H:%M:%S"

    @property
    def engine_mode(self) -> str:
        return "streaming" if self.streaming else "auto"
