"""JSON schema parser (JSON-Schema draft-07 style), validated with Pydantic.

References use the **named-type** convention: a property's `type` holds the name
of an entry in `definitions` (e.g. `{"type": "Currency"}`), rather than `$ref`.
Each resolved property is validated into a `PropertySchema` and mapped to a
normalized `ColumnDef`.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from pydantic import ValidationError

from ..models import ColumnDef, PropertySchema, RawSchema
from .base import SchemaParser

# Primitive type tokens; any other `type` value is treated as a definition name.
_TYPE_ALIASES = {
    "str": "string", "text": "string",
    "int": "integer", "integer": "integer",
    "number": "number", "decimal": "number", "float": "number", "double": "number",
    "timestamp": "timestamp", "datetime": "timestamp",
    "date": "date", "boolean": "boolean", "bool": "boolean",
}
_PRIMITIVES = set(_TYPE_ALIASES) | {"string"}
_TRUE = {"yes", "true", "y", "1"}


class SchemaError(ValueError):
    """Raised for a malformed schema (invalid property, or circular type ref)."""


class JsonSchemaParser(SchemaParser):
    """Parses the JSON schema into ordered, normalized column definitions."""

    def __init__(self, source: str | Path | dict[str, Any]) -> None:
        self._source = source

    def parse(self) -> list[ColumnDef]:
        """Return the columns, resolved and normalized, ordered by ColumnIndex."""
        raw = RawSchema.model_validate(self._load())
        columns = [
            self._to_column(name, self._resolve(name, node, raw.definitions, frozenset()))
            for name, node in raw.properties.items()
        ]
        columns.sort(key=lambda c: (c.order is None, c.order or 0))
        return columns

    def _load(self) -> dict[str, Any]:
        """Load the raw schema from a dict, a file path, or a JSON string."""
        if isinstance(self._source, dict):
            return self._source
        path = Path(self._source)
        if path.exists():
            return json.loads(path.read_text(encoding="utf-8"))
        if isinstance(self._source, str) and self._source.lstrip()[:1] in "{[":
            return json.loads(self._source)
        raise FileNotFoundError(f"Schema file not found: {self._source}")

    def _resolve(
        self, name: str, node: dict[str, Any], definitions: dict[str, dict], seen: frozenset
    ) -> dict[str, Any]:
        """Resolve a named-type reference.

        If `type` names a definition (not a primitive), merge that definition in —
        recursively, so chained references resolve — with the property's own keys
        taking precedence. Raises on a reference cycle.
        """
        ref = node.get("type")
        if not (isinstance(ref, str) and ref in definitions and ref.lower() not in _PRIMITIVES):
            return node
        if ref in seen:
            raise SchemaError(f"Column '{name}': circular type reference via '{ref}'")
        base = self._resolve(name, dict(definitions[ref]), definitions, seen | {ref})
        return {**base, **{k: v for k, v in node.items() if k != "type"}}

    def _to_column(self, name: str, node: dict[str, Any]) -> ColumnDef:
        """Validate one resolved property and map it to a normalized ColumnDef."""
        try:
            prop = PropertySchema.model_validate(node)
        except ValidationError as exc:
            raise SchemaError(f"Invalid schema for column '{name}': {exc}") from exc
        return ColumnDef(
            name=name,
            base_type=_base_type(prop.type),
            mandatory=prop.mandatory.strip().lower() in _TRUE,
            order=prop.column_index,
            max_length=prop.size,
            allowed_values=prop.authorize_value or prop.enum,
            pattern=prop.pattern,
            minimum=prop.minimum,
            total_digits=_as_int(prop.total_digits),
            fraction_digits=_as_int(prop.fraction_digits),
            date_format=prop.date_format,
            label=prop.information_item,
            attributes=node,
        )


def _base_type(raw_type: str | None) -> str:
    """Normalize a primitive type token (e.g. 'Timestamp' -> 'timestamp')."""
    token = (raw_type or "string").lower()
    return _TYPE_ALIASES.get(token, token)


def _as_int(value: float | None) -> int | None:
    """Coerce an optional digit count to int (tolerates float typos like 9.9)."""
    return int(value) if value is not None else None
