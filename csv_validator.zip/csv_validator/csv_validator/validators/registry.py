"""Validator registry — the extension point (types, constraints, custom checks)."""

from __future__ import annotations

from ..models import ColumnDef, EngineConfig
from ..models.check import BoundCheck
from .base import MandatoryValidator, Validator
from .constraint import Constraint
from .types import (
    BooleanType, DateType, IntegerType, NumberType, StringType, TimestampType,
    TypeValidator,
)


class ValidatorRegistry:
    """Holds validators and yields the checks applicable to a column.

    Three ways to extend, all without editing the built-ins:
      - `register(TypeValidator subclass)` — a new type;
      - `add_constraint(base_type, Constraint)` — fold a rule into a type's check;
      - `register(Validator)` — a separate, independently-reported check.
    """

    def __init__(self) -> None:
        self._validators: list[Validator] = []

    def register(self, validator: Validator) -> "ValidatorRegistry":
        """Add a validator (built-in or custom). Returns self for chaining."""
        self._validators.append(validator)
        return self

    def add_constraint(self, base_type: str, constraint: Constraint) -> "ValidatorRegistry":
        """Fold an extra constraint into the check of every matching type."""
        for validator in self._validators:
            if isinstance(validator, TypeValidator) and base_type in validator.handles:
                validator.constraints.append(constraint)
        return self

    def checks_for(self, col: ColumnDef) -> list[BoundCheck]:
        """The bound checks that apply to `col`, one per applicable validator."""
        return [
            BoundCheck(col.name, v.check_name(col), v.build(col))
            for v in self._validators
            if v.applies(col)
        ]


def default_registry(config: EngineConfig | None = None) -> ValidatorRegistry:
    """Registry with the built-ins: mandatory + one consolidated check per type."""
    cfg = config or EngineConfig()
    return (
        ValidatorRegistry()
        .register(MandatoryValidator())
        .register(StringType())
        .register(NumberType())
        .register(IntegerType())
        .register(TimestampType(cfg.default_timestamp_format))
        .register(DateType(cfg.default_date_format))
        .register(BooleanType())
    )
