"""CSV validation engine driven by a JSON schema.

Layered, object-oriented, pattern-based (Strategy, Template Method, Registry,
Facade, Builder). Pydantic validates the incoming schema and models the report;
Polars runs the column-wise checks in a streaming, event-loop-parallel engine.

Layers:
  models/      data structures (Pydantic where it adds value)
  sources/     data input (DataSource strategy)
  schema/      schema parsing (SchemaParser strategy)
  validators/  the checks (Strategy + Registry)
  execution/   orchestration (Runner + ValidationEngine facade)
"""

from .models import (
    ColumnDef, EngineConfig, DefinitionSchema, PropertySchema, RawSchema, BoundCheck,
    CheckMetric, ColumnMetrics, FileMetrics, ReportMetadata, ValidationReport, ReportBuilder,
)
from .structure import HeaderValidator, HeaderResult
from .sources import DataSource, CsvDataSource
from .schema import SchemaParser, JsonSchemaParser, SchemaError, SchemaError
from .validators import (
    Validator, GatedValidator, TypeValidator, Constraint,
    MandatoryValidator, ValidatorRegistry, default_registry,
)
from .execution import (
    BlockProcessor, Runner, ColumnRunner, FileRunner, ValidationEngine,
    validate, validate_async,
)

__all__ = [
    # models
    "ColumnDef", "EngineConfig", "DefinitionSchema", "PropertySchema", "RawSchema", "BoundCheck",
    "CheckMetric", "ColumnMetrics", "FileMetrics", "ReportMetadata", "ValidationReport", "ReportBuilder",
    "HeaderValidator", "HeaderResult",
    # sources / schema
    "DataSource", "CsvDataSource", "SchemaParser", "JsonSchemaParser", "SchemaError",
    # validators
    "Validator", "GatedValidator", "TypeValidator", "Constraint",
    "MandatoryValidator", "ValidatorRegistry", "default_registry",
    # execution
    "BlockProcessor", "Runner", "ColumnRunner", "FileRunner", "ValidationEngine",
    "validate", "validate_async",
]
