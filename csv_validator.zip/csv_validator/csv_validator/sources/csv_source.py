"""CSV data source (bounded-memory, block-by-block)."""

from __future__ import annotations

import io
import itertools
from collections.abc import Iterator
from pathlib import Path

import polars as pl

from .base import DataSource


class CsvDataSource(DataSource):
    """CSV file read in row blocks, every column as text.

    Each block is a small lazy scan collected by the caller, so peak memory
    depends on the block size, not the file size. Reading as text avoids implicit
    conversions and enables faithful lexical validation.

    Note: blocks are split on physical newlines; this assumes fields do not
    contain embedded newlines (true for the target inventory files).
    """

    def __init__(self, path: str | Path) -> None:
        self._path = Path(path)
        self._columns: list[str] | None = None

    def columns(self) -> list[str]:
        if self._columns is None:
            # Lazy: resolves the schema from the header only (does not read the
            # whole file, unlike `read_csv(path, n_rows=0)`).
            self._columns = pl.scan_csv(self._path).collect_schema().names()
        return self._columns

    def iter_frames(self, batch_size: int) -> Iterator[pl.DataFrame]:
        overrides = {c: pl.Utf8 for c in self.columns()}
        with open(self._path, "rb") as fh:
            header = fh.readline()
            while True:
                lines = list(itertools.islice(fh, batch_size))
                if not lines:
                    break
                # Yield a lazy scan of this N-line block; the caller adds its
                # expressions and collects once. Boundedness comes from slicing
                # to N lines here, not from the reader.
                yield pl.scan_csv(
                    io.BytesIO(header + b"".join(lines)),
                    schema_overrides=overrides,
                    infer_schema_length=0,
                    low_memory=True,
                )
