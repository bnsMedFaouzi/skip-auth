"""Data source abstraction (Strategy)."""

from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import Iterator

import polars as pl


class DataSource(ABC):
    """Abstract source of tabular data."""

    @abstractmethod
    def columns(self) -> list[str]:
        """Return the column names, in order."""

    @abstractmethod
    def iter_frames(self, batch_size: int) -> Iterator[pl.DataFrame]:
        """Yield the data in blocks of `batch_size` rows (all columns as text).

        Reading block by block keeps peak memory bounded regardless of file size.
        """
