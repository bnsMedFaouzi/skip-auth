"""Tests for execution/column_runner.py: error sampling."""

from csv_validator import EngineConfig, validate


def test_sample_is_capped_across_batches(tmp_file):
    schema = {"properties": {"N": {"type": "number", "ColumnIndex": 1}}}
    csv = tmp_file("N\na\nb\nc\nd\ne\n")                    # 5 non-numbers
    report = validate(schema, csv, config=EngineConfig(sample_size=2, row_batch_size=2))
    check = report.columns[0].checks[0]
    assert check.error_count == 5                           # all counted
    assert len(check.sample) == 2                           # but sample capped
