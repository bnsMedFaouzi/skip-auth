"""Tests for models/config.py: schema-weight (max width) linear memory model."""

from csv_validator import EngineConfig


class _Col:
    """Minimal stand-in for ColumnDef (row_weight reads type, max_length, total_digits)."""
    def __init__(self, type, max_length=None, total_digits=None):
        self.type = type
        self.max_length = max_length
        self.total_digits = total_digits


def test_forced_batch_size_wins():
    assert EngineConfig(row_batch_size=1234).batch_for(1000.0) == 1234


def test_row_weight_uses_max_per_type():
    cfg = EngineConfig()
    cols = [_Col("string", 40),          # Size -> 40
            _Col("number"),              # no TotalDigit -> default_other (20)
            _Col("string")]              # un-sized string -> default_string (64)
    assert cfg.row_weight(cols, num_checks=3) == 40 + 20 + 64 + 3   # + 1 byte per check


def test_total_digits_sets_number_width():
    cfg = EngineConfig()
    assert cfg.row_weight([_Col("number", total_digits=25)]) == 25 + 2   # digits + sign + decimal


def test_heavier_schema_gives_smaller_batch():
    cfg = EngineConfig()
    light, heavy = cfg.batch_for(100.0), cfg.batch_for(3000.0)
    assert heavy < light
    assert cfg.min_batch <= heavy <= cfg.max_batch
    assert cfg.min_batch <= light <= cfg.max_batch


def test_auto_batch_stays_under_margined_target():
    cfg = EngineConfig()
    W = 1000.0
    b = cfg.batch_for(W)
    if cfg.min_batch < b < cfg.max_batch:                          # not clamped
        peak = cfg.estimated_peak_mb(b, W)
        assert peak <= cfg.target_memory_mb * (1 - cfg.safety_margin) + 1


def test_operational_fields_configurable():
    cfg = EngineConfig(target_memory_mb=1000, safety_margin=0.3, min_batch=1000, max_batch=50_000)
    assert cfg.min_batch <= cfg.batch_for(500.0) <= cfg.max_batch
