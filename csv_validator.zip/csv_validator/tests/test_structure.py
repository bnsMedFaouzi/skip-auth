"""Tests for structure.py: header/column structure comparison and gating."""


def test_missing_column_gates(run_csv):
    schema = {"properties": {
        "A": {"type": "string", "ColumnIndex": 1, "Mandatory": "Yes"},
        "B": {"type": "string", "ColumnIndex": 2, "Mandatory": "No"},
    }}
    report = run_csv(schema, "A\nx\n")                      # B missing
    assert report.status == "INVALID_STRUCTURE"
    assert report.file.stopped_at == "header"
    assert "B" in report.file.missing_columns


def test_extra_column_flagged(run_csv):
    schema = {"properties": {"A": {"type": "string", "ColumnIndex": 1, "Mandatory": "No"}}}
    report = run_csv(schema, "A;Z\nx;1\n")                  # Z is extra
    assert "Z" in report.file.unexpected_columns
    assert report.file.structure_valid is False


def test_order_mismatch(run_csv):
    schema = {"properties": {
        "A": {"type": "string", "ColumnIndex": 1, "Mandatory": "No"},
        "B": {"type": "string", "ColumnIndex": 2, "Mandatory": "No"},
    }}
    report = run_csv(schema, "B;A\n1;2\n")                  # wrong order
    assert report.file.order_ok is False
    assert report.status == "INVALID_STRUCTURE"


def test_extra_column_tolerated_when_configured(run_csv):
    schema = {"properties": {"A": {"type": "string", "ColumnIndex": 1, "Mandatory": "No"}}}
    report = run_csv(schema, "A;Z\nx;1\n", allow_extra_columns=True)
    assert report.file.structure_valid is True
    assert "Z" in report.file.unexpected_columns           # still reported, but not failing
