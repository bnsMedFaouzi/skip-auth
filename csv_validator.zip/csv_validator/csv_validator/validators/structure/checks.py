"""Concrete structure checks — the header, and other file-level rules."""

from __future__ import annotations

from ...models import ColumnDef, EngineConfig, StructureIssue
from .base import StructureCheck


class HeaderCheck(StructureCheck):
    """The CSV columns must match the schema: presence, no extras, and order."""

    name = "header"

    def check(self, columns: list[ColumnDef], actual: list[str], config: EngineConfig) -> list[StructureIssue]:
        expected = [c.name for c in columns]           # already sorted by order
        expected_set, actual_set = set(expected), set(actual)
        issues: list[StructureIssue] = []

        missing = [c for c in expected if c not in actual_set]
        if missing:
            issues.append(self.issue("missing_columns", f"missing columns: {', '.join(missing)}", missing))

        unexpected = [c for c in actual if c not in expected_set]
        if unexpected and not config.allow_extra_columns:
            issues.append(self.issue("unexpected_columns",
                                     f"unexpected columns: {', '.join(unexpected)}", unexpected))

        # Order is only meaningful once the sets line up.
        if config.strict_column_order and not missing and (config.allow_extra_columns or not unexpected):
            if [c for c in actual if c in expected_set] != expected:
                issues.append(self.issue("out_of_order", "columns out of order"))

        return issues


class MaxColumns(StructureCheck):
    """The CSV must not have more than `limit` columns. (Not enabled by default.)"""

    name = "max_columns"

    def __init__(self, limit: int) -> None:
        self._limit = limit

    def check(self, columns: list[ColumnDef], actual: list[str], config: EngineConfig) -> list[StructureIssue]:
        if len(actual) > self._limit:
            return [self.issue("too_many_columns", f"too many columns: {len(actual)} > {self._limit}")]
        return []
