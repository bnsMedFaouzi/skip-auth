"""File-structure validation (the header), alongside the column validators.

The header is checked on the column *names* (before touching the data): it is a
structural, gate-level concern — if the columns are wrong or misordered,
validating values makes no sense. The built-in core checks presence and order;
extra rules plug in as `StructureCheck` objects (mirroring the column validators).
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field

from ..models import ColumnDef, EngineConfig


@dataclass
class HeaderResult:
    """Outcome of the header check: missing/extra columns, order, extra issues, validity."""

    missing: list[str] = field(default_factory=list)      # schema cols absent from CSV
    unexpected: list[str] = field(default_factory=list)   # CSV cols absent from schema
    order_ok: bool = True
    issues: list[str] = field(default_factory=list)       # messages from extra StructureChecks
    valid: bool = True


class StructureCheck(ABC):
    """A pluggable header rule: returns a message when violated, else None."""

    name: str = "structure"

    @abstractmethod
    def violation(self, expected: list[str], actual: list[str], config: EngineConfig) -> str | None:
        """Message describing the violation, or None if the header satisfies the rule."""


class MaxColumns(StructureCheck):
    """The CSV must not have more than `limit` columns. (Not enabled by default.)

    A source-agnostic example: it counts columns, so it works even when the reader
    renames duplicate headers. Instantiate with a limit: `MaxColumns(300)`.
    """

    name = "max_columns"

    def __init__(self, limit: int) -> None:
        self._limit = limit

    def violation(self, expected: list[str], actual: list[str], config: EngineConfig) -> str | None:
        return f"too many columns: {len(actual)} > {self._limit}" if len(actual) > self._limit else None


class HeaderValidator:
    """Compares the CSV header to the schema, plus any extra `StructureCheck`s.

    Extend it like the validator registry: pass checks in, or chain `.add(check)`.
    A header is valid when the core checks pass AND no extra check reports an issue.
    """

    def __init__(self, checks: list[StructureCheck] | None = None) -> None:
        self._checks: list[StructureCheck] = list(checks or [])

    def add(self, check: StructureCheck) -> "HeaderValidator":
        """Register an extra structure check. Returns self for chaining."""
        self._checks.append(check)
        return self

    def check(self, columns: list[ColumnDef], actual: list[str], config: EngineConfig) -> HeaderResult:
        """Compare the CSV header to the schema (presence, order, extras + custom rules)."""
        expected = [c.name for c in columns]           # already sorted by order
        expected_set, actual_set = set(expected), set(actual)

        missing = [c for c in expected if c not in actual_set]
        unexpected = [c for c in actual if c not in expected_set]

        # Order is only meaningful once the sets line up.
        order_ok = True
        if config.strict_column_order and not missing and (config.allow_extra_columns or not unexpected):
            common_actual = [c for c in actual if c in expected_set]
            order_ok = common_actual == expected

        issues = [msg for chk in self._checks
                  if (msg := chk.violation(expected, actual, config)) is not None]

        valid = (
            not missing
            and (config.allow_extra_columns or not unexpected)
            and order_ok
            and not issues
        )
        return HeaderResult(missing=missing, unexpected=unexpected, order_ok=order_ok,
                            issues=issues, valid=valid)
