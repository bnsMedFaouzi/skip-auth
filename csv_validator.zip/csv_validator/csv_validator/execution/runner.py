"""Generic block runner: streams row blocks once, feeding block processors.

Blocks are lazy scans; each processor collects what it needs and reports how many
rows the block held, which the runner sums into the total (also used to offset the
next block). The block loop runs on the event loop: each block's blocking work is
offloaded to a worker thread, so the loop stays responsive between blocks (e.g.
to keep a liveness heartbeat alive during a long file). A `BlockProcessor` handles
anything that needs per-block state.
"""

from __future__ import annotations

import asyncio
from abc import ABC, abstractmethod
from collections.abc import Iterable
from typing import Any

import polars as pl


class BlockProcessor(ABC):
    """Consumes row blocks one by one, then yields a result."""

    @abstractmethod
    def update(self, block: pl.LazyFrame, offset: int) -> int:
        """Fold one block in (`offset` = rows seen before it); return its row count."""

    @abstractmethod
    def result(self) -> Any:
        """Return the accumulated result once all blocks are consumed."""


class Runner:
    """Streams blocks once on the event loop, feeding each to every processor."""

    async def run(
        self, blocks: Iterable[pl.LazyFrame], processors: list[BlockProcessor]
    ) -> tuple[int, list[Any]]:
        """Consume the blocks once; return the total row count and each result.

        Each block's blocking processing runs in a worker thread, so the event
        loop drives the iteration without being blocked by a collect.
        """
        rows = 0
        for block in blocks:
            block_rows = 0
            for processor in processors:
                block_rows = await asyncio.to_thread(processor.update, block, rows)
            rows += block_rows
        return rows, [processor.result() for processor in processors]
