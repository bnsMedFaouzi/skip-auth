"""Tests for __main__.py: the command-line interface."""

import json

from csv_validator.__main__ import main

_SCHEMA = '{"properties": {"A": {"type": "integer", "minimum": 0, "ColumnIndex": 1}}}'


def test_cli_text_invalid_returns_1(tmp_file, capsys):
    schema = tmp_file(_SCHEMA, suffix=".json")
    csv = tmp_file("A\n1\n-3\nx\n")
    code = main([schema, csv, "--sample", "5", "--show-clean"])
    assert code == 1
    assert "status :" in capsys.readouterr().out


def test_cli_json_and_valid_returns_0(tmp_file, capsys):
    schema = tmp_file(_SCHEMA, suffix=".json")
    csv = tmp_file("A\n1\n2\n3\n")
    code = main([schema, csv, "--json", "--no-streaming"])
    assert code == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["status"] == "VALID"
